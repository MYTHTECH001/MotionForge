import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Upload,
  Download,
  Undo2,
  Redo2,
  Plus,
  Copy,
  X,
  Film,
  Terminal,
} from 'lucide-react';
import {
  R15_JOINT_NAMES,
  createNeutralPose,
  type AnimationProject,
  type EasingMode,
  type EvaluatedPose,
  type Keyframe,
  type PropType,
  type R15JointName,
  type Vec3Tuple,
} from './animation/types.ts';
import { ANIMATION_PRESETS } from './animation/presets.ts';
import { evaluatePoseAtTime } from './animation/interpolation.ts';
import { validateAnimationPayload } from './animation/validator.ts';
import {
  clonePose,
  mirrorJointToOpposite,
  mirrorPoseAcrossX,
  type LibraryCategory,
  type SnapIncrementOption,
} from './animation/poseUtils.ts';
import { Viewport3D, type ViewLayout } from './components/Viewport3D.tsx';
import { LeftToolRail, type LeftToolId } from './components/LeftToolRail.tsx';
import {
  ToolDrawer,
  type SavedLibraryItem,
} from './components/ToolDrawer.tsx';
import { InspectorPanel } from './components/InspectorPanel.tsx';
import { TimelinePanel } from './components/TimelinePanel.tsx';
import { ExportModal } from './components/ExportModal.tsx';
import { McpModal } from './components/McpModal.tsx';

const LAYOUT_STORAGE_KEY = 'motionforge.workspace.v2';
const LIBRARY_STORAGE_KEY = 'motionforge.library.v2';
const WORKSPACE_CLIPS_STORAGE_KEY = 'motionforge-workspace-v1';

interface WorkspaceClip {
  id: string;
  project: AnimationProject;
  undoStack: AnimationProject[];
  redoStack: AnimationProject[];
  isDirty: boolean;
  selectedKeyframeId: string | null;
  currentTime: number;
}

interface WorkspacePrefs {
  drawerWidth: number;
  inspectorWidth: number;
  timelineHeight: number;
  timelineCollapsed: boolean;
  gridVisible: boolean;
  showSkeleton: boolean;
  onionSkinEnabled: boolean;
  onionOpacity: number;
  snapToGrid: boolean;
  snapIncrement: SnapIncrementOption;
  viewLayout: ViewLayout;
  persistLayout: boolean;
}

const DEFAULT_PREFS: WorkspacePrefs = {
  drawerWidth: 300,
  inspectorWidth: 288,
  timelineHeight: 176,
  timelineCollapsed: false,
  gridVisible: true,
  showSkeleton: false,
  onionSkinEnabled: false,
  onionOpacity: 0.24,
  snapToGrid: true,
  snapIncrement: 0.1,
  viewLayout: 'single',
  persistLayout: true,
};

function isValidSnapIncrement(v: unknown): v is SnapIncrementOption {
  return v === 'frame' || v === 0.05 || v === 0.1 || v === 0.25 || v === 0.5;
}

function isValidViewLayout(v: unknown): v is ViewLayout {
  return v === 'single' || v === 'split' || v === 'quad';
}

function loadSavedPrefs(): WorkspacePrefs {
  try {
    const raw = window.localStorage.getItem(LAYOUT_STORAGE_KEY);
    if (!raw) return DEFAULT_PREFS;
    const parsed = JSON.parse(raw) as Partial<WorkspacePrefs>;
    if (parsed.persistLayout === false) {
      return { ...DEFAULT_PREFS, persistLayout: false };
    }
    return {
      ...DEFAULT_PREFS,
      ...parsed,
      drawerWidth: Math.max(260, Math.min(420, Number(parsed.drawerWidth) || 300)),
      inspectorWidth: Math.max(250, Math.min(380, Number(parsed.inspectorWidth) || 288)),
      timelineHeight: Math.max(140, Math.min(340, Number(parsed.timelineHeight) || 176)),
      onionOpacity: Math.max(0.1, Math.min(0.55, Number(parsed.onionOpacity) || 0.24)),
      snapToGrid: typeof parsed.snapToGrid === 'boolean' ? parsed.snapToGrid : true,
      snapIncrement: isValidSnapIncrement(parsed.snapIncrement)
        ? parsed.snapIncrement
        : 0.1,
      viewLayout: isValidViewLayout(parsed.viewLayout)
        ? parsed.viewLayout
        : 'single',
    };
  } catch {
    return DEFAULT_PREFS;
  }
}

function loadSavedLibrary(): SavedLibraryItem[] {
  try {
    const raw = window.localStorage.getItem(LIBRARY_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as SavedLibraryItem[]) : [];
  } catch {
    return [];
  }
}

function makeClipId(): string {
  return `clip-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
}

function createBlankProject(index: number): AnimationProject {
  return {
    version: 1,
    name: `New Animation ${index}`,
    duration: 2.0,
    fps: 30,
    loop: true,
    prop: 'none',
    keyframes: [
      {
        id: `kf-start-${Date.now()}`,
        time: 0,
        easing: 'easeInOut',
        joints: {
          HumanoidRootPart: [0, 0, 0],
          UpperTorso: [0, 0, 0],
          LeftUpperArm: [0, 0, 6],
          RightUpperArm: [0, 0, -6],
        },
        rootPosition: [0, 0, 0],
      },
      {
        id: `kf-end-${Date.now() + 1}`,
        time: 2.0,
        easing: 'easeInOut',
        joints: {
          HumanoidRootPart: [0, 0, 0],
          UpperTorso: [0, 0, 0],
          LeftUpperArm: [0, 0, 6],
          RightUpperArm: [0, 0, -6],
        },
        rootPosition: [0, 0, 0],
      },
    ],
  };
}

function createDefaultWorkspaceState(): {
  clips: WorkspaceClip[];
  activeClipId: string;
} {
  const initialProject = structuredClone(ANIMATION_PRESETS[0].project);
  return {
    activeClipId: 'clip-initial',
    clips: [
      {
        id: 'clip-initial',
        project: initialProject,
        undoStack: [],
        redoStack: [],
        isDirty: false,
        selectedKeyframeId: initialProject.keyframes[0]?.id ?? null,
        currentTime: 0,
      },
    ],
  };
}

function loadSavedWorkspaceClips(): {
  clips: WorkspaceClip[];
  activeClipId: string;
} {
  try {
    const raw = window.localStorage.getItem(WORKSPACE_CLIPS_STORAGE_KEY);
    if (!raw) return createDefaultWorkspaceState();
    const parsed = JSON.parse(raw) as {
      activeClipId?: unknown;
      clips?: unknown;
    };
    if (!parsed || !Array.isArray(parsed.clips)) {
      return createDefaultWorkspaceState();
    }

    const restored: WorkspaceClip[] = [];
    for (const item of parsed.clips) {
      if (!item || typeof item !== 'object') continue;
      const entry = item as Record<string, unknown>;
      const validation = validateAnimationPayload(entry.project);
      if (!validation.valid || !validation.project) continue;

      const id =
        typeof entry.id === 'string' && entry.id.trim().length > 0
          ? entry.id.trim()
          : makeClipId();
      const rawTime = Number(entry.currentTime);
      const currentTime = Number.isFinite(rawTime)
        ? Math.max(0, Math.min(validation.project.duration, rawTime))
        : 0;
      const selectedKeyframeId =
        typeof entry.selectedKeyframeId === 'string' &&
        validation.project.keyframes.some(
          (k) => k.id === entry.selectedKeyframeId,
        )
          ? entry.selectedKeyframeId
          : (validation.project.keyframes[0]?.id ?? null);

      restored.push({
        id,
        project: validation.project,
        undoStack: [],
        redoStack: [],
        isDirty: Boolean(entry.isDirty),
        selectedKeyframeId,
        currentTime,
      });
    }

    if (restored.length === 0) {
      return createDefaultWorkspaceState();
    }

    const activeClipId =
      typeof parsed.activeClipId === 'string' &&
      restored.some((c) => c.id === parsed.activeClipId)
        ? parsed.activeClipId
        : restored[0].id;

    return { clips: restored, activeClipId };
  } catch {
    return createDefaultWorkspaceState();
  }
}

export default function App() {
  const initialPrefs = useMemo(() => loadSavedPrefs(), []);
  const initialWorkspace = useMemo(() => loadSavedWorkspaceClips(), []);

  const [clips, setClips] = useState<WorkspaceClip[]>(initialWorkspace.clips);
  const [activeClipId, setActiveClipId] = useState(
    initialWorkspace.activeClipId,
  );

  const activeClip = useMemo(
    () => clips.find((c) => c.id === activeClipId) ?? clips[0],
    [clips, activeClipId],
  );
  const project = activeClip.project;
  const undoStack = activeClip.undoStack;
  const redoStack = activeClip.redoStack;
  const isDirty = activeClip.isDirty;
  const selectedKeyframeId = activeClip.selectedKeyframeId;

  const [currentTime, setCurrentTime] = useState(activeClip.currentTime);
  const currentTimeRef = useRef(activeClip.currentTime);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);

  // Contextual Inspector hidden by default until a joint is selected
  const [selectedJoint, setSelectedJoint] = useState<R15JointName | null>(null);
  const [inspectorOpen, setInspectorOpen] = useState(false);
  const [manualPoseOverride, setManualPoseOverride] =
    useState<EvaluatedPose | null>(null);

  // Workspace Layout & Tool State
  const [activeTool, setActiveTool] = useState<LeftToolId | null>('ai');
  const [drawerWidth, setDrawerWidth] = useState(initialPrefs.drawerWidth);
  const [inspectorWidth, setInspectorWidth] = useState(initialPrefs.inspectorWidth);
  const [timelineHeight, setTimelineHeight] = useState(initialPrefs.timelineHeight);
  const [timelineCollapsed, setTimelineCollapsed] = useState(
    initialPrefs.timelineCollapsed,
  );
  const [gridVisible, setGridVisible] = useState(initialPrefs.gridVisible);
  const [showSkeleton, setShowSkeleton] = useState(initialPrefs.showSkeleton);
  const [onionSkinEnabled, setOnionSkinEnabled] = useState(
    initialPrefs.onionSkinEnabled,
  );
  const [onionOpacity, setOnionOpacity] = useState(initialPrefs.onionOpacity);
  const [snapToGrid, setSnapToGrid] = useState(initialPrefs.snapToGrid);
  const [snapIncrement, setSnapIncrement] = useState<SnapIncrementOption>(
    initialPrefs.snapIncrement,
  );
  const [viewLayout, setViewLayout] = useState<ViewLayout>(initialPrefs.viewLayout);
  const [persistLayout, setPersistLayout] = useState(initialPrefs.persistLayout);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Library, Recent, Preview & Modals
  const [savedAnimations, setSavedAnimations] = useState<SavedLibraryItem[]>(() =>
    loadSavedLibrary(),
  );
  const [recentProjects, setRecentProjects] = useState<AnimationProject[]>([]);
  const [recentGenerations, setRecentGenerations] = useState<AnimationProject[]>([]);
  const [previewProject, setPreviewProject] = useState<AnimationProject | null>(
    null,
  );
  const [exportOpen, setExportOpen] = useState(false);
  const [mcpOpen, setMcpOpen] = useState(false);
  const [notice, setNotice] = useState<{
    text: string;
    kind: 'info' | 'error';
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const showNotice = useCallback(
    (text: string, kind: 'info' | 'error' = 'info') => {
      setNotice({ text, kind });
    },
    [],
  );

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(null), 4000);
    return () => window.clearTimeout(timer);
  }, [notice]);

  // Persist workspace layout preferences
  useEffect(() => {
    try {
      const prefs: WorkspacePrefs = {
        drawerWidth,
        inspectorWidth,
        timelineHeight,
        timelineCollapsed,
        gridVisible,
        showSkeleton,
        onionSkinEnabled,
        onionOpacity,
        snapToGrid,
        snapIncrement,
        viewLayout,
        persistLayout,
      };
      window.localStorage.setItem(LAYOUT_STORAGE_KEY, JSON.stringify(prefs));
    } catch {
      // Ignore storage quota errors
    }
  }, [
    drawerWidth,
    inspectorWidth,
    timelineHeight,
    timelineCollapsed,
    gridVisible,
    showSkeleton,
    onionSkinEnabled,
    onionOpacity,
    snapToGrid,
    snapIncrement,
    viewLayout,
    persistLayout,
  ]);

  // Persist saved animations library
  useEffect(() => {
    try {
      window.localStorage.setItem(
        LIBRARY_STORAGE_KEY,
        JSON.stringify(savedAnimations),
      );
    } catch {
      // Ignore storage quota errors
    }
  }, [savedAnimations]);

  // Debounced autosave for active clip and workspace clip list
  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        const payload = {
          activeClipId,
          clips: clips.map((c) => ({
            id: c.id,
            project: c.project,
            isDirty: c.isDirty,
            selectedKeyframeId: c.selectedKeyframeId,
            currentTime: c.id === activeClipId ? currentTime : c.currentTime,
          })),
        };
        window.localStorage.setItem(
          WORKSPACE_CLIPS_STORAGE_KEY,
          JSON.stringify(payload),
        );
      } catch {
        // Ignore storage quota errors
      }
    }, 400);

    return () => window.clearTimeout(timer);
  }, [clips, activeClipId, currentTime]);

  const updateActiveClip = useCallback(
    (updater: (clip: WorkspaceClip) => WorkspaceClip) => {
      setClips((prev) =>
        prev.map((c) => (c.id === activeClip.id ? updater(c) : c)),
      );
    },
    [activeClip.id],
  );

  const setSelectedKeyframeId = useCallback(
    (id: string | null) => {
      updateActiveClip((c) => ({ ...c, selectedKeyframeId: id }));
    },
    [updateActiveClip],
  );

  const setIsDirty = useCallback(
    (dirty: boolean) => {
      updateActiveClip((c) => ({ ...c, isDirty: dirty }));
    },
    [updateActiveClip],
  );

  // Commit project mutation with Undo/Redo snapshot on the active clip
  const mutateProject = useCallback(
    (updater: (prev: AnimationProject) => AnimationProject, recordUndo = true) => {
      updateActiveClip((clip) => {
        const nextProject = updater(clip.project);
        return {
          ...clip,
          project: nextProject,
          undoStack: recordUndo
            ? [...clip.undoStack.slice(-39), structuredClone(clip.project)]
            : clip.undoStack,
          redoStack: recordUndo ? [] : clip.redoStack,
          isDirty: true,
        };
      });
    },
    [updateActiveClip],
  );

  const handleUndo = useCallback(() => {
    updateActiveClip((clip) => {
      if (clip.undoStack.length === 0) return clip;
      const previous = clip.undoStack[clip.undoStack.length - 1];
      return {
        ...clip,
        project: previous,
        undoStack: clip.undoStack.slice(0, -1),
        redoStack: [...clip.redoStack, structuredClone(clip.project)],
        isDirty: true,
      };
    });
    setManualPoseOverride(null);
    if (undoStack.length > 0) {
      showNotice('Undid last change', 'info');
    }
  }, [updateActiveClip, undoStack.length, showNotice]);

  const handleRedo = useCallback(() => {
    updateActiveClip((clip) => {
      if (clip.redoStack.length === 0) return clip;
      const next = clip.redoStack[clip.redoStack.length - 1];
      return {
        ...clip,
        project: next,
        undoStack: [...clip.undoStack.slice(-39), structuredClone(clip.project)],
        redoStack: clip.redoStack.slice(0, -1),
        isDirty: true,
      };
    });
    setManualPoseOverride(null);
    if (redoStack.length > 0) {
      showNotice('Redid change', 'info');
    }
  }, [updateActiveClip, redoStack.length, showNotice]);

  // Multi-Clip Tab Management
  const handleSwitchClip = useCallback(
    (targetId: string) => {
      if (targetId === activeClip.id) return;
      setPreviewProject(null);
      setIsPlaying(false);
      setManualPoseOverride(null);

      const savedTime = currentTimeRef.current;
      let targetTime = 0;

      setClips((prev) =>
        prev.map((c) => {
          if (c.id === activeClip.id) {
            return { ...c, currentTime: savedTime };
          }
          if (c.id === targetId) {
            targetTime = Math.min(c.project.duration, c.currentTime);
          }
          return c;
        }),
      );

      setActiveClipId(targetId);
      currentTimeRef.current = targetTime;
      setCurrentTime(targetTime);
    },
    [activeClip.id],
  );

  const handleCreateNewClip = useCallback(() => {
    setPreviewProject(null);
    setIsPlaying(false);
    setManualPoseOverride(null);

    const newProj = createBlankProject(clips.length + 1);
    const newId = makeClipId();
    const savedTime = currentTimeRef.current;

    setClips((prev) => [
      ...prev.map((c) =>
        c.id === activeClip.id ? { ...c, currentTime: savedTime } : c,
      ),
      {
        id: newId,
        project: newProj,
        undoStack: [],
        redoStack: [],
        isDirty: false,
        selectedKeyframeId: newProj.keyframes[0]?.id ?? null,
        currentTime: 0,
      },
    ]);
    setActiveClipId(newId);
    currentTimeRef.current = 0;
    setCurrentTime(0);
    showNotice(`Created "${newProj.name}" (${newProj.duration.toFixed(1)}s)`, 'info');
  }, [clips.length, activeClip.id, showNotice]);

  const handleDuplicateActiveClip = useCallback(() => {
    setPreviewProject(null);
    setIsPlaying(false);
    setManualPoseOverride(null);

    const clonedProj = structuredClone(activeClip.project);
    clonedProj.name = `${clonedProj.name} Copy`;
    const newId = makeClipId();
    const savedTime = currentTimeRef.current;

    setClips((prev) => [
      ...prev.map((c) =>
        c.id === activeClip.id ? { ...c, currentTime: savedTime } : c,
      ),
      {
        id: newId,
        project: clonedProj,
        undoStack: [],
        redoStack: [],
        isDirty: true,
        selectedKeyframeId: clonedProj.keyframes[0]?.id ?? null,
        currentTime: 0,
      },
    ]);
    setActiveClipId(newId);
    currentTimeRef.current = 0;
    setCurrentTime(0);
    showNotice(`Duplicated clip as "${clonedProj.name}"`, 'info');
  }, [activeClip, showNotice]);

  const handleCloseClip = useCallback(
    (clipId: string) => {
      if (clips.length <= 1) return;
      const idx = clips.findIndex((c) => c.id === clipId);
      if (idx === -1) return;

      const remaining = clips.filter((c) => c.id !== clipId);
      setClips(remaining);

      if (clipId === activeClip.id) {
        setPreviewProject(null);
        setIsPlaying(false);
        setManualPoseOverride(null);
        const fallback = remaining[Math.max(0, idx - 1)] ?? remaining[0];
        setActiveClipId(fallback.id);
        const t = Math.min(fallback.project.duration, fallback.currentTime);
        currentTimeRef.current = t;
        setCurrentTime(t);
      }
    },
    [clips, activeClip.id],
  );

  // Active timeline & viewport source (either preview candidate or active clip)
  const activeRigProject = previewProject ?? project;

  const activeKeyframe = useMemo(() => {
    if (previewProject) return null;
    if (selectedKeyframeId) {
      const exact = project.keyframes.find((k) => k.id === selectedKeyframeId);
      if (exact && Math.abs(exact.time - currentTime) < 0.02) {
        return exact;
      }
    }
    return (
      project.keyframes.find((k) => Math.abs(k.time - currentTime) < 0.02) ??
      null
    );
  }, [previewProject, project.keyframes, selectedKeyframeId, currentTime]);

  const evaluatedPose = useMemo(
    () =>
      evaluatePoseAtTime(
        activeRigProject.keyframes,
        currentTime,
        undefined,
        activeRigProject.loop,
        activeRigProject.duration,
      ),
    [
      activeRigProject.keyframes,
      activeRigProject.loop,
      activeRigProject.duration,
      currentTime,
    ],
  );

  const displayPose = manualPoseOverride ?? evaluatedPose;

  // Compute Onion Skinning previous & next keyframe poses
  const { prevGhostPose, nextGhostPose } = useMemo(() => {
    if (!onionSkinEnabled || activeRigProject.keyframes.length < 2) {
      return { prevGhostPose: null, nextGhostPose: null };
    }
    const sorted = [...activeRigProject.keyframes].sort(
      (a, b) => a.time - b.time,
    );
    let prevKf: Keyframe | null = null;
    let nextKf: Keyframe | null = null;

    for (let i = 0; i < sorted.length; i++) {
      const kf = sorted[i];
      if (kf.time < currentTime - 0.015) {
        prevKf = kf;
      } else if (kf.time > currentTime + 0.015 && !nextKf) {
        nextKf = kf;
      }
    }

    if (!prevKf && activeRigProject.loop && sorted.length > 1) {
      prevKf = sorted[sorted.length - 2];
    }
    if (!nextKf && activeRigProject.loop && sorted.length > 1) {
      nextKf = sorted[1];
    }

    return {
      prevGhostPose: prevKf
        ? evaluatePoseAtTime(sorted, prevKf.time)
        : null,
      nextGhostPose: nextKf
        ? evaluatePoseAtTime(sorted, nextKf.time)
        : null,
    };
  }, [onionSkinEnabled, activeRigProject.keyframes, activeRigProject.loop, currentTime]);

  const handleLoadProject = useCallback(
    (
      nextProject: AnimationProject,
      sourceLabel?: string,
      opts?: { newTab?: boolean },
    ) => {
      setPreviewProject(null);
      setIsPlaying(false);
      setManualPoseOverride(null);
      const savedTime = currentTimeRef.current;
      currentTimeRef.current = 0;
      setCurrentTime(0);

      if (opts?.newTab) {
        const newId = makeClipId();
        setClips((prev) => [
          ...prev.map((c) =>
            c.id === activeClip.id ? { ...c, currentTime: savedTime } : c,
          ),
          {
            id: newId,
            project: nextProject,
            undoStack: [],
            redoStack: [],
            isDirty: false,
            selectedKeyframeId: nextProject.keyframes[0]?.id ?? null,
            currentTime: 0,
          },
        ]);
        setActiveClipId(newId);
      } else {
        setRecentProjects((rec) => {
          const filtered = rec.filter((r) => r.name !== project.name);
          return [structuredClone(project), ...filtered].slice(0, 6);
        });
        updateActiveClip((clip) => ({
          ...clip,
          project: nextProject,
          undoStack: [...clip.undoStack.slice(-39), structuredClone(clip.project)],
          redoStack: [],
          isDirty: false,
          selectedKeyframeId: nextProject.keyframes[0]?.id ?? null,
          currentTime: 0,
        }));
      }

      if (sourceLabel) {
        showNotice(sourceLabel, 'info');
      }
    },
    [activeClip.id, project, updateActiveClip, showNotice],
  );

  const handleStartPreview = useCallback((candidate: AnimationProject) => {
    setManualPoseOverride(null);
    setPreviewProject(candidate);
    currentTimeRef.current = 0;
    setCurrentTime(0);
    setIsPlaying(true);
  }, []);

  const handleApplyPreview = useCallback(() => {
    if (!previewProject) return;
    const toApply = structuredClone(previewProject);
    handleLoadProject(toApply, `Applied "${toApply.name}"`);
  }, [previewProject, handleLoadProject]);

  const handleCancelPreview = useCallback(() => {
    setPreviewProject(null);
    setIsPlaying(false);
    currentTimeRef.current = 0;
    setCurrentTime(0);
  }, []);

  const handleTimeTick = useCallback((t: number, ended?: boolean) => {
    setCurrentTime(t);
    if (ended) {
      setIsPlaying(false);
    }
  }, []);

  const handleScrub = useCallback(
    (t: number) => {
      const clamped = Math.max(0, Math.min(activeRigProject.duration, t));
      setIsPlaying(false);
      setManualPoseOverride(null);
      currentTimeRef.current = clamped;
      setCurrentTime(clamped);
      if (!previewProject) {
        const hit = project.keyframes.find(
          (k) => Math.abs(k.time - clamped) < 0.02,
        );
        setSelectedKeyframeId(hit ? hit.id : null);
      }
    },
    [
      activeRigProject.duration,
      previewProject,
      project.keyframes,
      setSelectedKeyframeId,
    ],
  );

  const handleTogglePlay = useCallback(() => {
    setManualPoseOverride(null);
    setIsPlaying((prev) => {
      if (!prev && currentTimeRef.current >= activeRigProject.duration - 0.01) {
        currentTimeRef.current = 0;
        setCurrentTime(0);
      }
      return !prev;
    });
  }, [activeRigProject.duration]);

  const handleStop = useCallback(() => {
    setIsPlaying(false);
    setManualPoseOverride(null);
    currentTimeRef.current = 0;
    setCurrentTime(0);
    setSelectedKeyframeId(activeRigProject.keyframes[0]?.id ?? null);
  }, [activeRigProject.keyframes, setSelectedKeyframeId]);

  const handleSelectJoint = useCallback((joint: R15JointName) => {
    setSelectedJoint(joint);
    setInspectorOpen(true);
  }, []);

  const handleSelectKeyframe = useCallback(
    (kf: Keyframe) => {
      setIsPlaying(false);
      setManualPoseOverride(null);
      currentTimeRef.current = kf.time;
      setCurrentTime(kf.time);
      setSelectedKeyframeId(kf.id);
    },
    [setSelectedKeyframeId],
  );

  const handleBeginMoveKeyframe = useCallback(() => {
    updateActiveClip((clip) => ({
      ...clip,
      undoStack: [...clip.undoStack.slice(-39), structuredClone(clip.project)],
      redoStack: [],
    }));
  }, [updateActiveClip]);

  const handleMoveKeyframe = useCallback(
    (kfId: string, newTime: number) => {
      const clamped =
        Math.round(Math.max(0, Math.min(project.duration, newTime)) * 1000) /
        1000;
      updateActiveClip((clip) => ({
        ...clip,
        isDirty: true,
        project: {
          ...clip.project,
          keyframes: clip.project.keyframes
            .map((k) => (k.id === kfId ? { ...k, time: clamped } : k))
            .sort((a, b) => a.time - b.time),
        },
      }));
    },
    [project.duration, updateActiveClip],
  );

  const handleEditJointRotation = useCallback(
    (joint: R15JointName, axis: 0 | 1 | 2, deg: number) => {
      setIsPlaying(false);
      setManualPoseOverride((prev) => {
        const base = prev ? clonePose(prev) : clonePose(evaluatedPose);
        base.joints[joint][axis] = deg;
        return base;
      });
    },
    [evaluatedPose],
  );

  const handleEditRootPosition = useCallback(
    (axis: 0 | 1 | 2, val: number) => {
      setIsPlaying(false);
      setManualPoseOverride((prev) => {
        const base = prev ? clonePose(prev) : clonePose(evaluatedPose);
        base.rootPosition[axis] = val;
        return base;
      });
    },
    [evaluatedPose],
  );

  const handleResetJoint = useCallback(
    (joint: R15JointName) => {
      setIsPlaying(false);
      setManualPoseOverride((prev) => {
        const base = prev ? clonePose(prev) : clonePose(evaluatedPose);
        base.joints[joint] = [0, 0, 0];
        if (joint === 'HumanoidRootPart') {
          base.rootPosition = [0, 0, 0];
        }
        return base;
      });
    },
    [evaluatedPose],
  );

  const handleResetFullPose = useCallback(() => {
    setIsPlaying(false);
    setManualPoseOverride(createNeutralPose());
  }, []);

  const handleMirrorFullPose = useCallback(() => {
    setIsPlaying(false);
    const mirrored = mirrorPoseAcrossX(displayPose);
    setManualPoseOverride(mirrored);
    showNotice('Mirrored full pose across X-axis (keyframe to save)', 'info');
  }, [displayPose, showNotice]);

  const handleMirrorSelectedJoint = useCallback(
    (joint: R15JointName) => {
      setIsPlaying(false);
      const { pose: nextPose, targetJoint } = mirrorJointToOpposite(
        displayPose,
        joint,
      );
      setManualPoseOverride(nextPose);
      showNotice(`Mirrored ${joint} to ${targetJoint}`, 'info');
    },
    [displayPose, showNotice],
  );

  const handleApplyQuickTemplate = useCallback(
    (template: 'neutral' | 'ready' | 'tpose') => {
      setIsPlaying(false);
      const pose = createNeutralPose();
      if (template === 'tpose') {
        pose.joints.LeftUpperArm = [0, 0, 90];
        pose.joints.RightUpperArm = [0, 0, -90];
      } else if (template === 'ready') {
        pose.rootPosition = [0, -0.1, 0];
        pose.joints.UpperTorso = [-8, 0, 0];
        pose.joints.Head = [6, 0, 0];
        pose.joints.LeftUpperArm = [-25, 0, 18];
        pose.joints.LeftLowerArm = [-45, 0, 0];
        pose.joints.RightUpperArm = [-25, 0, -18];
        pose.joints.RightLowerArm = [-45, 0, 0];
        pose.joints.LeftUpperLeg = [-16, 0, 5];
        pose.joints.LeftLowerLeg = [28, 0, 0];
        pose.joints.LeftFoot = [-12, 0, 0];
        pose.joints.RightUpperLeg = [10, 0, -5];
        pose.joints.RightLowerLeg = [18, 0, 0];
        pose.joints.RightFoot = [-10, 0, 0];
      }
      setManualPoseOverride(pose);
    },
    [],
  );

  const commitPoseAtTime = useCallback(
    (poseToSave: EvaluatedPose, targetTime: number) => {
      if (previewProject) return;
      const roundedTime = Math.round(targetTime * 1000) / 1000;
      const sparseJoints: Partial<Record<R15JointName, Vec3Tuple>> = {};
      for (const j of R15_JOINT_NAMES) {
        const [rx, ry, rz] = poseToSave.joints[j];
        sparseJoints[j] = [
          Math.round(rx * 100) / 100,
          Math.round(ry * 100) / 100,
          Math.round(rz * 100) / 100,
        ];
      }
      const rootPos: Vec3Tuple = [
        Math.round(poseToSave.rootPosition[0] * 100) / 100,
        Math.round(poseToSave.rootPosition[1] * 100) / 100,
        Math.round(poseToSave.rootPosition[2] * 100) / 100,
      ];

      let resultingId = '';
      mutateProject((prev) => {
        const existing = prev.keyframes.find(
          (k) => Math.abs(k.time - roundedTime) < 0.02,
        );
        if (existing) {
          resultingId = existing.id;
          return {
            ...prev,
            keyframes: prev.keyframes.map((k) =>
              k.id === existing.id
                ? { ...k, joints: sparseJoints, rootPosition: rootPos }
                : k,
            ),
          };
        } else {
          resultingId = `kf-${Date.now()}`;
          const nextKf: Keyframe = {
            id: resultingId,
            time: roundedTime,
            easing: 'easeInOut',
            joints: sparseJoints,
            rootPosition: rootPos,
          };
          return {
            ...prev,
            keyframes: [...prev.keyframes, nextKf].sort(
              (a, b) => a.time - b.time,
            ),
          };
        }
      });

      setManualPoseOverride(null);
      if (resultingId) {
        setSelectedKeyframeId(resultingId);
      }
      showNotice(`Keyframed pose at ${roundedTime.toFixed(2)}s`, 'info');
    },
    [previewProject, mutateProject, setSelectedKeyframeId, showNotice],
  );

  const handleCommitPoseToKeyframe = useCallback(() => {
    commitPoseAtTime(displayPose, currentTime);
  }, [commitPoseAtTime, displayPose, currentTime]);

  const handleDuplicateKeyframe = useCallback(
    (kfId: string) => {
      const source = project.keyframes.find((k) => k.id === kfId);
      if (!source) return;
      const newTime = Math.min(
        project.duration,
        Math.round((source.time + 0.1) * 1000) / 1000,
      );
      const dup: Keyframe = {
        ...structuredClone(source),
        id: `kf-dup-${Date.now()}`,
        time: newTime,
      };
      mutateProject((prev) => ({
        ...prev,
        keyframes: [...prev.keyframes, dup].sort((a, b) => a.time - b.time),
      }));
      currentTimeRef.current = newTime;
      setCurrentTime(newTime);
      setSelectedKeyframeId(dup.id);
      showNotice(`Duplicated keyframe to ${newTime.toFixed(2)}s`, 'info');
    },
    [
      project.keyframes,
      project.duration,
      mutateProject,
      setSelectedKeyframeId,
      showNotice,
    ],
  );

  const handleDeleteKeyframe = useCallback(
    (kfId: string) => {
      if (project.keyframes.length <= 1) return;
      mutateProject((prev) => ({
        ...prev,
        keyframes: prev.keyframes.filter((k) => k.id !== kfId),
      }));
      setSelectedKeyframeId(null);
      setManualPoseOverride(null);
      showNotice('Deleted keyframe', 'info');
    },
    [project.keyframes.length, mutateProject, setSelectedKeyframeId, showNotice],
  );

  const handleChangeKeyframeMeta = useCallback(
    (kfId: string, patch: { time?: number; easing?: EasingMode }) => {
      mutateProject((prev) => ({
        ...prev,
        keyframes: prev.keyframes
          .map((k) => (k.id === kfId ? { ...k, ...patch } : k))
          .sort((a, b) => a.time - b.time),
      }));
      if (patch.time !== undefined) {
        currentTimeRef.current = patch.time;
        setCurrentTime(patch.time);
      }
    },
    [mutateProject],
  );

  const handleChangeDuration = useCallback(
    (nextDuration: number) => {
      mutateProject((prev) => {
        const oldDur = Math.max(0.01, prev.duration);
        const ratio = nextDuration / oldDur;
        return {
          ...prev,
          duration: Math.round(nextDuration * 100) / 100,
          keyframes: prev.keyframes.map((k) => ({
            ...k,
            time: Math.round(k.time * ratio * 1000) / 1000,
          })),
        };
      });
      currentTimeRef.current = Math.min(currentTimeRef.current, nextDuration);
      setCurrentTime(currentTimeRef.current);
    },
    [mutateProject],
  );

  const handleImportJSON = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const validation = validateAnimationPayload(parsed);
      if (!validation.valid || !validation.project) {
        showNotice(
          `Invalid project JSON: ${validation.errors.join(' ')}`,
          'error',
        );
        return;
      }
      handleLoadProject(
        validation.project,
        `Imported "${validation.project.name}" (${validation.project.keyframes.length} keys)`,
        { newTab: true },
      );
    } catch {
      showNotice('Could not parse JSON file.', 'error');
    }
  };

  const handleSaveCurrentToLibrary = useCallback(
    (category: Exclude<LibraryCategory, 'All'>) => {
      const item: SavedLibraryItem = {
        id: `saved-${Date.now()}`,
        savedAt: new Date().toISOString(),
        category,
        project: structuredClone(project),
      };
      setSavedAnimations((prev) => [item, ...prev]);
      setIsDirty(false);
      showNotice(`Saved "${project.name}" to Library`, 'info');
    },
    [project, setIsDirty, showNotice],
  );

  const handleDeleteSavedAnimation = useCallback((id: string) => {
    setSavedAnimations((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const handleResetWorkspaceLayout = useCallback(() => {
    setDrawerWidth(DEFAULT_PREFS.drawerWidth);
    setInspectorWidth(DEFAULT_PREFS.inspectorWidth);
    setTimelineHeight(DEFAULT_PREFS.timelineHeight);
    setTimelineCollapsed(false);
    setGridVisible(true);
    setShowSkeleton(false);
    setOnionSkinEnabled(false);
    setOnionOpacity(DEFAULT_PREFS.onionOpacity);
    setSnapToGrid(DEFAULT_PREFS.snapToGrid);
    setSnapIncrement(DEFAULT_PREFS.snapIncrement);
    setViewLayout(DEFAULT_PREFS.viewLayout);
    setActiveTool('ai');
    setInspectorOpen(false);
    showNotice('Reset workspace layout', 'info');
  }, [showNotice]);

  // Panel drag resize handlers
  const startDrawerResize = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    const startX = e.clientX;
    const startW = drawerWidth;
    const onMove = (ev: PointerEvent) => {
      setDrawerWidth(
        Math.max(260, Math.min(420, startW + (ev.clientX - startX))),
      );
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const startInspectorResize = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    const startX = e.clientX;
    const startW = inspectorWidth;
    const onMove = (ev: PointerEvent) => {
      setInspectorWidth(
        Math.max(250, Math.min(380, startW - (ev.clientX - startX))),
      );
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const startTimelineResize = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    const startY = e.clientY;
    const startH = timelineHeight;
    const onMove = (ev: PointerEvent) => {
      setTimelineHeight(
        Math.max(140, Math.min(340, startH - (ev.clientY - startY))),
      );
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  // Global Keyboard Shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const mod = e.metaKey || e.ctrlKey;
      if (mod && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) handleRedo();
        else handleUndo();
        return;
      }
      if (mod && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
        return;
      }

      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

      if (e.code === 'Space') {
        e.preventDefault();
        handleTogglePlay();
      } else if (e.key === 'k' || e.key === 'K') {
        e.preventDefault();
        handleCommitPoseToKeyframe();
      } else if (e.key === 'o' || e.key === 'O') {
        e.preventDefault();
        setOnionSkinEnabled((v) => !v);
      } else if (e.key === 'g' || e.key === 'G') {
        e.preventDefault();
        setGridVisible((v) => !v);
      } else if (e.key === 'j' || e.key === 'J') {
        e.preventDefault();
        setShowSkeleton((v) => !v);
      } else if (e.key === 's' || e.key === 'S') {
        e.preventDefault();
        setSnapToGrid((v) => !v);
      } else if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        handleMirrorFullPose();
      } else if (e.key === 'Escape') {
        if (isFullscreen) setIsFullscreen(false);
        else if (activeTool) setActiveTool(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    handleUndo,
    handleRedo,
    handleTogglePlay,
    handleCommitPoseToKeyframe,
    handleMirrorFullPose,
    isFullscreen,
    activeTool,
  ]);

  return (
    <div className="h-screen w-screen flex flex-col bg-[#0B0E14] text-[#F1F5F9] overflow-hidden">
      {/* 1. Slim Application Header */}
      {!isFullscreen && (
        <header className="h-11 shrink-0 bg-[#111622] border-b border-[#232B3E] px-4 flex items-center justify-between gap-4">
          {/* Brand + Editable Name + Save Status */}
          <div className="flex items-center gap-4 min-w-0">
            <div className="flex items-center gap-2 shrink-0">
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                aria-hidden="true"
                className="text-[#3B82F6]"
              >
                <rect
                  x="3"
                  y="3"
                  width="8"
                  height="8"
                  rx="1.5"
                  fill="currentColor"
                />
                <rect
                  x="13"
                  y="3"
                  width="8"
                  height="8"
                  rx="1.5"
                  fill="currentColor"
                  fillOpacity="0.45"
                />
                <rect
                  x="8"
                  y="13"
                  width="8"
                  height="8"
                  rx="1.5"
                  fill="currentColor"
                  fillOpacity="0.75"
                />
              </svg>
              <span className="text-sm font-bold tracking-tight text-white whitespace-nowrap">
                MotionForge
              </span>
            </div>

            <div className="w-px h-4 bg-[#232B3E] hidden sm:block" />

            <input
              type="text"
              aria-label="Animation name"
              value={project.name}
              onChange={(e) => {
                const name = e.target.value;
                updateActiveClip((clip) => ({
                  ...clip,
                  isDirty: true,
                  project: { ...clip.project, name },
                }));
              }}
              className="w-36 sm:w-52 bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded px-2 py-1 text-xs font-medium text-slate-100 outline-none truncate"
            />

            <span className="hidden md:inline text-[11px] text-slate-400 whitespace-nowrap">
              {isDirty ? 'Unsaved changes' : 'Saved'}
            </span>
          </div>

          {/* Right: Undo/Redo, Import, Export */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="flex items-center gap-0.5">
              <button
                type="button"
                onClick={handleUndo}
                disabled={undoStack.length === 0}
                title="Undo (Ctrl+Z)"
                className="p-1.5 text-slate-300 hover:text-white hover:bg-[#1B2233] disabled:opacity-35 disabled:cursor-not-allowed rounded transition-colors cursor-pointer"
              >
                <Undo2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={handleRedo}
                disabled={redoStack.length === 0}
                title="Redo (Ctrl+Shift+Z)"
                className="p-1.5 text-slate-300 hover:text-white hover:bg-[#1B2233] disabled:opacity-35 disabled:cursor-not-allowed rounded transition-colors cursor-pointer"
              >
                <Redo2 className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="w-px h-4 bg-[#232B3E]" />

            <input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              onChange={handleImportJSON}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              title="Import MotionForge Project JSON into new clip tab"
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white hover:bg-[#1B2233] rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Import .motionforge.json</span>
            </button>

            <button
              type="button"
              onClick={() => setMcpOpen(true)}
              title="Connect Claude Code or Codex via MCP Server"
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white hover:bg-[#1B2233] rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Terminal className="w-3.5 h-3.5 text-[#60A5FA]" />
              <span>MCP</span>
            </button>

            <button
              type="button"
              onClick={() => setExportOpen(true)}
              title="Export JSON, GLB, or FBX Animation"
              className="flex items-center gap-1.5 px-3 py-1 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export</span>
            </button>
          </div>
        </header>
      )}

      {/* Multi-Clip Workspace Tab Bar */}
      {!isFullscreen && (
        <div className="h-8 shrink-0 bg-[#0E131D] border-b border-[#232B3E] px-2 flex items-center justify-between gap-2 overflow-hidden">
          <div className="flex items-center gap-1 overflow-x-auto min-w-0 py-0.5">
            {clips.map((clip) => {
              const isActive = clip.id === activeClip.id;
              return (
                <div
                  key={clip.id}
                  className={`group flex items-center gap-1.5 px-2.5 py-1 rounded text-xs transition-colors shrink-0 border ${
                    isActive
                      ? 'bg-[#172033] border-[#3B82F6]/60 text-white'
                      : 'bg-transparent border-transparent text-slate-400 hover:text-slate-200 hover:bg-[#151B29]'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => handleSwitchClip(clip.id)}
                    className="flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    <Film className="w-3 h-3 text-[#3B82F6] shrink-0" />
                    <span className="max-w-36 truncate font-medium">
                      {clip.project.name || 'Untitled'}
                    </span>
                    <span className="text-[10px] font-mono tabular-nums text-slate-400">
                      {clip.project.duration.toFixed(1)}s
                    </span>
                    {clip.isDirty && (
                      <span
                        title="Unsaved changes"
                        className="text-amber-400 font-bold leading-none"
                      >
                        *
                      </span>
                    )}
                  </button>
                  {clips.length > 1 && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCloseClip(clip.id);
                      }}
                      title="Close clip tab"
                      aria-label={`Close ${clip.project.name}`}
                      className="p-0.5 text-slate-500 hover:text-slate-200 rounded transition-colors cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={handleDuplicateActiveClip}
              title="Duplicate current animation into a new clip tab"
              className="flex items-center gap-1 px-2 py-0.5 text-[11px] font-medium text-slate-400 hover:text-white hover:bg-[#1B2233] rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Copy className="w-3 h-3" />
              <span className="hidden sm:inline">Duplicate</span>
            </button>
            <button
              type="button"
              onClick={handleCreateNewClip}
              title="Create a new blank animation clip tab"
              className="flex items-center gap-1 px-2 py-0.5 text-[11px] font-medium text-sky-300 hover:text-white bg-[#161E2E] hover:bg-[#1D2842] border border-[#232B3E] rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-3 h-3" />
              <span>New Clip</span>
            </button>
          </div>
        </div>
      )}

      {/* 2. Main Workspace Row */}
      <div className="flex-1 flex min-h-0 overflow-hidden relative">
        {!isFullscreen && (
          <LeftToolRail
            activeTool={activeTool}
            onSelectTool={(tool) =>
              setActiveTool((curr) => (curr === tool ? null : tool))
            }
          />
        )}

        {!isFullscreen && activeTool && (
          <>
            <ToolDrawer
              activeTool={activeTool}
              width={drawerWidth}
              onClose={() => setActiveTool(null)}
              project={project}
              displayPose={displayPose}
              selectedJoint={selectedJoint}
              onSelectJoint={handleSelectJoint}
              onLoadProject={handleLoadProject}
              onChangeProp={(p) =>
                mutateProject((prev) => ({ ...prev, prop: p }))
              }
              onMirrorFullPose={handleMirrorFullPose}
              onResetFullPose={handleResetFullPose}
              onEditRootPosition={handleEditRootPosition}
              onApplyQuickTemplate={handleApplyQuickTemplate}
              savedAnimations={savedAnimations}
              recentProjects={recentProjects}
              recentGenerations={recentGenerations}
              onAddRecentGeneration={(proj) =>
                setRecentGenerations((prev) => [proj, ...prev].slice(0, 8))
              }
              onSaveCurrentToLibrary={handleSaveCurrentToLibrary}
              onDeleteSavedAnimation={handleDeleteSavedAnimation}
              onStartPreview={handleStartPreview}
              onionSkinEnabled={onionSkinEnabled}
              onToggleOnionSkin={() => setOnionSkinEnabled((v) => !v)}
              onionOpacity={onionOpacity}
              onChangeOnionOpacity={setOnionOpacity}
              gridVisible={gridVisible}
              onToggleGrid={() => setGridVisible((v) => !v)}
              showSkeleton={showSkeleton}
              onToggleSkeleton={() => setShowSkeleton((v) => !v)}
              persistLayout={persistLayout}
              onTogglePersistLayout={() => setPersistLayout((v) => !v)}
              onResetWorkspaceLayout={handleResetWorkspaceLayout}
            />
            <div
              onPointerDown={startDrawerResize}
              title="Drag to resize panel"
              className="w-1 shrink-0 cursor-col-resize hover:bg-[#3B82F6]/40 transition-colors bg-transparent"
            />
          </>
        )}

        {/* Dominant Center 3D Viewport (Single / Dual Split / Quad Views) */}
        <main className="flex-1 min-w-0 min-h-0 relative">
          <Viewport3D
            keyframes={activeRigProject.keyframes}
            duration={activeRigProject.duration}
            isPlaying={isPlaying}
            loop={activeRigProject.loop}
            playbackSpeed={playbackSpeed}
            currentTimeRef={currentTimeRef}
            onTimeTick={handleTimeTick}
            selectedJoint={selectedJoint}
            onSelectJoint={handleSelectJoint}
            showSkeleton={showSkeleton}
            onToggleSkeleton={() => setShowSkeleton((v) => !v)}
            gridVisible={gridVisible}
            onToggleGrid={() => setGridVisible((v) => !v)}
            onionSkinEnabled={onionSkinEnabled}
            onToggleOnionSkin={() => setOnionSkinEnabled((v) => !v)}
            onionOpacity={onionOpacity}
            prevGhostPose={prevGhostPose}
            nextGhostPose={nextGhostPose}
            viewLayout={viewLayout}
            onChangeViewLayout={setViewLayout}
            isFullscreen={isFullscreen}
            onToggleFullscreen={() => setIsFullscreen((v) => !v)}
            inspectorOpen={inspectorOpen && !isFullscreen}
            onOpenInspector={() => {
              if (!selectedJoint) setSelectedJoint('RightUpperArm');
              setInspectorOpen(true);
            }}
            prop={activeRigProject.prop}
            manualPoseOverride={previewProject ? null : manualPoseOverride}
            previewBanner={
              previewProject
                ? {
                    name: previewProject.name,
                    onApply: handleApplyPreview,
                    onCancel: handleCancelPreview,
                  }
                : null
            }
          />

          {notice && (
            <div
              className={`absolute bottom-9 right-3 z-30 px-3 py-1.5 rounded-md border text-xs font-medium shadow-lg ${
                notice.kind === 'error'
                  ? 'bg-rose-950/95 border-rose-700 text-rose-200'
                  : 'bg-[#111622] border-[#232B3E] text-slate-200'
              }`}
            >
              {notice.text}
            </div>
          )}
        </main>

        {/* Contextual Right Joint Inspector (hidden by default) */}
        {!isFullscreen && inspectorOpen && (
          <>
            <div
              onPointerDown={startInspectorResize}
              title="Drag to resize inspector"
              className="w-1 shrink-0 cursor-col-resize hover:bg-[#3B82F6]/40 transition-colors bg-transparent"
            />
            <InspectorPanel
              width={inspectorWidth}
              selectedJoint={selectedJoint}
              onSelectJoint={handleSelectJoint}
              displayPose={displayPose}
              activeKeyframe={activeKeyframe}
              currentTime={currentTime}
              hasUnsavedPoseEdits={manualPoseOverride !== null}
              onEditJointRotation={handleEditJointRotation}
              onEditRootPosition={handleEditRootPosition}
              onResetJoint={handleResetJoint}
              onMirrorFullPose={handleMirrorFullPose}
              onMirrorSelectedJoint={handleMirrorSelectedJoint}
              onCommitPoseToKeyframe={handleCommitPoseToKeyframe}
              onChangeKeyframeMeta={handleChangeKeyframeMeta}
              duration={project.duration}
              onClose={() => setInspectorOpen(false)}
            />
          </>
        )}
      </div>

      {/* 3. Resizable & Collapsible Timeline */}
      {!isFullscreen && (
        <TimelinePanel
          height={timelineHeight}
          keyframes={activeRigProject.keyframes}
          duration={activeRigProject.duration}
          fps={activeRigProject.fps}
          currentTime={currentTime}
          isPlaying={isPlaying}
          loop={activeRigProject.loop}
          playbackSpeed={playbackSpeed}
          selectedKeyframeId={selectedKeyframeId}
          snapEnabled={snapToGrid}
          snapIncrement={snapIncrement}
          onToggleSnap={() => setSnapToGrid((v) => !v)}
          onChangeSnapIncrement={setSnapIncrement}
          onTogglePlay={handleTogglePlay}
          onStop={handleStop}
          onToggleLoop={() =>
            mutateProject((prev) => ({ ...prev, loop: !prev.loop }))
          }
          onChangeSpeed={setPlaybackSpeed}
          onChangeDuration={handleChangeDuration}
          onScrub={handleScrub}
          onSelectKeyframe={handleSelectKeyframe}
          onBeginMoveKeyframe={handleBeginMoveKeyframe}
          onMoveKeyframe={handleMoveKeyframe}
          onChangeKeyframeEasing={(kfId, easing) =>
            handleChangeKeyframeMeta(kfId, { easing })
          }
          onAddKeyframeAtPlayhead={handleCommitPoseToKeyframe}
          onDuplicateKeyframe={handleDuplicateKeyframe}
          onDeleteKeyframe={handleDeleteKeyframe}
          isCollapsed={timelineCollapsed}
          onToggleCollapse={() => setTimelineCollapsed((v) => !v)}
          onStartResizeHeight={startTimelineResize}
        />
      )}

      <ExportModal
        project={project}
        isOpen={exportOpen}
        onClose={() => {
          setExportOpen(false);
          setIsDirty(false);
        }}
      />

      <McpModal
        isOpen={mcpOpen}
        onClose={() => setMcpOpen(false)}
        activeProject={project}
        onOpenClipInTab={(clipProj, label) =>
          handleLoadProject(clipProj, label, { newTab: true })
        }
      />
    </div>
  );
}
