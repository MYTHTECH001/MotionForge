import * as THREE from 'three';
import type { R15JointName } from '../animation/types.ts';

/**
 * Creates a rounded-rectangle ExtrudeGeometry centered on X/Z, spanning Y from yMin to yMax
 * (with optional bevels) so R15 limbs have chamfered studio edges instead of raw BoxGeometry.
 */
export function createChamferedBlockGeometry(
  width: number,
  height: number,
  depth: number,
  radius = 0.08,
  bevel = 0.035,
  yAnchor: 'center' | 'top' | 'bottom' = 'top',
): THREE.BufferGeometry {
  const innerW = Math.max(0.05, width - bevel * 2);
  const innerD = Math.max(0.05, depth - bevel * 2);
  const innerH = Math.max(0.05, height - bevel * 2);
  const r = Math.min(radius, innerW * 0.4, innerD * 0.4);

  const shape = new THREE.Shape();
  const hw = innerW / 2;
  const hd = innerD / 2;

  shape.moveTo(-hw + r, -hd);
  shape.lineTo(hw - r, -hd);
  shape.quadraticCurveTo(hw, -hd, hw, -hd + r);
  shape.lineTo(hw, hd - r);
  shape.quadraticCurveTo(hw, hd, hw - r, hd);
  shape.lineTo(-hw + r, hd);
  shape.quadraticCurveTo(-hw, hd, -hw, hd - r);
  shape.lineTo(-hw, -hd + r);
  shape.quadraticCurveTo(-hw, -hd, -hw + r, -hd);

  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: innerH,
    bevelEnabled: true,
    bevelThickness: bevel,
    bevelSize: bevel,
    bevelSegments: 2,
    curveSegments: 6,
  });

  // Extrude runs along +Z; rotate so extrusion runs along +Y
  geo.rotateX(-Math.PI / 2);
  geo.computeBoundingBox();
  const box = geo.boundingBox!;
  const centerX = (box.min.x + box.max.x) / 2;
  const centerZ = (box.min.z + box.max.z) / 2;

  let offsetY = 0;
  if (yAnchor === 'top') {
    // Pivot at top of limb (y = 0), limb extends downward to -height
    offsetY = -box.max.y;
  } else if (yAnchor === 'bottom') {
    // Pivot at bottom of limb (y = 0), limb extends upward to +height
    offsetY = -box.min.y;
  } else {
    offsetY = -(box.min.y + box.max.y) / 2;
  }

  geo.translate(-centerX, offsetY, -centerZ);
  geo.computeVertexNormals();
  return geo;
}

/**
 * Creates a procedural studio floor grid CanvasTexture with crisp lines and subtle radial fade.
 */
export function createStudioFloorTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#12151C';
  ctx.fillRect(0, 0, size, size);

  // Fine sub-grid (8x8)
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.08)';
  ctx.lineWidth = 1;
  const step = size / 8;
  for (let i = 0; i <= 8; i++) {
    const p = Math.round(i * step) + 0.5;
    ctx.beginPath();
    ctx.moveTo(p, 0);
    ctx.lineTo(p, size);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, p);
    ctx.lineTo(size, p);
    ctx.stroke();
  }

  // Major 1-stud tile border
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.22)';
  ctx.lineWidth = 2;
  ctx.strokeRect(1, 1, size - 2, size - 2);

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(16, 16);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Creates a soft radial contact shadow texture placed beneath the character at y = 0.005.
 */
export function createContactShadowTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createRadialGradient(
    size / 2,
    size / 2,
    12,
    size / 2,
    size / 2,
    size / 2,
  );
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.65)');
  grad.addColorStop(0.55, 'rgba(0, 0, 0, 0.28)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Exact R15 joint hierarchy offsets (1 unit = 1 Roblox stud, total standing height = 5.15 studs).
 * Neutral pose: feet soles sit at y = 0.00, HumanoidRootPart sits at y = 2.35.
 */
export const R15_PIVOT_OFFSETS: Record<R15JointName, [number, number, number]> = {
  HumanoidRootPart: [0, 2.35, 0],
  LowerTorso: [0, 0, 0],
  UpperTorso: [0, 0.35, 0],
  Head: [0, 1.25, 0],
  LeftUpperArm: [1.48, 1.06, 0],
  LeftLowerArm: [0, -0.82, 0],
  LeftHand: [0, -0.76, 0],
  RightUpperArm: [-1.48, 1.06, 0],
  RightLowerArm: [0, -0.82, 0],
  RightHand: [0, -0.76, 0],
  LeftUpperLeg: [0.5, -0.35, 0],
  LeftLowerLeg: [0, -0.85, 0],
  LeftFoot: [0, -0.85, 0],
  RightUpperLeg: [-0.5, -0.35, 0],
  RightLowerLeg: [0, -0.85, 0],
  RightFoot: [0, -0.85, 0],
};

/**
 * Builds a clean standalone Three.js R15 Group hierarchy for GLB/glTF export.
 */
export function buildExportableR15Group(): {
  root: THREE.Group;
  joints: Record<R15JointName, THREE.Group>;
} {
  const root = new THREE.Group();
  root.name = 'MotionForge_R15_Rig';

  const makeJoint = (name: R15JointName, parent: THREE.Object3D): THREE.Group => {
    const g = new THREE.Group();
    g.name = name;
    const [x, y, z] = R15_PIVOT_OFFSETS[name];
    g.position.set(x, y, z);
    parent.add(g);
    return g;
  };

  const matArmor = new THREE.MeshStandardMaterial({
    color: 0x2f3b52,
    roughness: 0.45,
    metalness: 0.25,
  });
  const matAccent = new THREE.MeshStandardMaterial({
    color: 0x3b82f6,
    roughness: 0.35,
    metalness: 0.5,
  });
  const matSkin = new THREE.MeshStandardMaterial({
    color: 0xd9b38c,
    roughness: 0.68,
    metalness: 0.04,
  });

  const HumanoidRootPart = makeJoint('HumanoidRootPart', root);
  const LowerTorso = makeJoint('LowerTorso', HumanoidRootPart);
  LowerTorso.add(
    new THREE.Mesh(createChamferedBlockGeometry(1.9, 0.7, 1.0, 0.1, 0.04, 'center'), matArmor),
  );

  const UpperTorso = makeJoint('UpperTorso', LowerTorso);
  UpperTorso.add(
    new THREE.Mesh(createChamferedBlockGeometry(2.0, 1.25, 1.05, 0.12, 0.05, 'bottom'), matArmor),
  );

  const Head = makeJoint('Head', UpperTorso);
  Head.add(
    new THREE.Mesh(createChamferedBlockGeometry(1.1, 1.1, 1.1, 0.24, 0.06, 'bottom'), matSkin),
  );

  const LeftUpperArm = makeJoint('LeftUpperArm', UpperTorso);
  LeftUpperArm.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.92, 0.84, 0.92, 0.12, 0.04, 'top'), matAccent),
  );
  const LeftLowerArm = makeJoint('LeftLowerArm', LeftUpperArm);
  LeftLowerArm.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.86, 0.78, 0.86, 0.12, 0.04, 'top'), matSkin),
  );
  const LeftHand = makeJoint('LeftHand', LeftLowerArm);
  LeftHand.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.82, 0.34, 0.82, 0.1, 0.03, 'top'), matSkin),
  );

  const RightUpperArm = makeJoint('RightUpperArm', UpperTorso);
  RightUpperArm.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.92, 0.84, 0.92, 0.12, 0.04, 'top'), matAccent),
  );
  const RightLowerArm = makeJoint('RightLowerArm', RightUpperArm);
  RightLowerArm.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.86, 0.78, 0.86, 0.12, 0.04, 'top'), matSkin),
  );
  const RightHand = makeJoint('RightHand', RightLowerArm);
  RightHand.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.82, 0.34, 0.82, 0.1, 0.03, 'top'), matSkin),
  );

  const LeftUpperLeg = makeJoint('LeftUpperLeg', LowerTorso);
  LeftUpperLeg.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.92, 0.87, 0.94, 0.12, 0.04, 'top'), matArmor),
  );
  const LeftLowerLeg = makeJoint('LeftLowerLeg', LeftUpperLeg);
  LeftLowerLeg.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.88, 0.87, 0.9, 0.12, 0.04, 'top'), matArmor),
  );
  const LeftFoot = makeJoint('LeftFoot', LeftLowerLeg);
  LeftFoot.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.92, 0.3, 1.06, 0.1, 0.03, 'top'), matAccent),
  );

  const RightUpperLeg = makeJoint('RightUpperLeg', LowerTorso);
  RightUpperLeg.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.92, 0.87, 0.94, 0.12, 0.04, 'top'), matArmor),
  );
  const RightLowerLeg = makeJoint('RightLowerLeg', RightUpperLeg);
  RightLowerLeg.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.88, 0.87, 0.9, 0.12, 0.04, 'top'), matArmor),
  );
  const RightFoot = makeJoint('RightFoot', RightLowerLeg);
  RightFoot.add(
    new THREE.Mesh(createChamferedBlockGeometry(0.92, 0.3, 1.06, 0.1, 0.03, 'top'), matAccent),
  );

  return {
    root,
    joints: {
      HumanoidRootPart,
      LowerTorso,
      UpperTorso,
      Head,
      LeftUpperArm,
      LeftLowerArm,
      LeftHand,
      RightUpperArm,
      RightLowerArm,
      RightHand,
      LeftUpperLeg,
      LeftLowerLeg,
      LeftFoot,
      RightUpperLeg,
      RightLowerLeg,
      RightFoot,
    },
  };
}
