import React, { useEffect, useMemo } from 'react';
import * as THREE from 'three';
import type { EvaluatedPose } from '../animation/types.ts';
import {
  R15_PIVOT_OFFSETS,
  createChamferedBlockGeometry,
} from './r15Geometry.ts';

interface R15GhostCharacterProps {
  pose: EvaluatedPose;
  color: string;
  opacity?: number;
}

const DEG2RAD = Math.PI / 180;

function toRad(v: [number, number, number]): [number, number, number] {
  return [v[0] * DEG2RAD, v[1] * DEG2RAD, v[2] * DEG2RAD];
}

export function R15GhostCharacter({
  pose,
  color,
  opacity = 0.24,
}: R15GhostCharacterProps) {
  const geos = useMemo(() => {
    return {
      lowerTorso: createChamferedBlockGeometry(1.9, 0.7, 1.0, 0.1, 0.04, 'center'),
      upperTorso: createChamferedBlockGeometry(2.0, 1.25, 1.05, 0.12, 0.05, 'bottom'),
      head: createChamferedBlockGeometry(1.12, 1.12, 1.12, 0.28, 0.06, 'bottom'),
      upperArm: createChamferedBlockGeometry(0.92, 0.84, 0.92, 0.12, 0.04, 'top'),
      lowerArm: createChamferedBlockGeometry(0.86, 0.78, 0.86, 0.12, 0.04, 'top'),
      hand: createChamferedBlockGeometry(0.82, 0.34, 0.82, 0.1, 0.03, 'top'),
      upperLeg: createChamferedBlockGeometry(0.92, 0.87, 0.94, 0.12, 0.04, 'top'),
      lowerLeg: createChamferedBlockGeometry(0.88, 0.87, 0.9, 0.12, 0.04, 'top'),
      foot: createChamferedBlockGeometry(0.92, 0.3, 1.06, 0.1, 0.03, 'top'),
    };
  }, []);

  const mat = useMemo(
    () =>
      new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity,
        depthWrite: false,
        wireframe: false,
      }),
    [color, opacity],
  );

  useEffect(() => {
    return () => {
      Object.values(geos).forEach((g) => g.dispose());
    };
  }, [geos]);

  useEffect(() => {
    return () => {
      mat.dispose();
    };
  }, [mat]);

  const base = R15_PIVOT_OFFSETS.HumanoidRootPart;
  const rootPos: [number, number, number] = [
    base[0] + pose.rootPosition[0],
    base[1] + pose.rootPosition[1],
    base[2] + pose.rootPosition[2],
  ];

  const j = pose.joints;

  return (
    <group position={rootPos} rotation={toRad(j.HumanoidRootPart)}>
      <group position={R15_PIVOT_OFFSETS.LowerTorso} rotation={toRad(j.LowerTorso)}>
        <mesh geometry={geos.lowerTorso} material={mat} />

        <group position={R15_PIVOT_OFFSETS.UpperTorso} rotation={toRad(j.UpperTorso)}>
          <mesh geometry={geos.upperTorso} material={mat} />

          <group position={R15_PIVOT_OFFSETS.Head} rotation={toRad(j.Head)}>
            <mesh geometry={geos.head} material={mat} position={[0, 0.06, 0]} />
          </group>

          <group position={R15_PIVOT_OFFSETS.LeftUpperArm} rotation={toRad(j.LeftUpperArm)}>
            <mesh geometry={geos.upperArm} material={mat} />
            <group position={R15_PIVOT_OFFSETS.LeftLowerArm} rotation={toRad(j.LeftLowerArm)}>
              <mesh geometry={geos.lowerArm} material={mat} />
              <group position={R15_PIVOT_OFFSETS.LeftHand} rotation={toRad(j.LeftHand)}>
                <mesh geometry={geos.hand} material={mat} />
              </group>
            </group>
          </group>

          <group position={R15_PIVOT_OFFSETS.RightUpperArm} rotation={toRad(j.RightUpperArm)}>
            <mesh geometry={geos.upperArm} material={mat} />
            <group position={R15_PIVOT_OFFSETS.RightLowerArm} rotation={toRad(j.RightLowerArm)}>
              <mesh geometry={geos.lowerArm} material={mat} />
              <group position={R15_PIVOT_OFFSETS.RightHand} rotation={toRad(j.RightHand)}>
                <mesh geometry={geos.hand} material={mat} />
              </group>
            </group>
          </group>
        </group>

        <group position={R15_PIVOT_OFFSETS.LeftUpperLeg} rotation={toRad(j.LeftUpperLeg)}>
          <mesh geometry={geos.upperLeg} material={mat} />
          <group position={R15_PIVOT_OFFSETS.LeftLowerLeg} rotation={toRad(j.LeftLowerLeg)}>
            <mesh geometry={geos.lowerLeg} material={mat} />
            <group position={R15_PIVOT_OFFSETS.LeftFoot} rotation={toRad(j.LeftFoot)}>
              <mesh geometry={geos.foot} material={mat} position={[0, 0, 0.06]} />
            </group>
          </group>
        </group>

        <group position={R15_PIVOT_OFFSETS.RightUpperLeg} rotation={toRad(j.RightUpperLeg)}>
          <mesh geometry={geos.upperLeg} material={mat} />
          <group position={R15_PIVOT_OFFSETS.RightLowerLeg} rotation={toRad(j.RightLowerLeg)}>
            <mesh geometry={geos.lowerLeg} material={mat} />
            <group position={R15_PIVOT_OFFSETS.RightFoot} rotation={toRad(j.RightFoot)}>
              <mesh geometry={geos.foot} material={mat} position={[0, 0, 0.06]} />
            </group>
          </group>
        </group>
      </group>
    </group>
  );
}
