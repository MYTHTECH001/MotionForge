import React, { useEffect, useMemo, useRef } from 'react';
import { useFrame, type ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';
import {
  R15_JOINT_NAMES,
  createNeutralPose,
  type EvaluatedPose,
  type Keyframe,
  type PropType,
  type R15JointName,
} from '../animation/types.ts';
import { evaluatePoseAtTime } from '../animation/interpolation.ts';
import {
  R15_PIVOT_OFFSETS,
  createChamferedBlockGeometry,
} from './r15Geometry.ts';

interface R15CharacterProps {
  keyframes: Keyframe[];
  duration: number;
  isPlaying: boolean;
  loop: boolean;
  playbackSpeed: number;
  currentTimeRef: React.MutableRefObject<number>;
  onTimeTick: (time: number, ended?: boolean) => void;
  selectedJoint: R15JointName | null;
  hoveredJoint: R15JointName | null;
  onSelectJoint: (joint: R15JointName) => void;
  onHoverJoint: (joint: R15JointName | null) => void;
  showSkeleton: boolean;
  prop: PropType;
  manualPoseOverride: EvaluatedPose | null;
  isDriver?: boolean;
}

const DEG2RAD = Math.PI / 180;

/**
 * Composite procedural Catching Net prop (7 parts: handle wrap, grip ring, shaft,
 * Y-collar, anodized hoop, inner rim, woven conical net basket).
 */
function NetProp() {
  const basketGeo = useMemo(() => {
    const pts = [
      new THREE.Vector2(0.58, 0.0),
      new THREE.Vector2(0.5, -0.35),
      new THREE.Vector2(0.32, -0.78),
      new THREE.Vector2(0.08, -1.05),
      new THREE.Vector2(0.0, -1.1),
    ];
    return new THREE.LatheGeometry(pts, 18);
  }, []);

  useEffect(() => () => basketGeo.dispose(), [basketGeo]);

  return (
    <group position={[0, -0.18, 0.15]} rotation={[Math.PI * 0.48, 0, 0]}>
      {/* Grip tape handle */}
      <mesh position={[0, 0.18, 0]} castShadow>
        <cylinderGeometry args={[0.075, 0.082, 0.62, 12]} />
        <meshStandardMaterial color="#1E293B" roughness={0.85} metalness={0.05} />
      </mesh>
      {/* Pommel cap */}
      <mesh position={[0, -0.14, 0]} castShadow>
        <cylinderGeometry args={[0.09, 0.07, 0.08, 12]} />
        <meshStandardMaterial color="#F59E0B" roughness={0.3} metalness={0.75} />
      </mesh>
      {/* Aluminum shaft */}
      <mesh position={[0, 1.15, 0]} castShadow>
        <cylinderGeometry args={[0.05, 0.055, 1.45, 12]} />
        <meshStandardMaterial color="#CBD5E1" roughness={0.25} metalness={0.85} />
      </mesh>
      {/* Y-neck collar */}
      <mesh position={[0, 1.88, 0]} castShadow>
        <cylinderGeometry args={[0.1, 0.065, 0.18, 12]} />
        <meshStandardMaterial color="#3B82F6" roughness={0.35} metalness={0.65} />
      </mesh>
      {/* Rim hoop */}
      <mesh position={[0, 2.54, 0]} rotation={[0, 0, 0]} castShadow>
        <torusGeometry args={[0.6, 0.045, 10, 28]} />
        <meshStandardMaterial color="#3B82F6" roughness={0.3} metalness={0.75} />
      </mesh>
      {/* Woven net basket */}
      <mesh
        geometry={basketGeo}
        position={[0, 2.54, 0]}
        rotation={[Math.PI / 2, 0, 0]}
        castShadow
      >
        <meshStandardMaterial
          color="#E2E8F0"
          roughness={0.85}
          metalness={0.0}
          wireframe
        />
      </mesh>
      {/* Subtle translucent mesh liner inside wireframe */}
      <mesh
        geometry={basketGeo}
        position={[0, 2.54, 0]}
        rotation={[Math.PI / 2, 0, 0]}
      >
        <meshStandardMaterial
          color="#93C5FD"
          roughness={0.75}
          metalness={0.05}
          transparent
          opacity={0.22}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}

/**
 * Composite procedural Sword prop (5 parts: pommel, leather grip, beveled crossguard,
 * core fuller, chamfered steel blade).
 */
function SwordProp() {
  const bladeGeo = useMemo(() => {
    const shape = new THREE.Shape();
    shape.moveTo(-0.075, 0);
    shape.lineTo(0.075, 0);
    shape.lineTo(0.058, 1.85);
    shape.lineTo(0, 2.25);
    shape.lineTo(-0.058, 1.85);
    shape.closePath();
    const g = new THREE.ExtrudeGeometry(shape, {
      depth: 0.03,
      bevelEnabled: true,
      bevelThickness: 0.015,
      bevelSize: 0.015,
      bevelSegments: 2,
    });
    g.translate(0, 0, -0.015);
    g.computeVertexNormals();
    return g;
  }, []);

  useEffect(() => () => bladeGeo.dispose(), [bladeGeo]);

  return (
    <group position={[0, -0.18, 0.14]} rotation={[Math.PI * 0.48, 0, 0]}>
      {/* Pommel */}
      <mesh position={[0, -0.14, 0]} castShadow>
        <octahedronGeometry args={[0.1, 1]} />
        <meshStandardMaterial color="#F59E0B" roughness={0.25} metalness={0.85} />
      </mesh>
      {/* Wrapped hilt */}
      <mesh position={[0, 0.14, 0]} castShadow>
        <cylinderGeometry args={[0.065, 0.072, 0.48, 12]} />
        <meshStandardMaterial color="#1E293B" roughness={0.88} metalness={0.05} />
      </mesh>
      {/* Crossguard */}
      <mesh position={[0, 0.4, 0]} castShadow>
        <boxGeometry args={[0.62, 0.1, 0.18]} />
        <meshStandardMaterial color="#F59E0B" roughness={0.28} metalness={0.82} />
      </mesh>
      {/* Steel blade */}
      <mesh geometry={bladeGeo} position={[0, 0.45, 0]} castShadow>
        <meshStandardMaterial color="#E2E8F0" roughness={0.18} metalness={0.92} />
      </mesh>
      {/* Fuller accent strip */}
      <mesh position={[0, 1.35, 0]}>
        <boxGeometry args={[0.032, 1.55, 0.068]} />
        <meshStandardMaterial color="#3B82F6" roughness={0.35} metalness={0.7} />
      </mesh>
    </group>
  );
}

export function R15Character({
  keyframes,
  duration,
  isPlaying,
  loop,
  playbackSpeed,
  currentTimeRef,
  onTimeTick,
  selectedJoint,
  hoveredJoint,
  onSelectJoint,
  onHoverJoint,
  showSkeleton,
  prop,
  manualPoseOverride,
  isDriver = true,
}: R15CharacterProps) {
  const jointRefs = useRef<Partial<Record<R15JointName, THREE.Group | null>>>({});
  const scratchPose = useRef<EvaluatedPose>(createNeutralPose());
  const uiSyncAcc = useRef(0);

  // Shared procedural chamfered geometries for all R15 segments
  const geos = useMemo(() => {
    return {
      lowerTorso: createChamferedBlockGeometry(1.9, 0.7, 1.0, 0.1, 0.04, 'center'),
      upperTorso: createChamferedBlockGeometry(2.0, 1.25, 1.05, 0.12, 0.05, 'bottom'),
      chestPlate: createChamferedBlockGeometry(1.5, 0.72, 0.18, 0.08, 0.025, 'center'),
      beltTrim: createChamferedBlockGeometry(1.98, 0.18, 1.08, 0.08, 0.02, 'center'),
      head: createChamferedBlockGeometry(1.12, 1.12, 1.12, 0.28, 0.06, 'bottom'),
      visor: createChamferedBlockGeometry(0.88, 0.34, 0.18, 0.08, 0.02, 'center'),
      upperArm: createChamferedBlockGeometry(0.92, 0.84, 0.92, 0.12, 0.04, 'top'),
      shoulderPad: createChamferedBlockGeometry(1.0, 0.28, 1.0, 0.12, 0.03, 'top'),
      lowerArm: createChamferedBlockGeometry(0.86, 0.78, 0.86, 0.12, 0.04, 'top'),
      hand: createChamferedBlockGeometry(0.82, 0.34, 0.82, 0.1, 0.03, 'top'),
      upperLeg: createChamferedBlockGeometry(0.92, 0.87, 0.94, 0.12, 0.04, 'top'),
      lowerLeg: createChamferedBlockGeometry(0.88, 0.87, 0.9, 0.12, 0.04, 'top'),
      foot: createChamferedBlockGeometry(0.92, 0.3, 1.06, 0.1, 0.03, 'top'),
      bootSole: createChamferedBlockGeometry(0.96, 0.1, 1.1, 0.08, 0.015, 'bottom'),
      jointCollar: new THREE.CylinderGeometry(0.28, 0.28, 0.12, 16),
      jointPin: new THREE.SphereGeometry(0.11, 14, 14),
    };
  }, []);

  useEffect(() => {
    return () => {
      Object.values(geos).forEach((g) => g.dispose());
    };
  }, [geos]);

  const setJointRef = (name: R15JointName) => (el: THREE.Group | null) => {
    jointRefs.current[name] = el;
    if (el) {
      el.userData.r15Joint = name;
    }
  };

  const handleJointClick = (joint: R15JointName) => (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    onSelectJoint(joint);
  };

  const handleJointOver = (joint: R15JointName) => (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    onHoverJoint(joint);
    document.body.style.cursor = 'pointer';
  };

  const handleJointOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    onHoverJoint(null);
    document.body.style.cursor = 'default';
  };

  // Helper to compute emissive tint when selected or hovered
  const emissiveFor = (joint: R15JointName): string => {
    if (selectedJoint === joint) return '#F59E0B';
    if (hoveredJoint === joint) return '#3B82F6';
    return '#000000';
  };
  const emissiveIntensityFor = (joint: R15JointName): number => {
    if (selectedJoint === joint) return 0.32;
    if (hoveredJoint === joint) return 0.18;
    return 0;
  };

  // Per-frame 60fps kinematic update
  useFrame((_state, delta) => {
    let t = currentTimeRef.current;

    if (isPlaying && isDriver) {
      const clampedDelta = Math.min(delta, 0.05);
      t += clampedDelta * playbackSpeed;
      let ended = false;
      if (t >= duration) {
        if (loop) {
          t = t % Math.max(0.01, duration);
        } else {
          t = duration;
          ended = true;
        }
      }
      currentTimeRef.current = t;
      uiSyncAcc.current += clampedDelta;
      if (uiSyncAcc.current >= 1 / 30 || ended) {
        uiSyncAcc.current = 0;
        onTimeTick(t, ended);
      }
    }

    const pose =
      manualPoseOverride ??
      evaluatePoseAtTime(keyframes, t, scratchPose.current, loop, duration);

    for (let i = 0; i < R15_JOINT_NAMES.length; i++) {
      const jName = R15_JOINT_NAMES[i];
      const group = jointRefs.current[jName];
      if (!group) continue;

      const rot = pose.joints[jName];
      group.rotation.set(
        rot[0] * DEG2RAD,
        rot[1] * DEG2RAD,
        rot[2] * DEG2RAD,
        'XYZ',
      );

      if (jName === 'HumanoidRootPart') {
        const base = R15_PIVOT_OFFSETS.HumanoidRootPart;
        group.position.set(
          base[0] + pose.rootPosition[0],
          base[1] + pose.rootPosition[1],
          base[2] + pose.rootPosition[2],
        );
      }
    }
  });

  const JointMarker = ({ joint }: { joint: R15JointName }) => {
    const isSelected = selectedJoint === joint;
    if (!showSkeleton && !isSelected) return null;
    return (
      <mesh
        geometry={geos.jointPin}
        renderOrder={20}
        onClick={handleJointClick(joint)}
        onPointerOver={handleJointOver(joint)}
        onPointerOut={handleJointOut}
      >
        <meshStandardMaterial
          color={isSelected ? '#F59E0B' : '#38BDF8'}
          emissive={isSelected ? '#F59E0B' : '#0284C7'}
          emissiveIntensity={isSelected ? 0.9 : 0.45}
          roughness={0.2}
          metalness={0.3}
          depthTest={!showSkeleton}
          transparent={showSkeleton}
          opacity={showSkeleton ? 0.92 : 1}
        />
      </mesh>
    );
  };

  return (
    <group
      ref={setJointRef('HumanoidRootPart')}
      position={R15_PIVOT_OFFSETS.HumanoidRootPart}
    >
      <JointMarker joint="HumanoidRootPart" />

      {/* LowerTorso (Pelvis) */}
      <group
        ref={setJointRef('LowerTorso')}
        position={R15_PIVOT_OFFSETS.LowerTorso}
      >
        <JointMarker joint="LowerTorso" />
        <mesh
          geometry={geos.lowerTorso}
          castShadow
          receiveShadow
          onClick={handleJointClick('LowerTorso')}
          onPointerOver={handleJointOver('LowerTorso')}
          onPointerOut={handleJointOut}
        >
          <meshStandardMaterial
            color="#263042"
            roughness={0.58}
            metalness={0.18}
            emissive={emissiveFor('LowerTorso')}
            emissiveIntensity={emissiveIntensityFor('LowerTorso')}
          />
        </mesh>
        {/* Belt trim accent */}
        <mesh geometry={geos.beltTrim} position={[0, 0.25, 0]} castShadow>
          <meshStandardMaterial color="#475569" roughness={0.28} metalness={0.72} />
        </mesh>

        {/* UpperTorso */}
        <group
          ref={setJointRef('UpperTorso')}
          position={R15_PIVOT_OFFSETS.UpperTorso}
        >
          <JointMarker joint="UpperTorso" />
          <mesh
            geometry={geos.upperTorso}
            castShadow
            receiveShadow
            onClick={handleJointClick('UpperTorso')}
            onPointerOver={handleJointOver('UpperTorso')}
            onPointerOut={handleJointOut}
          >
            <meshStandardMaterial
              color="#334155"
              roughness={0.46}
              metalness={0.22}
              emissive={emissiveFor('UpperTorso')}
              emissiveIntensity={emissiveIntensityFor('UpperTorso')}
            />
          </mesh>
          {/* Chest armor plate + core accent */}
          <mesh geometry={geos.chestPlate} position={[0, 0.74, 0.48]} castShadow>
            <meshStandardMaterial color="#1E293B" roughness={0.34} metalness={0.62} />
          </mesh>
          <mesh position={[0, 0.8, 0.59]} castShadow>
            <cylinderGeometry args={[0.14, 0.14, 0.06, 16]} />
            <meshStandardMaterial
              color="#3B82F6"
              emissive="#3B82F6"
              emissiveIntensity={0.45}
              roughness={0.2}
              metalness={0.4}
            />
          </mesh>

          {/* Neck + Head */}
          <group
            ref={setJointRef('Head')}
            position={R15_PIVOT_OFFSETS.Head}
          >
            <JointMarker joint="Head" />
            {/* Neck collar */}
            <mesh geometry={geos.jointCollar} position={[0, 0.02, 0]}>
              <meshStandardMaterial color="#475569" roughness={0.28} metalness={0.78} />
            </mesh>
            {/* Sculpted Head block */}
            <mesh
              geometry={geos.head}
              position={[0, 0.06, 0]}
              castShadow
              receiveShadow
              onClick={handleJointClick('Head')}
              onPointerOver={handleJointOver('Head')}
              onPointerOut={handleJointOut}
            >
              <meshStandardMaterial
                color="#E2B98F"
                roughness={0.68}
                metalness={0.04}
                emissive={emissiveFor('Head')}
                emissiveIntensity={emissiveIntensityFor('Head')}
              />
            </mesh>
            {/* Studio Visor + Eyes (indicates +Z facing direction clearly) */}
            <mesh
              geometry={geos.visor}
              position={[0, 0.66, 0.54]}
              castShadow
              onClick={handleJointClick('Head')}
            >
              <meshStandardMaterial
                color="#0F172A"
                roughness={0.14}
                metalness={0.82}
              />
            </mesh>
            {/* Left & Right glowing eye optics */}
            <mesh position={[0.2, 0.66, 0.63]}>
              <boxGeometry args={[0.16, 0.08, 0.03]} />
              <meshStandardMaterial
                color="#60A5FA"
                emissive="#3B82F6"
                emissiveIntensity={0.85}
                roughness={0.2}
              />
            </mesh>
            <mesh position={[-0.2, 0.66, 0.63]}>
              <boxGeometry args={[0.16, 0.08, 0.03]} />
              <meshStandardMaterial
                color="#60A5FA"
                emissive="#3B82F6"
                emissiveIntensity={0.85}
                roughness={0.2}
              />
            </mesh>
          </group>

          {/* Left Arm Chain */}
          <group
            ref={setJointRef('LeftUpperArm')}
            position={R15_PIVOT_OFFSETS.LeftUpperArm}
          >
            <JointMarker joint="LeftUpperArm" />
            <mesh
              geometry={geos.upperArm}
              castShadow
              receiveShadow
              onClick={handleJointClick('LeftUpperArm')}
              onPointerOver={handleJointOver('LeftUpperArm')}
              onPointerOut={handleJointOut}
            >
              <meshStandardMaterial
                color="#3B82F6"
                roughness={0.42}
                metalness={0.28}
                emissive={emissiveFor('LeftUpperArm')}
                emissiveIntensity={emissiveIntensityFor('LeftUpperArm')}
              />
            </mesh>
            <mesh geometry={geos.shoulderPad} position={[0, 0.02, 0]} castShadow>
              <meshStandardMaterial color="#1E293B" roughness={0.3} metalness={0.68} />
            </mesh>

            <group
              ref={setJointRef('LeftLowerArm')}
              position={R15_PIVOT_OFFSETS.LeftLowerArm}
            >
              <JointMarker joint="LeftLowerArm" />
              <mesh
                geometry={geos.lowerArm}
                castShadow
                receiveShadow
                onClick={handleJointClick('LeftLowerArm')}
                onPointerOver={handleJointOver('LeftLowerArm')}
                onPointerOut={handleJointOut}
              >
                <meshStandardMaterial
                  color="#E2B98F"
                  roughness={0.68}
                  metalness={0.04}
                  emissive={emissiveFor('LeftLowerArm')}
                  emissiveIntensity={emissiveIntensityFor('LeftLowerArm')}
                />
              </mesh>

              <group
                ref={setJointRef('LeftHand')}
                position={R15_PIVOT_OFFSETS.LeftHand}
              >
                <JointMarker joint="LeftHand" />
                <mesh
                  geometry={geos.hand}
                  castShadow
                  receiveShadow
                  onClick={handleJointClick('LeftHand')}
                  onPointerOver={handleJointOver('LeftHand')}
                  onPointerOut={handleJointOut}
                >
                  <meshStandardMaterial
                    color="#D4A67A"
                    roughness={0.72}
                    metalness={0.04}
                    emissive={emissiveFor('LeftHand')}
                    emissiveIntensity={emissiveIntensityFor('LeftHand')}
                  />
                </mesh>
              </group>
            </group>
          </group>

          {/* Right Arm Chain */}
          <group
            ref={setJointRef('RightUpperArm')}
            position={R15_PIVOT_OFFSETS.RightUpperArm}
          >
            <JointMarker joint="RightUpperArm" />
            <mesh
              geometry={geos.upperArm}
              castShadow
              receiveShadow
              onClick={handleJointClick('RightUpperArm')}
              onPointerOver={handleJointOver('RightUpperArm')}
              onPointerOut={handleJointOut}
            >
              <meshStandardMaterial
                color="#3B82F6"
                roughness={0.42}
                metalness={0.28}
                emissive={emissiveFor('RightUpperArm')}
                emissiveIntensity={emissiveIntensityFor('RightUpperArm')}
              />
            </mesh>
            <mesh geometry={geos.shoulderPad} position={[0, 0.02, 0]} castShadow>
              <meshStandardMaterial color="#1E293B" roughness={0.3} metalness={0.68} />
            </mesh>

            <group
              ref={setJointRef('RightLowerArm')}
              position={R15_PIVOT_OFFSETS.RightLowerArm}
            >
              <JointMarker joint="RightLowerArm" />
              <mesh
                geometry={geos.lowerArm}
                castShadow
                receiveShadow
                onClick={handleJointClick('RightLowerArm')}
                onPointerOver={handleJointOver('RightLowerArm')}
                onPointerOut={handleJointOut}
              >
                <meshStandardMaterial
                  color="#E2B98F"
                  roughness={0.68}
                  metalness={0.04}
                  emissive={emissiveFor('RightLowerArm')}
                  emissiveIntensity={emissiveIntensityFor('RightLowerArm')}
                />
              </mesh>

              <group
                ref={setJointRef('RightHand')}
                position={R15_PIVOT_OFFSETS.RightHand}
              >
                <JointMarker joint="RightHand" />
                <mesh
                  geometry={geos.hand}
                  castShadow
                  receiveShadow
                  onClick={handleJointClick('RightHand')}
                  onPointerOver={handleJointOver('RightHand')}
                  onPointerOut={handleJointOut}
                >
                  <meshStandardMaterial
                    color="#D4A67A"
                    roughness={0.72}
                    metalness={0.04}
                    emissive={emissiveFor('RightHand')}
                    emissiveIntensity={emissiveIntensityFor('RightHand')}
                  />
                </mesh>

                {prop === 'net' && <NetProp />}
                {prop === 'sword' && <SwordProp />}
              </group>
            </group>
          </group>
        </group>

        {/* Left Leg Chain */}
        <group
          ref={setJointRef('LeftUpperLeg')}
          position={R15_PIVOT_OFFSETS.LeftUpperLeg}
        >
          <JointMarker joint="LeftUpperLeg" />
          <mesh
            geometry={geos.upperLeg}
            castShadow
            receiveShadow
            onClick={handleJointClick('LeftUpperLeg')}
            onPointerOver={handleJointOver('LeftUpperLeg')}
            onPointerOut={handleJointOut}
          >
            <meshStandardMaterial
              color="#1E293B"
              roughness={0.55}
              metalness={0.18}
              emissive={emissiveFor('LeftUpperLeg')}
              emissiveIntensity={emissiveIntensityFor('LeftUpperLeg')}
            />
          </mesh>

          <group
            ref={setJointRef('LeftLowerLeg')}
            position={R15_PIVOT_OFFSETS.LeftLowerLeg}
          >
            <JointMarker joint="LeftLowerLeg" />
            <mesh
              geometry={geos.lowerLeg}
              castShadow
              receiveShadow
              onClick={handleJointClick('LeftLowerLeg')}
              onPointerOver={handleJointOver('LeftLowerLeg')}
              onPointerOut={handleJointOut}
            >
              <meshStandardMaterial
                color="#273244"
                roughness={0.5}
                metalness={0.22}
                emissive={emissiveFor('LeftLowerLeg')}
                emissiveIntensity={emissiveIntensityFor('LeftLowerLeg')}
              />
            </mesh>

            <group
              ref={setJointRef('LeftFoot')}
              position={R15_PIVOT_OFFSETS.LeftFoot}
            >
              <JointMarker joint="LeftFoot" />
              <mesh
                geometry={geos.foot}
                position={[0, 0, 0.06]}
                castShadow
                receiveShadow
                onClick={handleJointClick('LeftFoot')}
                onPointerOver={handleJointOver('LeftFoot')}
                onPointerOut={handleJointOut}
              >
                <meshStandardMaterial
                  color="#334155"
                  roughness={0.4}
                  metalness={0.35}
                  emissive={emissiveFor('LeftFoot')}
                  emissiveIntensity={emissiveIntensityFor('LeftFoot')}
                />
              </mesh>
              <mesh geometry={geos.bootSole} position={[0, -0.3, 0.06]} castShadow>
                <meshStandardMaterial color="#0F172A" roughness={0.88} metalness={0.05} />
              </mesh>
            </group>
          </group>
        </group>

        {/* Right Leg Chain */}
        <group
          ref={setJointRef('RightUpperLeg')}
          position={R15_PIVOT_OFFSETS.RightUpperLeg}
        >
          <JointMarker joint="RightUpperLeg" />
          <mesh
            geometry={geos.upperLeg}
            castShadow
            receiveShadow
            onClick={handleJointClick('RightUpperLeg')}
            onPointerOver={handleJointOver('RightUpperLeg')}
            onPointerOut={handleJointOut}
          >
            <meshStandardMaterial
              color="#1E293B"
              roughness={0.55}
              metalness={0.18}
              emissive={emissiveFor('RightUpperLeg')}
              emissiveIntensity={emissiveIntensityFor('RightUpperLeg')}
            />
          </mesh>

          <group
            ref={setJointRef('RightLowerLeg')}
            position={R15_PIVOT_OFFSETS.RightLowerLeg}
          >
            <JointMarker joint="RightLowerLeg" />
            <mesh
              geometry={geos.lowerLeg}
              castShadow
              receiveShadow
              onClick={handleJointClick('RightLowerLeg')}
              onPointerOver={handleJointOver('RightLowerLeg')}
              onPointerOut={handleJointOut}
            >
              <meshStandardMaterial
                color="#273244"
                roughness={0.5}
                metalness={0.22}
                emissive={emissiveFor('RightLowerLeg')}
                emissiveIntensity={emissiveIntensityFor('RightLowerLeg')}
              />
            </mesh>

            <group
              ref={setJointRef('RightFoot')}
              position={R15_PIVOT_OFFSETS.RightFoot}
            >
              <JointMarker joint="RightFoot" />
              <mesh
                geometry={geos.foot}
                position={[0, 0, 0.06]}
                castShadow
                receiveShadow
                onClick={handleJointClick('RightFoot')}
                onPointerOver={handleJointOver('RightFoot')}
                onPointerOut={handleJointOut}
              >
                <meshStandardMaterial
                  color="#334155"
                  roughness={0.4}
                  metalness={0.35}
                  emissive={emissiveFor('RightFoot')}
                  emissiveIntensity={emissiveIntensityFor('RightFoot')}
                />
              </mesh>
              <mesh geometry={geos.bootSole} position={[0, -0.3, 0.06]} castShadow>
                <meshStandardMaterial color="#0F172A" roughness={0.88} metalness={0.05} />
              </mesh>
            </group>
          </group>
        </group>
      </group>
    </group>
  );
}
