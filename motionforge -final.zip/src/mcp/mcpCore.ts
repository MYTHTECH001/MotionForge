import {
  R15_JOINT_META,
  R15_JOINT_NAMES,
  type AnimationProject,
  type PropType,
} from '../animation/types.ts';
import { ANIMATION_PRESETS } from '../animation/presets.ts';
import { evaluatePoseAtTime } from '../animation/interpolation.ts';
import { validateAnimationPayload } from '../animation/validator.ts';
import { R15_PIVOT_OFFSETS } from '../rig/r15Geometry.ts';
import { buildFBXAscii } from '../export/fbxExporter.ts';
import {
  generateAnimationFromPrompt,
  isGeminiConfigured,
} from '../server/geminiGenerator.ts';

export const MCP_PROTOCOL_VERSIONS = ['2025-03-26', '2024-11-05'] as const;

export interface SharedWorkspaceClip {
  id: string;
  source: 'mcp' | 'studio';
  updatedAt: string;
  project: AnimationProject;
}

const MAX_MCP_SESSIONS = 250;
const sessionWorkspaces = new Map<string, Map<string, SharedWorkspaceClip>>();

function normalizeSessionId(sessionId?: string): string {
  const trimmed = sessionId?.trim();
  return trimmed && trimmed.length > 0 ? trimmed.slice(0, 128) : 'default';
}

function getSessionClipMap(sessionId?: string): Map<string, SharedWorkspaceClip> {
  const key = normalizeSessionId(sessionId);
  let map = sessionWorkspaces.get(key);
  if (!map) {
    if (sessionWorkspaces.size >= MAX_MCP_SESSIONS) {
      const oldestKey = sessionWorkspaces.keys().next().value;
      if (oldestKey !== undefined) {
        sessionWorkspaces.delete(oldestKey);
      }
    }
    map = new Map<string, SharedWorkspaceClip>();
    sessionWorkspaces.set(key, map);
  }
  return map;
}

function makeClipId(name: string): string {
  const slug =
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'clip';
  return `${slug}-${Date.now().toString(36).slice(-4)}`;
}

export function listSharedWorkspaceClips(
  sessionId?: string,
): SharedWorkspaceClip[] {
  const map = getSessionClipMap(sessionId);
  return Array.from(map.values()).sort((a, b) =>
    b.updatedAt.localeCompare(a.updatedAt),
  );
}

export function saveSharedWorkspaceClip(
  project: AnimationProject,
  id?: string,
  source: 'mcp' | 'studio' = 'mcp',
  sessionId?: string,
): SharedWorkspaceClip {
  const map = getSessionClipMap(sessionId);
  const clipId = (id && id.trim()) || makeClipId(project.name);
  const entry: SharedWorkspaceClip = {
    id: clipId,
    source,
    updatedAt: new Date().toISOString(),
    project: structuredClone(project),
  };
  map.set(clipId, entry);
  return entry;
}

export function getSharedWorkspaceClip(
  id: string,
  sessionId?: string,
): SharedWorkspaceClip | undefined {
  return getSessionClipMap(sessionId).get(id);
}

export function deleteSharedWorkspaceClip(
  id: string,
  sessionId?: string,
): boolean {
  return getSessionClipMap(sessionId).delete(id);
}

export function deleteSharedWorkspaceSession(sessionId: string): boolean {
  return sessionWorkspaces.delete(normalizeSessionId(sessionId));
}

export interface JsonRpcRequest {
  jsonrpc?: string;
  id?: string | number | null;
  method: string;
  params?: Record<string, unknown>;
}

export interface JsonRpcResponse {
  jsonrpc: '2.0';
  id: string | number | null;
  result?: unknown;
  error?: {
    code: number;
    message: string;
    data?: unknown;
  };
}

export const MCP_TOOLS = [
  {
    name: 'list_r15_joints',
    description:
      'Returns the 16 Roblox R15 joint names, Motor6D names, hierarchy pivot offsets (studs), and local Euler rotation conventions.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'list_presets',
    description:
      'Lists built-in MotionForge R15 animation presets with IDs, durations, props, and keyframe counts.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'get_preset',
    description:
      'Returns the complete validated AnimationProject JSON for a built-in preset ID.',
    inputSchema: {
      type: 'object',
      properties: {
        presetId: {
          type: 'string',
          description:
            'Preset ID (e.g. net-swing, sword-attack, jumping, waving, dancing, celebration)',
        },
      },
      required: ['presetId'],
    },
  },
  {
    name: 'generate_animation',
    description:
      'Generates a structured Roblox R15 keyframe animation from a natural-language prompt using Gemini (0.3s to 30s). Optionally saves it into the shared MotionForge MCP workspace so it can be opened in the 3D editor.',
    inputSchema: {
      type: 'object',
      properties: {
        prompt: {
          type: 'string',
          description: 'Natural-language description of the R15 animation',
        },
        duration: {
          type: 'number',
          description: 'Duration in seconds (0.3 to 30, default 2.0)',
        },
        prop: {
          type: 'string',
          enum: ['auto', 'none', 'net', 'sword'],
          description: 'Hand prop attached to RightHand',
        },
        loop: {
          type: 'boolean',
          description: 'Whether start and end poses should loop seamlessly',
        },
        saveToWorkspace: {
          type: 'boolean',
          description:
            'If true, stores the generated clip in the shared MotionForge workspace (default true)',
        },
      },
      required: ['prompt'],
    },
  },
  {
    name: 'validate_animation',
    description:
      'Validates and normalizes a MotionForge AnimationProject JSON payload against the R15 joint and keyframe schema.',
    inputSchema: {
      type: 'object',
      properties: {
        project: {
          type: 'object',
          description: 'Raw AnimationProject JSON object to validate',
        },
      },
      required: ['project'],
    },
  },
  {
    name: 'evaluate_pose',
    description:
      'Evaluates the interpolated 16-joint R15 Euler pose and rootPosition at a given timestamp in seconds.',
    inputSchema: {
      type: 'object',
      properties: {
        time: {
          type: 'number',
          description: 'Timestamp in seconds',
        },
        project: {
          type: 'object',
          description: 'AnimationProject object (optional if clipId or presetId given)',
        },
        clipId: {
          type: 'string',
          description: 'ID of a clip in the shared MCP workspace',
        },
        presetId: {
          type: 'string',
          description: 'Built-in preset ID',
        },
      },
      required: ['time'],
    },
  },
  {
    name: 'export_fbx',
    description:
      'Exports an R15 animation as an ASCII FBX 7.4 skeletal animation file containing the 16-bone LimbNode hierarchy and baked per-frame XYZ AnimationCurves.',
    inputSchema: {
      type: 'object',
      properties: {
        project: {
          type: 'object',
          description: 'AnimationProject object (optional if clipId or presetId given)',
        },
        clipId: {
          type: 'string',
          description: 'ID of a clip in the shared MCP workspace',
        },
        presetId: {
          type: 'string',
          description: 'Built-in preset ID',
        },
      },
    },
  },
  {
    name: 'save_clip',
    description:
      'Saves a validated AnimationProject JSON into the shared MotionForge workspace so the user can open and edit it in the 3D viewport.',
    inputSchema: {
      type: 'object',
      properties: {
        id: {
          type: 'string',
          description: 'Optional custom clip ID (overwrites if existing)',
        },
        project: {
          type: 'object',
          description: 'AnimationProject JSON to save',
        },
      },
      required: ['project'],
    },
  },
  {
    name: 'list_clips',
    description:
      'Lists all animation clips currently stored in the shared MotionForge MCP workspace.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'get_clip',
    description:
      'Retrieves the full AnimationProject JSON for a clip ID from the shared MotionForge MCP workspace.',
    inputSchema: {
      type: 'object',
      properties: {
        clipId: {
          type: 'string',
          description: 'Workspace clip ID',
        },
      },
      required: ['clipId'],
    },
  },
] as const;

function resolveProjectArg(
  args: Record<string, unknown>,
  sessionId?: string,
): AnimationProject {
  if (typeof args.clipId === 'string' && args.clipId.trim()) {
    const clip = getSharedWorkspaceClip(args.clipId.trim(), sessionId);
    if (!clip) {
      throw new Error(`Workspace clip "${args.clipId}" not found.`);
    }
    return clip.project;
  }

  if (typeof args.presetId === 'string' && args.presetId.trim()) {
    const preset = ANIMATION_PRESETS.find((p) => p.id === args.presetId);
    if (!preset) {
      throw new Error(`Preset "${args.presetId}" not found.`);
    }
    return preset.project;
  }

  if (args.project && typeof args.project === 'object') {
    const validation = validateAnimationPayload(args.project);
    if (!validation.valid || !validation.project) {
      throw new Error(
        `Invalid AnimationProject: ${validation.errors.join(' ')}`,
      );
    }
    return validation.project;
  }

  throw new Error(
    'Provide one of "project", "clipId", or "presetId".',
  );
}

function okToolText(payload: unknown) {
  return {
    content: [
      {
        type: 'text',
        text:
          typeof payload === 'string'
            ? payload
            : JSON.stringify(payload, null, 2),
      },
    ],
  };
}

function errToolText(message: string) {
  return {
    isError: true,
    content: [{ type: 'text', text: message }],
  };
}

async function executeTool(
  name: string,
  args: Record<string, unknown>,
  sessionId?: string,
): Promise<unknown> {
  switch (name) {
    case 'list_r15_joints': {
      return okToolText({
        joints: R15_JOINT_NAMES.map((j) => ({
          name: j,
          motorName: R15_JOINT_META[j].motorName,
          category: R15_JOINT_META[j].category,
          pivotOffset: R15_PIVOT_OFFSETS[j],
        })),
        conventions: {
          eulerOrder: 'XYZ',
          units: 'degrees',
          upAxis: '+Y',
          frontAxis: '+Z',
          leftSide: '+X',
          rightSide: '-X',
        },
      });
    }

    case 'list_presets': {
      return okToolText({
        presets: ANIMATION_PRESETS.map((p) => ({
          id: p.id,
          label: p.label,
          summary: p.summary,
          duration: p.project.duration,
          fps: p.project.fps,
          loop: p.project.loop,
          prop: p.project.prop,
          keyframeCount: p.project.keyframes.length,
        })),
      });
    }

    case 'get_preset': {
      const presetId = typeof args.presetId === 'string' ? args.presetId : '';
      const preset = ANIMATION_PRESETS.find((p) => p.id === presetId);
      if (!preset) {
        return errToolText(
          `Preset "${presetId}" not found. Available IDs: ${ANIMATION_PRESETS.map((p) => p.id).join(', ')}`,
        );
      }
      return okToolText(preset.project);
    }

    case 'generate_animation': {
      const prompt = typeof args.prompt === 'string' ? args.prompt : '';
      const duration =
        typeof args.duration === 'number' ? args.duration : 2.0;
      const prop =
        args.prop === 'net' ||
        args.prop === 'sword' ||
        args.prop === 'none' ||
        args.prop === 'auto'
          ? (args.prop as PropType | 'auto')
          : 'auto';
      const loop = typeof args.loop === 'boolean' ? args.loop : true;
      const saveToWorkspace =
        typeof args.saveToWorkspace === 'boolean'
          ? args.saveToWorkspace
          : true;

      if (!isGeminiConfigured()) {
        return errToolText(
          'GEMINI_API_KEY is not configured on the server. Use list_presets / get_preset / save_clip / export_fbx or configure GEMINI_API_KEY.',
        );
      }

      const result = await generateAnimationFromPrompt({
        prompt,
        duration,
        prop,
        loop,
      });

      const saved = saveToWorkspace
        ? saveSharedWorkspaceClip(result.project, undefined, 'mcp', sessionId)
        : null;

      return okToolText({
        clipId: saved?.id ?? null,
        warnings: result.warnings,
        project: result.project,
      });
    }

    case 'validate_animation': {
      const validation = validateAnimationPayload(args.project);
      if (!validation.valid || !validation.project) {
        return errToolText(
          `Validation failed: ${validation.errors.join(' ')}`,
        );
      }
      return okToolText({
        valid: true,
        warnings: validation.warnings,
        project: validation.project,
      });
    }

    case 'evaluate_pose': {
      const time = Number(args.time);
      if (!Number.isFinite(time)) {
        return errToolText('Parameter "time" must be a finite number.');
      }
      const project = resolveProjectArg(args, sessionId);
      const pose = evaluatePoseAtTime(
        project.keyframes,
        time,
        undefined,
        project.loop,
        project.duration,
      );
      return okToolText({
        projectName: project.name,
        time: Math.max(0, Math.min(project.duration, time)),
        pose,
      });
    }

    case 'export_fbx': {
      const project = resolveProjectArg(args, sessionId);
      const fbxAscii = buildFBXAscii(project);
      return okToolText({
        format: 'fbx-7.4-ascii',
        filename: `${
          project.name
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-|-$/g, '') || 'motionforge-animation'
        }.fbx`,
        byteLength: new TextEncoder().encode(fbxAscii).byteLength,
        fbxAscii,
      });
    }

    case 'save_clip': {
      const validation = validateAnimationPayload(args.project);
      if (!validation.valid || !validation.project) {
        return errToolText(
          `Invalid project JSON: ${validation.errors.join(' ')}`,
        );
      }
      const customId = typeof args.id === 'string' ? args.id : undefined;
      const saved = saveSharedWorkspaceClip(
        validation.project,
        customId,
        'mcp',
        sessionId,
      );
      return okToolText({
        saved: true,
        clipId: saved.id,
        updatedAt: saved.updatedAt,
        name: saved.project.name,
        duration: saved.project.duration,
        keyframes: saved.project.keyframes.length,
      });
    }

    case 'list_clips': {
      return okToolText({
        clips: listSharedWorkspaceClips(sessionId).map((c) => ({
          id: c.id,
          name: c.project.name,
          duration: c.project.duration,
          fps: c.project.fps,
          prop: c.project.prop,
          keyframes: c.project.keyframes.length,
          source: c.source,
          updatedAt: c.updatedAt,
        })),
      });
    }

    case 'get_clip': {
      const clipId = typeof args.clipId === 'string' ? args.clipId : '';
      const clip = getSharedWorkspaceClip(clipId, sessionId);
      if (!clip) {
        return errToolText(`Workspace clip "${clipId}" not found.`);
      }
      return okToolText(clip);
    }

    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}

export async function handleMcpJsonRpc(
  msg: JsonRpcRequest,
  sessionId = 'default',
): Promise<JsonRpcResponse | null> {
  const isNotification = msg.id === undefined || (msg.id === null && !('id' in msg));

  if (!msg || typeof msg.method !== 'string') {
    if (isNotification) return null;
    return {
      jsonrpc: '2.0',
      id: msg?.id ?? null,
      error: { code: -32600, message: 'Invalid JSON-RPC Request' },
    };
  }

  // Notifications require no JSON-RPC response body
  if (msg.method.startsWith('notifications/') || msg.id === undefined) {
    return null;
  }

  const id = msg.id;
  const params =
    msg.params && typeof msg.params === 'object' ? msg.params : {};

  try {
    switch (msg.method) {
      case 'initialize': {
        const clientVersion =
          typeof params.protocolVersion === 'string'
            ? params.protocolVersion
            : '2025-03-26';
        const negotiated = (
          MCP_PROTOCOL_VERSIONS as readonly string[]
        ).includes(clientVersion)
          ? clientVersion
          : '2025-03-26';

        return {
          jsonrpc: '2.0',
          id,
          result: {
            protocolVersion: negotiated,
            capabilities: {
              tools: { listChanged: false },
              resources: { listChanged: false },
            },
            serverInfo: {
              name: 'motionforge-r15',
              version: '2.0.0',
            },
            instructions:
              'MotionForge R15 MCP Server: generate, validate, inspect, evaluate, and export Roblox R15 skeletal animations (JSON & ASCII FBX 7.4).',
          },
        };
      }

      case 'ping':
        return { jsonrpc: '2.0', id, result: {} };

      case 'tools/list':
        return {
          jsonrpc: '2.0',
          id,
          result: { tools: MCP_TOOLS },
        };

      case 'tools/call': {
        const toolName = typeof params.name === 'string' ? params.name : '';
        const toolArgs =
          params.arguments && typeof params.arguments === 'object'
            ? (params.arguments as Record<string, unknown>)
            : {};

        if (!MCP_TOOLS.some((t) => t.name === toolName)) {
          return {
            jsonrpc: '2.0',
            id,
            error: { code: -32602, message: `Unknown tool: ${toolName}` },
          };
        }

        try {
          const result = await executeTool(toolName, toolArgs, sessionId);
          return { jsonrpc: '2.0', id, result };
        } catch (toolErr: unknown) {
          const errMsg =
            toolErr instanceof Error ? toolErr.message : String(toolErr);
          return {
            jsonrpc: '2.0',
            id,
            result: errToolText(errMsg),
          };
        }
      }

      case 'resources/list': {
        return {
          jsonrpc: '2.0',
          id,
          result: {
            resources: [
              {
                uri: 'motionforge://r15/schema',
                name: 'Roblox R15 Rig & Animation Schema',
                description:
                  '16-joint R15 skeleton offsets, Motor6D mappings, and coordinate conventions',
                mimeType: 'application/json',
              },
              {
                uri: 'motionforge://presets',
                name: 'Built-in R15 Animation Presets',
                description:
                  'List of built-in MotionForge animation presets',
                mimeType: 'application/json',
              },
            ],
          },
        };
      }

      case 'resources/read': {
        const uri = typeof params.uri === 'string' ? params.uri : '';
        if (uri === 'motionforge://r15/schema') {
          return {
            jsonrpc: '2.0',
            id,
            result: {
              contents: [
                {
                  uri,
                  mimeType: 'application/json',
                  text: JSON.stringify(
                    {
                      joints: R15_JOINT_NAMES.map((j) => ({
                        name: j,
                        motorName: R15_JOINT_META[j].motorName,
                        pivotOffset: R15_PIVOT_OFFSETS[j],
                      })),
                      durationRangeSeconds: [0.2, 30],
                      easingModes: [
                        'easeInOut',
                        'easeIn',
                        'easeOut',
                        'linear',
                        'constant',
                        'bounce',
                        'elastic',
                      ],
                      props: ['none', 'net', 'sword'],
                    },
                    null,
                    2,
                  ),
                },
              ],
            },
          };
        }
        if (uri === 'motionforge://presets') {
          return {
            jsonrpc: '2.0',
            id,
            result: {
              contents: [
                {
                  uri,
                  mimeType: 'application/json',
                  text: JSON.stringify(ANIMATION_PRESETS, null, 2),
                },
              ],
            },
          };
        }
        return {
          jsonrpc: '2.0',
          id,
          error: { code: -32002, message: `Resource not found: ${uri}` },
        };
      }

      default:
        return {
          jsonrpc: '2.0',
          id,
          error: { code: -32601, message: `Method not found: ${msg.method}` },
        };
    }
  } catch (err: unknown) {
    return {
      jsonrpc: '2.0',
      id,
      error: {
        code: -32603,
        message: err instanceof Error ? err.message : 'Internal server error',
      },
    };
  }
}
