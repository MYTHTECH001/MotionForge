import * as THREE from 'three';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import {
  R15_JOINT_NAMES,
  createNeutralPose,
  type AnimationProject,
} from '../animation/types.ts';
import { evaluatePoseAtTime } from '../animation/interpolation.ts';
import {
  R15_PIVOT_OFFSETS,
  buildExportableR15Group,
} from '../rig/r15Geometry.ts';
import { buildFBXAscii } from './fbxExporter.ts';

function slugify(name: string): string {
  return (
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'motionforge-animation'
  );
}

function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/**
 * Exports the complete MotionForge animation project as formatted JSON
 * for full round-trip saving and loading.
 */
export function exportProjectJSON(project: AnimationProject): void {
  const payload = {
    ...project,
    exportedAt: new Date().toISOString(),
    generator: 'MotionForge R15 Studio',
  };
  const json = JSON.stringify(payload, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  triggerDownload(blob, `${slugify(project.name)}.motionforge.json`);
}

/**
 * Compiles the MotionForge R15 keyframes into a Three.js AnimationClip
 * with QuaternionKeyframeTracks and a HumanoidRootPart position track.
 */
export function buildThreeAnimationClip(
  project: AnimationProject,
): THREE.AnimationClip {
  const sorted = [...project.keyframes].sort((a, b) => a.time - b.time);
  const sampleCount = Math.max(2, Math.round(project.duration * project.fps) + 1);
  const times: number[] = [];
  for (let i = 0; i < sampleCount; i++) {
    const t = (i / (sampleCount - 1)) * project.duration;
    times.push(Number(t.toFixed(4)));
  }

  const jointValues: Record<string, number[]> = {};
  for (const j of R15_JOINT_NAMES) {
    jointValues[j] = [];
  }
  const rootPosValues: number[] = [];

  const poseScratch = createNeutralPose();
  const euler = new THREE.Euler();
  const quat = new THREE.Quaternion();
  const DEG2RAD = Math.PI / 180;
  const baseRoot = R15_PIVOT_OFFSETS.HumanoidRootPart;

  for (let i = 0; i < times.length; i++) {
    const pose = evaluatePoseAtTime(
      sorted,
      times[i],
      poseScratch,
      project.loop,
      project.duration,
    );
    for (const j of R15_JOINT_NAMES) {
      const r = pose.joints[j];
      euler.set(r[0] * DEG2RAD, r[1] * DEG2RAD, r[2] * DEG2RAD, 'XYZ');
      quat.setFromEuler(euler);
      jointValues[j].push(quat.x, quat.y, quat.z, quat.w);
    }
    rootPosValues.push(
      baseRoot[0] + pose.rootPosition[0],
      baseRoot[1] + pose.rootPosition[1],
      baseRoot[2] + pose.rootPosition[2],
    );
  }

  const tracks: THREE.KeyframeTrack[] = [
    new THREE.VectorKeyframeTrack(
      'HumanoidRootPart.position',
      times,
      rootPosValues,
    ),
  ];

  for (const j of R15_JOINT_NAMES) {
    tracks.push(
      new THREE.QuaternionKeyframeTrack(
        `${j}.quaternion`,
        times,
        jointValues[j],
      ),
    );
  }

  return new THREE.AnimationClip(project.name, project.duration, tracks);
}

/**
 * Exports the articulated R15 rig + compiled skeletal AnimationClip as a standard binary .glb file.
 */
export async function exportGLBAnimation(
  project: AnimationProject,
): Promise<number> {
  const { root } = buildExportableR15Group();
  const clip = buildThreeAnimationClip(project);
  const exporter = new GLTFExporter();

  const glbBuffer = await new Promise<ArrayBuffer>((resolve, reject) => {
    exporter.parse(
      root,
      (result) => {
        if (result instanceof ArrayBuffer) {
          resolve(result);
        } else {
          const text = JSON.stringify(result);
          resolve(new TextEncoder().encode(text).buffer);
        }
      },
      (err) => reject(err),
      {
        binary: true,
        animations: [clip],
      },
    );
  });

  // Dispose temporary export meshes/materials
  root.traverse((obj) => {
    if (obj instanceof THREE.Mesh) {
      obj.geometry.dispose();
      if (Array.isArray(obj.material)) {
        obj.material.forEach((m) => m.dispose());
      } else {
        obj.material.dispose();
      }
    }
  });

  const blob = new Blob([glbBuffer], { type: 'model/gltf-binary' });
  triggerDownload(blob, `${slugify(project.name)}.glb`);
  return glbBuffer.byteLength;
}

/**
 * Exports the articulated R15 skeletal rig and baked animation curves as an ASCII FBX 7.4 file.
 */
export function exportFBXAnimation(project: AnimationProject): number {
  const fbxText = buildFBXAscii(project);
  const blob = new Blob([fbxText], { type: 'text/plain;charset=utf-8' });
  triggerDownload(blob, `${slugify(project.name)}.fbx`);
  return blob.size;
}

export { exportRobloxLua, buildRobloxLua } from './robloxExporter.ts';

