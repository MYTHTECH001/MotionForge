import {
  R15_JOINT_NAMES,
  createNeutralPose,
  type AnimationProject,
  type R15JointName,
} from '../animation/types.ts';
import { evaluatePoseAtTime } from '../animation/interpolation.ts';
import { R15_PIVOT_OFFSETS } from '../rig/r15Geometry.ts';

const FBX_TICKS_PER_SECOND = 46186158000;

const R15_PARENTS: Record<R15JointName, R15JointName | null> = {
  HumanoidRootPart: null,
  LowerTorso: 'HumanoidRootPart',
  UpperTorso: 'LowerTorso',
  Head: 'UpperTorso',
  LeftUpperArm: 'UpperTorso',
  LeftLowerArm: 'LeftUpperArm',
  LeftHand: 'LeftLowerArm',
  RightUpperArm: 'UpperTorso',
  RightLowerArm: 'RightUpperArm',
  RightHand: 'RightLowerArm',
  LeftUpperLeg: 'LowerTorso',
  LeftLowerLeg: 'LeftUpperLeg',
  LeftFoot: 'LeftLowerLeg',
  RightUpperLeg: 'LowerTorso',
  RightLowerLeg: 'RightUpperLeg',
  RightFoot: 'RightLowerLeg',
};

function sanitizeFbxName(name: string): string {
  return name.replace(/["\r\n]/g, '').trim() || 'MotionForgeAnimation';
}

function fmtNum(n: number): string {
  if (Math.abs(n) < 1e-6) return '0';
  return Number(n.toFixed(5)).toString();
}

function toFbxTicks(seconds: number): number {
  return Math.round(seconds * FBX_TICKS_PER_SECOND);
}

/**
 * Generates an ASCII FBX 7.4 skeletal animation containing the 16-joint R15 LimbNode
 * hierarchy and baked per-frame XYZ Euler rotation & root translation curves.
 */
export function buildFBXAscii(project: AnimationProject): string {
  const sorted = [...project.keyframes].sort((a, b) => a.time - b.time);
  const fps = Math.max(1, Math.min(120, Math.round(project.fps || 30)));
  const sampleCount = Math.max(2, Math.round(project.duration * fps) + 1);

  const sampleTimesSec: number[] = [];
  const sampleTicks: number[] = [];
  for (let i = 0; i < sampleCount; i++) {
    const t = (i / (sampleCount - 1)) * project.duration;
    sampleTimesSec.push(t);
    sampleTicks.push(toFbxTicks(t));
  }

  const rootPosCurves: [number[], number[], number[]] = [[], [], []];
  const jointRotCurves: Record<R15JointName, [number[], number[], number[]]> =
    {} as Record<R15JointName, [number[], number[], number[]]>;

  for (const j of R15_JOINT_NAMES) {
    jointRotCurves[j] = [[], [], []];
  }

  const poseScratch = createNeutralPose();
  const baseRoot = R15_PIVOT_OFFSETS.HumanoidRootPart;

  for (let i = 0; i < sampleTimesSec.length; i++) {
    const pose = evaluatePoseAtTime(
      sorted,
      sampleTimesSec[i],
      poseScratch,
      project.loop,
      project.duration,
    );
    rootPosCurves[0].push(baseRoot[0] + pose.rootPosition[0]);
    rootPosCurves[1].push(baseRoot[1] + pose.rootPosition[1]);
    rootPosCurves[2].push(baseRoot[2] + pose.rootPosition[2]);

    for (const j of R15_JOINT_NAMES) {
      const r = pose.joints[j];
      jointRotCurves[j][0].push(r[0]);
      jointRotCurves[j][1].push(r[1]);
      jointRotCurves[j][2].push(r[2]);
    }
  }

  let nextId = 100000;
  const allocId = () => ++nextId;

  const rigRootId = allocId();
  const animStackId = allocId();
  const animLayerId = allocId();

  const jointModelIds = {} as Record<R15JointName, number>;
  const jointAttrIds = {} as Record<R15JointName, number>;
  for (const j of R15_JOINT_NAMES) {
    jointModelIds[j] = allocId();
    jointAttrIds[j] = allocId();
  }

  const clipName = sanitizeFbxName(project.name);
  const durationTicks = toFbxTicks(project.duration);

  const lines: string[] = [];
  const connections: string[] = [];

  lines.push('; FBX 7.4.0 project file');
  lines.push('; Created by MotionForge R15 Studio');
  lines.push('; ----------------------------------------------------');
  lines.push('');

  lines.push('FBXHeaderExtension:  {');
  lines.push('\tFBXHeaderVersion: 1003');
  lines.push('\tFBXVersion: 7400');
  lines.push('\tCreator: "MotionForge R15 Studio"');
  lines.push('}');
  lines.push('');

  lines.push('GlobalSettings:  {');
  lines.push('\tVersion: 1000');
  lines.push('\tProperties70:  {');
  lines.push('\t\tP: "UpAxis", "int", "Integer", "",1');
  lines.push('\t\tP: "UpAxisSign", "int", "Integer", "",1');
  lines.push('\t\tP: "FrontAxis", "int", "Integer", "",2');
  lines.push('\t\tP: "FrontAxisSign", "int", "Integer", "",1');
  lines.push('\t\tP: "CoordAxis", "int", "Integer", "",0');
  lines.push('\t\tP: "CoordAxisSign", "int", "Integer", "",1');
  lines.push('\t\tP: "UnitScaleFactor", "double", "Number", "",1');
  lines.push(`\t\tP: "CustomFrameRate", "double", "Number", "",${fps}`);
  lines.push('\t}');
  lines.push('}');
  lines.push('');

  const curveNodeCount = 1 + R15_JOINT_NAMES.length;
  const curveCount = curveNodeCount * 3;
  const nodeAttrCount = R15_JOINT_NAMES.length;
  const modelCount = 1 + R15_JOINT_NAMES.length;

  lines.push('Definitions:  {');
  lines.push('\tVersion: 100');
  lines.push(
    `\tCount: ${modelCount + nodeAttrCount + 2 + curveNodeCount + curveCount}`,
  );
  lines.push('\tObjectType: "GlobalSettings" {');
  lines.push('\t\tCount: 1');
  lines.push('\t}');
  lines.push('\tObjectType: "Model" {');
  lines.push(`\t\tCount: ${modelCount}`);
  lines.push('\t}');
  lines.push('\tObjectType: "NodeAttribute" {');
  lines.push(`\t\tCount: ${nodeAttrCount}`);
  lines.push('\t}');
  lines.push('\tObjectType: "AnimationStack" {');
  lines.push('\t\tCount: 1');
  lines.push('\t}');
  lines.push('\tObjectType: "AnimationLayer" {');
  lines.push('\t\tCount: 1');
  lines.push('\t}');
  lines.push('\tObjectType: "AnimationCurveNode" {');
  lines.push(`\t\tCount: ${curveNodeCount}`);
  lines.push('\t}');
  lines.push('\tObjectType: "AnimationCurve" {');
  lines.push(`\t\tCount: ${curveCount}`);
  lines.push('\t}');
  lines.push('}');
  lines.push('');

  lines.push('Objects:  {');

  // Skeleton NodeAttributes
  for (const j of R15_JOINT_NAMES) {
    lines.push(
      `\tNodeAttribute: ${jointAttrIds[j]}, "NodeAttribute::${j}", "Skeleton" {`,
    );
    lines.push('\t\tTypeFlags: "Skeleton"');
    lines.push('\t}');
    connections.push(`\tC: "OO",${jointAttrIds[j]},${jointModelIds[j]}`);
  }

  // Root armature container node
  lines.push(
    `\tModel: ${rigRootId}, "Model::MotionForge_R15_Rig", "Null" {`,
  );
  lines.push('\t\tVersion: 232');
  lines.push('\t\tProperties70:  {');
  lines.push('\t\t\tP: "Lcl Translation", "Lcl Translation", "", "A",0,0,0');
  lines.push('\t\t\tP: "Lcl Rotation", "Lcl Rotation", "", "A",0,0,0');
  lines.push('\t\t\tP: "Lcl Scaling", "Lcl Scaling", "", "A",1,1,1');
  lines.push('\t\t}');
  lines.push('\t\tShading: Y');
  lines.push('\t\tCulling: "CullingOff"');
  lines.push('\t}');
  connections.push(`\tC: "OO",${rigRootId},0`);

  // 16 R15 LimbNodes
  for (const j of R15_JOINT_NAMES) {
    const [tx, ty, tz] = R15_PIVOT_OFFSETS[j];
    const firstRot = jointRotCurves[j];
    const rx0 = firstRot[0][0] ?? 0;
    const ry0 = firstRot[1][0] ?? 0;
    const rz0 = firstRot[2][0] ?? 0;

    lines.push(`\tModel: ${jointModelIds[j]}, "Model::${j}", "LimbNode" {`);
    lines.push('\t\tVersion: 232');
    lines.push('\t\tProperties70:  {');
    lines.push('\t\t\tP: "RotationActive", "bool", "", "",1');
    lines.push('\t\t\tP: "RotationOrder", "enum", "", "",0');
    lines.push('\t\t\tP: "InheritType", "enum", "", "",1');
    lines.push('\t\t\tP: "DefaultAttributeIndex", "int", "Integer", "",0');
    lines.push(
      `\t\t\tP: "Lcl Translation", "Lcl Translation", "", "A",${fmtNum(tx)},${fmtNum(ty)},${fmtNum(tz)}`,
    );
    lines.push(
      `\t\t\tP: "Lcl Rotation", "Lcl Rotation", "", "A",${fmtNum(rx0)},${fmtNum(ry0)},${fmtNum(rz0)}`,
    );
    lines.push('\t\t\tP: "Lcl Scaling", "Lcl Scaling", "", "A",1,1,1');
    lines.push('\t\t}');
    lines.push('\t\tShading: Y');
    lines.push('\t\tCulling: "CullingOff"');
    lines.push('\t}');

    const parentJoint = R15_PARENTS[j];
    const parentId = parentJoint ? jointModelIds[parentJoint] : rigRootId;
    connections.push(`\tC: "OO",${jointModelIds[j]},${parentId}`);
  }

  // AnimationStack & AnimationLayer
  lines.push(
    `\tAnimationStack: ${animStackId}, "AnimStack::${clipName}", "" {`,
  );
  lines.push('\t\tProperties70:  {');
  lines.push('\t\t\tP: "LocalStart", "KTime", "Time", "",0');
  lines.push(`\t\t\tP: "LocalStop", "KTime", "Time", "",${durationTicks}`);
  lines.push('\t\t\tP: "ReferenceStart", "KTime", "Time", "",0');
  lines.push(
    `\t\t\tP: "ReferenceStop", "KTime", "Time", "",${durationTicks}`,
  );
  lines.push('\t\t}');
  lines.push('\t}');

  lines.push(
    `\tAnimationLayer: ${animLayerId}, "AnimLayer::BaseLayer", "" {`,
  );
  lines.push('\t}');
  connections.push(`\tC: "OO",${animLayerId},${animStackId}`);

  const keyTimesStr = sampleTicks.join(',');

  const emitCurveTriplet = (
    modelId: number,
    attrType: 'T' | 'R',
    fbxProp: 'Lcl Translation' | 'Lcl Rotation',
    valuesXYZ: [number[], number[], number[]],
  ) => {
    const curveNodeId = allocId();
    const dX = fmtNum(valuesXYZ[0][0] ?? 0);
    const dY = fmtNum(valuesXYZ[1][0] ?? 0);
    const dZ = fmtNum(valuesXYZ[2][0] ?? 0);

    lines.push(
      `\tAnimationCurveNode: ${curveNodeId}, "AnimCurveNode::${attrType}", "" {`,
    );
    lines.push('\t\tProperties70:  {');
    lines.push(`\t\t\tP: "d|X", "Number", "", "A",${dX}`);
    lines.push(`\t\t\tP: "d|Y", "Number", "", "A",${dY}`);
    lines.push(`\t\t\tP: "d|Z", "Number", "", "A",${dZ}`);
    lines.push('\t\t}');
    lines.push('\t}');

    connections.push(`\tC: "OO",${curveNodeId},${animLayerId}`);
    connections.push(`\tC: "OP",${curveNodeId},${modelId}, "${fbxProp}"`);

    const axes: ['d|X' | 'd|Y' | 'd|Z', number[]][] = [
      ['d|X', valuesXYZ[0]],
      ['d|Y', valuesXYZ[1]],
      ['d|Z', valuesXYZ[2]],
    ];

    for (const [axisProp, vals] of axes) {
      const curveId = allocId();
      const valStr = vals.map(fmtNum).join(',');
      lines.push(`\tAnimationCurve: ${curveId}, "AnimCurve::", "" {`);
      lines.push(`\t\tDefault: ${fmtNum(vals[0] ?? 0)}`);
      lines.push('\t\tKeyVer: 4008');
      lines.push(`\t\tKeyTime: *${sampleTicks.length} {`);
      lines.push(`\t\t\ta: ${keyTimesStr}`);
      lines.push('\t\t}');
      lines.push(`\t\tKeyValueFloat: *${vals.length} {`);
      lines.push(`\t\t\ta: ${valStr}`);
      lines.push('\t\t}');
      lines.push('\t\tKeyAttrFlags: *1 {');
      lines.push('\t\t\ta: 24840');
      lines.push('\t\t}');
      lines.push('\t\tKeyAttrDataFloat: *4 {');
      lines.push('\t\t\ta: 0,0,21845333,0');
      lines.push('\t\t}');
      lines.push('\t\tKeyAttrRefCount: *1 {');
      lines.push(`\t\t\ta: ${vals.length}`);
      lines.push('\t\t}');
      lines.push('\t}');

      connections.push(`\tC: "OP",${curveId},${curveNodeId}, "${axisProp}"`);
    }
  };

  // Root position track + 16 R15 joint rotation tracks
  emitCurveTriplet(
    jointModelIds.HumanoidRootPart,
    'T',
    'Lcl Translation',
    rootPosCurves,
  );

  for (const j of R15_JOINT_NAMES) {
    emitCurveTriplet(jointModelIds[j], 'R', 'Lcl Rotation', jointRotCurves[j]);
  }

  lines.push('}');
  lines.push('');

  lines.push('Connections:  {');
  lines.push(...connections);
  lines.push('}');
  lines.push('');

  return lines.join('\n');
}
