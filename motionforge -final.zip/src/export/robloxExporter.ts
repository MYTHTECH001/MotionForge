import {
  R15_JOINT_NAMES,
  type AnimationProject,
  type EasingMode,
  type R15JointName,
  type Vec3Tuple,
} from '../animation/types.ts';

const R15_PARENT_MAP: Record<R15JointName, R15JointName | null> = {
  HumanoidRootPart: null,
  LowerTorso: 'HumanoidRootPart',
  UpperTorso: 'LowerTorso',
  Head: 'UpperTorso',
  LeftUpperArm: 'UpperTorso',
  LeftLowerArm: 'LeftUpperArm',
  LeftHand: 'LeftLowerArm',
  RightUpperArm: 'UpperTorso',
  RightLowerArm: 'RightUpperArm',
  RightHand: 'RightLowerArm',
  LeftUpperLeg: 'LowerTorso',
  LeftLowerLeg: 'LeftUpperLeg',
  LeftFoot: 'LeftLowerLeg',
  RightUpperLeg: 'LowerTorso',
  RightLowerLeg: 'RightUpperLeg',
  RightFoot: 'RightLowerLeg',
};

function escapeLuaString(str: string): string {
  return str
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"')
    .replace(/\r?\n/g, ' ');
}

function fmtDeg(n: number): string {
  const clean = Math.abs(n) < 1e-5 ? 0 : Number(n.toFixed(3));
  return String(clean);
}

function mapEasingToRoblox(easing: EasingMode): {
  style: string;
  direction: string;
} {
  switch (easing) {
    case 'linear':
      return {
        style: 'Enum.PoseEasingStyle.Linear',
        direction: 'Enum.PoseEasingDirection.InOut',
      };
    case 'easeIn':
      return {
        style: 'Enum.PoseEasingStyle.Cubic',
        direction: 'Enum.PoseEasingDirection.In',
      };
    case 'easeOut':
      return {
        style: 'Enum.PoseEasingStyle.Cubic',
        direction: 'Enum.PoseEasingDirection.Out',
      };
    case 'constant':
      return {
        style: 'Enum.PoseEasingStyle.Constant',
        direction: 'Enum.PoseEasingDirection.InOut',
      };
    case 'bounce':
      return {
        style: 'Enum.PoseEasingStyle.Bounce',
        direction: 'Enum.PoseEasingDirection.Out',
      };
    case 'elastic':
      return {
        style: 'Enum.PoseEasingStyle.Elastic',
        direction: 'Enum.PoseEasingDirection.Out',
      };
    case 'easeInOut':
    default:
      return {
        style: 'Enum.PoseEasingStyle.Cubic',
        direction: 'Enum.PoseEasingDirection.InOut',
      };
  }
}

function slugify(name: string): string {
  return (
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'motionforge-animation'
  );
}

/**
 * Generates a self-contained Roblox Studio Command Bar / Plugin Luau script
 * that constructs a KeyframeSequence with the full R15 Pose hierarchy.
 */
export function buildRobloxLua(project: AnimationProject): string {
  const sorted = [...project.keyframes].sort((a, b) => a.time - b.time);
  const safeName = escapeLuaString(project.name.trim() || 'MotionForgeAnimation');
  const lines: string[] = [];

  lines.push(`-- MotionForge R15 Roblox KeyframeSequence Script`);
  lines.push(`-- Animation: ${safeName} (${project.duration.toFixed(2)}s, ${sorted.length} keyframes)`);
  lines.push(`do`);
  lines.push(`  local Selection = game:GetService("Selection")`);
  lines.push(`  local ServerStorage = game:GetService("ServerStorage")`);
  lines.push(``);
  lines.push(`  local seq = Instance.new("KeyframeSequence")`);
  lines.push(`  seq.Name = "${safeName}"`);
  lines.push(`  seq.Looped = ${project.loop ? 'true' : 'false'}`);
  lines.push(`  seq.Priority = Enum.AnimationPriority.Action`);
  lines.push(``);
  lines.push(`  local function makePose(name, parent, rx, ry, rz, style, dir, px, py, pz, weight)`);
  lines.push(`    local pose = Instance.new("Pose")`);
  lines.push(`    pose.Name = name`);
  lines.push(`    pose.Weight = weight or 1`);
  lines.push(`    pose.EasingStyle = style`);
  lines.push(`    pose.EasingDirection = dir`);
  lines.push(`    local rot = CFrame.Angles(math.rad(rx), math.rad(ry), math.rad(rz))`);
  lines.push(`    if px ~= nil then`);
  lines.push(`      pose.CFrame = CFrame.new(px, py, pz) * rot`);
  lines.push(`    else`);
  lines.push(`      pose.CFrame = rot`);
  lines.push(`    end`);
  lines.push(`    pose.Parent = parent`);
  lines.push(`    return pose`);
  lines.push(`  end`);

  sorted.forEach((kf, idx) => {
    const { style, direction } = mapEasingToRoblox(kf.easing);
    const kfVar = `kf${idx}`;
    const pos = kf.rootPosition ?? [0, 0, 0];

    lines.push(``);
    lines.push(`  local ${kfVar} = Instance.new("Keyframe")`);
    lines.push(`  ${kfVar}.Name = "KF_${idx}"`);
    lines.push(`  ${kfVar}.Time = ${Number(kf.time.toFixed(4))}`);
    lines.push(`  ${kfVar}.Parent = seq`);

    const poseVar: Partial<Record<R15JointName, string>> = {};
    for (const joint of R15_JOINT_NAMES) {
      const parentJoint = R15_PARENT_MAP[joint];
      const parentExpr = parentJoint ? poseVar[parentJoint]! : kfVar;
      const vName = `p_${idx}_${joint}`;
      poseVar[joint] = vName;

      const rot: Vec3Tuple = kf.joints[joint] ?? [0, 0, 0];
      const isRoot = joint === 'HumanoidRootPart';
      const hasRootTransform =
        isRoot &&
        (Math.abs(pos[0]) > 1e-5 ||
          Math.abs(pos[1]) > 1e-5 ||
          Math.abs(pos[2]) > 1e-5 ||
          Math.abs(rot[0]) > 1e-5 ||
          Math.abs(rot[1]) > 1e-5 ||
          Math.abs(rot[2]) > 1e-5);
      const weight = isRoot && !hasRootTransform ? 0 : 1;

      if (isRoot && (Math.abs(pos[0]) > 1e-5 || Math.abs(pos[1]) > 1e-5 || Math.abs(pos[2]) > 1e-5)) {
        lines.push(
          `  local ${vName} = makePose("${joint}", ${parentExpr}, ${fmtDeg(rot[0])}, ${fmtDeg(rot[1])}, ${fmtDeg(rot[2])}, ${style}, ${direction}, ${fmtDeg(pos[0])}, ${fmtDeg(pos[1])}, ${fmtDeg(pos[2])}, ${weight})`,
        );
      } else {
        lines.push(
          `  local ${vName} = makePose("${joint}", ${parentExpr}, ${fmtDeg(rot[0])}, ${fmtDeg(rot[1])}, ${fmtDeg(rot[2])}, ${style}, ${direction}, nil, nil, nil, ${weight})`,
        );
      }
    }
  });

  lines.push(``);
  lines.push(`  local targetParent = Selection:Get()[1] or ServerStorage`);
  lines.push(`  seq.Parent = targetParent`);
  lines.push(`  Selection:Set({ seq })`);
  lines.push(`  print("[MotionForge] Created KeyframeSequence '" .. seq.Name .. "' in " .. targetParent:GetFullName())`);
  lines.push(`end`);
  lines.push(``);

  return lines.join('\n');
}

export function exportRobloxLua(project: AnimationProject): number {
  const luaText = buildRobloxLua(project);
  const blob = new Blob([luaText], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${slugify(project.name)}.roblox.lua`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  return blob.size;
}
