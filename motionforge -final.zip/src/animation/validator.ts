import {
  R15_JOINT_NAMES,
  type AnimationProject,
  type EasingMode,
  type Keyframe,
  type PropType,
  type R15JointName,
  type Vec3Tuple,
} from './types.ts';
import { clampToLimits } from './jointLimits.ts';

export interface ValidationResult {
  valid: boolean;
  project?: AnimationProject;
  errors: string[];
  warnings: string[];
}

const VALID_JOINT_SET = new Set<string>(R15_JOINT_NAMES);
const VALID_EASING_SET = new Set<string>([
  'linear',
  'easeInOut',
  'easeIn',
  'easeOut',
  'constant',
  'bounce',
  'elastic',
]);
const VALID_PROP_SET = new Set<string>(['none', 'net', 'sword']);

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

function round3(n: number): number {
  return Math.round(n * 1000) / 1000;
}

function parseVec3(
  raw: unknown,
  minVal: number,
  maxVal: number,
): Vec3Tuple | null {
  if (!Array.isArray(raw) || raw.length !== 3) {
    return null;
  }
  const x = Number(raw[0]);
  const y = Number(raw[1]);
  const z = Number(raw[2]);
  if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) {
    return null;
  }
  return [
    round2(clamp(x, minVal, maxVal)),
    round2(clamp(y, minVal, maxVal)),
    round2(clamp(z, minVal, maxVal)),
  ];
}

export function validateAnimationPayload(raw: unknown): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return {
      valid: false,
      errors: ['Animation payload must be a JSON object.'],
      warnings,
    };
  }

  const obj = raw as Record<string, unknown>;

  const name =
    typeof obj.name === 'string' && obj.name.trim().length > 0
      ? obj.name.trim().slice(0, 80)
      : 'Untitled Animation';

  const rawDuration = Number(obj.duration);
  if (!Number.isFinite(rawDuration) || rawDuration <= 0) {
    errors.push('Animation "duration" must be a positive number in seconds.');
  }
  const duration = Number.isFinite(rawDuration)
    ? round3(clamp(rawDuration, 0.2, 30))
    : 1.0;

  if (Number.isFinite(rawDuration) && (rawDuration < 0.2 || rawDuration > 30)) {
    warnings.push(`Duration clamped to ${duration}s (allowed 0.2s - 30s).`);
  }

  const rawFps = Number(obj.fps ?? 30);
  const fps = Number.isFinite(rawFps) ? Math.round(clamp(rawFps, 12, 120)) : 30;
  const loop = typeof obj.loop === 'boolean' ? obj.loop : true;
  const prop: PropType =
    typeof obj.prop === 'string' && VALID_PROP_SET.has(obj.prop)
      ? (obj.prop as PropType)
      : 'none';

  if (!Array.isArray(obj.keyframes) || obj.keyframes.length === 0) {
    errors.push('Animation must contain a non-empty "keyframes" array.');
    return { valid: false, errors, warnings };
  }

  const normalizedKeyframes: Keyframe[] = [];
  const axisNames = ['rx', 'ry', 'rz'] as const;

  obj.keyframes.forEach((kfRaw, idx) => {
    if (!kfRaw || typeof kfRaw !== 'object' || Array.isArray(kfRaw)) {
      errors.push(`Keyframe at index ${idx} is not an object.`);
      return;
    }

    const kfObj = kfRaw as Record<string, unknown>;
    const rawTime = Number(kfObj.time);
    if (!Number.isFinite(rawTime)) {
      errors.push(`Keyframe ${idx} has an invalid numeric "time".`);
      return;
    }

    const time = round3(clamp(rawTime, 0, duration));
    if (rawTime < 0 || rawTime > duration) {
      warnings.push(
        `Keyframe ${idx} time (${rawTime}s) clamped to [0, ${duration}s].`,
      );
    }

    const easing: EasingMode =
      typeof kfObj.easing === 'string' && VALID_EASING_SET.has(kfObj.easing)
        ? (kfObj.easing as EasingMode)
        : 'easeInOut';

    const jointsRaw = kfObj.joints;
    if (!jointsRaw || typeof jointsRaw !== 'object' || Array.isArray(jointsRaw)) {
      errors.push(`Keyframe ${idx} must provide a "joints" object.`);
      return;
    }

    const joints: Partial<Record<R15JointName, Vec3Tuple>> = {};
    let validJointCount = 0;

    for (const [jointKey, tupleRaw] of Object.entries(
      jointsRaw as Record<string, unknown>,
    )) {
      if (!VALID_JOINT_SET.has(jointKey)) {
        warnings.push(
          `Ignored unknown joint "${jointKey}" in keyframe ${idx}.`,
        );
        continue;
      }

      const parsed = parseVec3(tupleRaw, -180, 180);
      if (!parsed) {
        warnings.push(
          `Ignored invalid rotation tuple on "${jointKey}" in keyframe ${idx}.`,
        );
        continue;
      }

      const jointName = jointKey as R15JointName;
      const limited = clampToLimits(jointName, parsed);
      for (let axis = 0; axis < 3; axis++) {
        if (limited[axis] !== parsed[axis]) {
          warnings.push(`Clamped ${jointName} ${axisNames[axis]} to ${limited[axis]}`);
        }
      }

      joints[jointName] = limited;
      validJointCount++;
    }

    let rootPosition: Vec3Tuple | undefined;
    if (kfObj.rootPosition !== undefined) {
      const parsedPos = parseVec3(kfObj.rootPosition, -10, 10);
      if (parsedPos) {
        rootPosition = parsedPos;
      } else {
        warnings.push(`Ignored invalid rootPosition in keyframe ${idx}.`);
      }
    }

    if (validJointCount === 0 && !rootPosition) {
      warnings.push(`Keyframe ${idx} had no valid joint rotations or rootPosition.`);
    }

    const id =
      typeof kfObj.id === 'string' && kfObj.id.trim().length > 0
        ? kfObj.id.trim()
        : `kf-${idx}-${Math.round(time * 1000)}`;

    normalizedKeyframes.push({
      id,
      time,
      easing,
      joints,
      ...(rootPosition ? { rootPosition } : {}),
    });
  });

  if (errors.length > 0) {
    return { valid: false, errors, warnings };
  }

  if (normalizedKeyframes.length === 0) {
    return {
      valid: false,
      errors: ['No valid keyframes remained after validation.'],
      warnings,
    };
  }

  normalizedKeyframes.sort((a, b) => a.time - b.time);

  // Deduplicate exact identical timestamps by keeping later entry or nudging slightly
  const deduped: Keyframe[] = [];
  for (const kf of normalizedKeyframes) {
    const prev = deduped[deduped.length - 1];
    if (prev && Math.abs(prev.time - kf.time) < 0.001) {
      deduped[deduped.length - 1] = {
        ...prev,
        ...kf,
        joints: { ...prev.joints, ...kf.joints },
      };
      warnings.push(`Merged duplicate keyframe at t=${kf.time}s.`);
    } else {
      deduped.push(kf);
    }
  }

  if (deduped.length === 1) {
    const first = deduped[0];
    if (first.time > 0) {
      deduped.unshift({
        id: 'kf-auto-start',
        time: 0,
        easing: 'easeInOut',
        joints: {},
        rootPosition: [0, 0, 0],
      });
    } else {
      deduped.push({
        id: 'kf-auto-end',
        time: duration,
        easing: 'easeInOut',
        joints: { ...first.joints },
        ...(first.rootPosition ? { rootPosition: [...first.rootPosition] as Vec3Tuple } : {}),
      });
    }
    warnings.push('Added second keyframe so interpolation has start and end poses.');
  }

  return {
    valid: true,
    project: {
      version: 1,
      name,
      duration,
      fps,
      loop,
      prop,
      keyframes: deduped,
    },
    errors: [],
    warnings,
  };
}
