export const R15_JOINT_NAMES = [
  'HumanoidRootPart',
  'LowerTorso',
  'UpperTorso',
  'Head',
  'LeftUpperArm',
  'LeftLowerArm',
  'LeftHand',
  'RightUpperArm',
  'RightLowerArm',
  'RightHand',
  'LeftUpperLeg',
  'LeftLowerLeg',
  'LeftFoot',
  'RightUpperLeg',
  'RightLowerLeg',
  'RightFoot',
] as const;

export type R15JointName = (typeof R15_JOINT_NAMES)[number];

export type Vec3Tuple = [number, number, number];

export type EasingMode =
  | 'linear'
  | 'easeInOut'
  | 'easeIn'
  | 'easeOut'
  | 'constant'
  | 'bounce'
  | 'elastic';

export type PropType = 'none' | 'net' | 'sword';

export interface Keyframe {
  id: string;
  time: number;
  easing: EasingMode;
  joints: Partial<Record<R15JointName, Vec3Tuple>>;
  rootPosition?: Vec3Tuple;
}

export interface AnimationProject {
  version: 1;
  name: string;
  duration: number;
  fps: number;
  loop: boolean;
  prop: PropType;
  keyframes: Keyframe[];
}

export interface EvaluatedPose {
  joints: Record<R15JointName, Vec3Tuple>;
  rootPosition: Vec3Tuple;
}

export interface R15JointMeta {
  name: R15JointName;
  motorName: string;
  parent: R15JointName | null;
  category: 'root' | 'torso' | 'leftArm' | 'rightArm' | 'leftLeg' | 'rightLeg';
  axisHint: string;
}

export const R15_JOINT_META: Record<R15JointName, R15JointMeta> = {
  HumanoidRootPart: {
    name: 'HumanoidRootPart',
    motorName: 'RootRig',
    parent: null,
    category: 'root',
    axisHint: 'X: lean fwd/back · Y: turn · Z: tilt side',
  },
  LowerTorso: {
    name: 'LowerTorso',
    motorName: 'Root',
    parent: 'HumanoidRootPart',
    category: 'torso',
    axisHint: 'X: hip pitch · Y: hip twist · Z: hip sway',
  },
  UpperTorso: {
    name: 'UpperTorso',
    motorName: 'Waist',
    parent: 'LowerTorso',
    category: 'torso',
    axisHint: '-X: hunch fwd · +X: arch back · Y: twist',
  },
  Head: {
    name: 'Head',
    motorName: 'Neck',
    parent: 'UpperTorso',
    category: 'torso',
    axisHint: '-X: look down · +X: look up · Y: turn left/right',
  },
  LeftUpperArm: {
    name: 'LeftUpperArm',
    motorName: 'LeftShoulder',
    parent: 'UpperTorso',
    category: 'leftArm',
    axisHint: '-X: swing fwd · +X: swing back · +Z: raise out',
  },
  LeftLowerArm: {
    name: 'LeftLowerArm',
    motorName: 'LeftElbow',
    parent: 'LeftUpperArm',
    category: 'leftArm',
    axisHint: '-X: bend elbow forward',
  },
  LeftHand: {
    name: 'LeftHand',
    motorName: 'LeftWrist',
    parent: 'LeftLowerArm',
    category: 'leftArm',
    axisHint: 'X: wrist flex · Y: pronate/supinate',
  },
  RightUpperArm: {
    name: 'RightUpperArm',
    motorName: 'RightShoulder',
    parent: 'UpperTorso',
    category: 'rightArm',
    axisHint: '-X: swing fwd · +X: swing back · -Z: raise out',
  },
  RightLowerArm: {
    name: 'RightLowerArm',
    motorName: 'RightElbow',
    parent: 'RightUpperArm',
    category: 'rightArm',
    axisHint: '-X: bend elbow forward',
  },
  RightHand: {
    name: 'RightHand',
    motorName: 'RightWrist',
    parent: 'RightLowerArm',
    category: 'rightArm',
    axisHint: 'X: wrist flex · Y: twist prop grip',
  },
  LeftUpperLeg: {
    name: 'LeftUpperLeg',
    motorName: 'LeftHip',
    parent: 'LowerTorso',
    category: 'leftLeg',
    axisHint: '-X: kick forward · +X: extend back · +Z: split out',
  },
  LeftLowerLeg: {
    name: 'LeftLowerLeg',
    motorName: 'LeftKnee',
    parent: 'LeftUpperLeg',
    category: 'leftLeg',
    axisHint: '+X: bend knee backward',
  },
  LeftFoot: {
    name: 'LeftFoot',
    motorName: 'LeftAnkle',
    parent: 'LeftLowerLeg',
    category: 'leftLeg',
    axisHint: '-X: toes up · +X: point toes down',
  },
  RightUpperLeg: {
    name: 'RightUpperLeg',
    motorName: 'RightHip',
    parent: 'LowerTorso',
    category: 'rightLeg',
    axisHint: '-X: kick forward · +X: extend back · -Z: split out',
  },
  RightLowerLeg: {
    name: 'RightLowerLeg',
    motorName: 'RightKnee',
    parent: 'RightUpperLeg',
    category: 'rightLeg',
    axisHint: '+X: bend knee backward',
  },
  RightFoot: {
    name: 'RightFoot',
    motorName: 'RightAnkle',
    parent: 'RightLowerLeg',
    category: 'rightLeg',
    axisHint: '-X: toes up · +X: point toes down',
  },
};

export function createNeutralPose(): EvaluatedPose {
  const joints = {} as Record<R15JointName, Vec3Tuple>;
  for (const name of R15_JOINT_NAMES) {
    joints[name] = [0, 0, 0];
  }
  return {
    joints,
    rootPosition: [0, 0, 0],
  };
}
