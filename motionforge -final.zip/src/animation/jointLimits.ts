import type { R15JointName, Vec3Tuple } from './types.ts';

export interface JointLimits {
  min: Vec3Tuple;
  max: Vec3Tuple;
}

export const R15_JOINT_LIMITS: Record<R15JointName, JointLimits> = {
  HumanoidRootPart: {
    min: [-180, -180, -180],
    max: [180, 180, 180],
  },
  LowerTorso: {
    min: [-45, -60, -45],
    max: [45, 60, 45],
  },
  UpperTorso: {
    min: [-60, -70, -45],
    max: [45, 70, 45],
  },
  Head: {
    min: [-60, -80, -45],
    max: [60, 80, 45],
  },
  LeftUpperArm: {
    min: [-175, -90, -45],
    max: [90, 90, 175],
  },
  LeftLowerArm: {
    min: [-150, -15, -15],
    max: [0, 15, 15],
  },
  LeftHand: {
    min: [-80, -90, -45],
    max: [80, 90, 45],
  },
  RightUpperArm: {
    min: [-175, -90, -175],
    max: [90, 90, 45],
  },
  RightLowerArm: {
    min: [-150, -15, -15],
    max: [0, 15, 15],
  },
  RightHand: {
    min: [-80, -90, -45],
    max: [80, 90, 45],
  },
  LeftUpperLeg: {
    min: [-130, -60, -35],
    max: [80, 60, 85],
  },
  LeftLowerLeg: {
    min: [0, -5, -5],
    max: [150, 5, 5],
  },
  LeftFoot: {
    min: [-45, -30, -30],
    max: [45, 30, 30],
  },
  RightUpperLeg: {
    min: [-130, -60, -85],
    max: [80, 60, 35],
  },
  RightLowerLeg: {
    min: [0, -5, -5],
    max: [150, 5, 5],
  },
  RightFoot: {
    min: [-45, -30, -30],
    max: [45, 30, 30],
  },
};

function clampAxis(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

export function clampToLimits(joint: R15JointName, rot: Vec3Tuple): Vec3Tuple {
  const limits = R15_JOINT_LIMITS[joint];
  return [
    clampAxis(rot[0], limits.min[0], limits.max[0]),
    clampAxis(rot[1], limits.min[1], limits.max[1]),
    clampAxis(rot[2], limits.min[2], limits.max[2]),
  ];
}
