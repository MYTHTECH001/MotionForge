import * as THREE from 'three';
import {
  R15_JOINT_NAMES,
  createNeutralPose,
  type EasingMode,
  type EvaluatedPose,
  type Keyframe,
  type Vec3Tuple,
} from './types.ts';

// Pre-allocated scratch math objects for zero-GC 60fps evaluation
const _eulerA = new THREE.Euler(0, 0, 0, 'XYZ');
const _eulerB = new THREE.Euler(0, 0, 0, 'XYZ');
const _eulerOut = new THREE.Euler(0, 0, 0, 'XYZ');
const _quatA = new THREE.Quaternion();
const _quatB = new THREE.Quaternion();
const _quatOut = new THREE.Quaternion();

const DEG2RAD = Math.PI / 180;
const RAD2DEG = 180 / Math.PI;

// Cache sorted keyframe arrays by input array reference to avoid sorting on every frame
const sortedKeyframesCache = new WeakMap<Keyframe[], Keyframe[]>();

function getSortedKeyframes(keyframes: Keyframe[]): Keyframe[] {
  if (keyframes.length <= 1) return keyframes;
  const cached = sortedKeyframesCache.get(keyframes);
  if (cached) return cached;

  let alreadySorted = true;
  for (let i = 1; i < keyframes.length; i++) {
    if (keyframes[i].time < keyframes[i - 1].time) {
      alreadySorted = false;
      break;
    }
  }
  const sorted = alreadySorted
    ? keyframes
    : [...keyframes].sort((a, b) => a.time - b.time);
  sortedKeyframesCache.set(keyframes, sorted);
  return sorted;
}

function easeOutBounce(x: number): number {
  const n1 = 7.5625;
  const d1 = 2.75;
  if (x < 1 / d1) {
    return n1 * x * x;
  } else if (x < 2 / d1) {
    const t = x - 1.5 / d1;
    return n1 * t * t + 0.75;
  } else if (x < 2.5 / d1) {
    const t = x - 2.25 / d1;
    return n1 * t * t + 0.9375;
  } else {
    const t = x - 2.625 / d1;
    return n1 * t * t + 0.984375;
  }
}

function easeOutElastic(x: number): number {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  const c4 = (2 * Math.PI) / 3;
  return Math.pow(2, -10 * x) * Math.sin((x * 10 - 0.75) * c4) + 1;
}

export function applyEasing(t: number, mode: EasingMode): number {
  const u = Math.max(0, Math.min(1, t));
  switch (mode) {
    case 'constant':
      return u >= 1 ? 1 : 0;
    case 'linear':
      return u;
    case 'easeIn':
      return u * u * u;
    case 'easeOut':
      return 1 - Math.pow(1 - u, 3);
    case 'bounce':
      return u === 0 ? 0 : u === 1 ? 1 : easeOutBounce(u);
    case 'elastic':
      return easeOutElastic(u);
    case 'easeInOut':
    default:
      return u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2;
  }
}

/**
 * Exact normalized first derivative f'(u) of applyEasing(u, mode).
 * Integrates to 1 over [0, 1]; linear = 1 everywhere, cubic peaks at 3.
 */
export function getEasingVelocity(t: number, mode: EasingMode): number {
  const u = Math.max(0, Math.min(1, t));
  switch (mode) {
    case 'constant':
      return 0;
    case 'linear':
      return 1;
    case 'easeIn':
      return 3 * u * u;
    case 'easeOut':
      return 3 * (1 - u) * (1 - u);
    case 'bounce':
    case 'elastic': {
      const eps = 0.005;
      const a = Math.max(0, u - eps);
      const b = Math.min(1, u + eps);
      const span = Math.max(1e-5, b - a);
      const slope = Math.abs(applyEasing(b, mode) - applyEasing(a, mode)) / span;
      return Math.min(3, slope);
    }
    case 'easeInOut':
    default:
      return u < 0.5 ? 12 * u * u : 12 * (1 - u) * (1 - u);
  }
}

/**
 * Computes the peak angular/spatial delta between two poses (in effective degrees)
 * so timeline segments can distinguish active motion from static holds.
 */
export function computePoseDeltaMagnitude(
  a: EvaluatedPose,
  b: EvaluatedPose,
): number {
  let maxDelta = 0;
  for (let i = 0; i < R15_JOINT_NAMES.length; i++) {
    const j = R15_JOINT_NAMES[i];
    const ra = a.joints[j];
    const rb = b.joints[j];
    const dx = ra[0] - rb[0];
    const dy = ra[1] - rb[1];
    const dz = ra[2] - rb[2];
    const mag = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (mag > maxDelta) maxDelta = mag;
  }
  const rx = (a.rootPosition[0] - b.rootPosition[0]) * 35;
  const ry = (a.rootPosition[1] - b.rootPosition[1]) * 35;
  const rz = (a.rootPosition[2] - b.rootPosition[2]) * 35;
  const rootMag = Math.sqrt(rx * rx + ry * ry + rz * rz);
  return Math.max(maxDelta, rootMag);
}

function slerpEulerDegrees(
  a: Vec3Tuple,
  b: Vec3Tuple,
  alpha: number,
  out: Vec3Tuple,
): void {
  _eulerA.set(a[0] * DEG2RAD, a[1] * DEG2RAD, a[2] * DEG2RAD, 'XYZ');
  _eulerB.set(b[0] * DEG2RAD, b[1] * DEG2RAD, b[2] * DEG2RAD, 'XYZ');
  _quatA.setFromEuler(_eulerA);
  _quatB.setFromEuler(_eulerB);
  _quatOut.slerpQuaternions(_quatA, _quatB, alpha);
  _eulerOut.setFromQuaternion(_quatOut, 'XYZ');
  out[0] = _eulerOut.x * RAD2DEG;
  out[1] = _eulerOut.y * RAD2DEG;
  out[2] = _eulerOut.z * RAD2DEG;
}

export function evaluatePoseAtTime(
  keyframes: Keyframe[],
  time: number,
  targetPose?: EvaluatedPose,
  loop = false,
  duration?: number,
): EvaluatedPose {
  const pose = targetPose ?? createNeutralPose();

  if (keyframes.length === 0) {
    for (const j of R15_JOINT_NAMES) {
      pose.joints[j][0] = 0;
      pose.joints[j][1] = 0;
      pose.joints[j][2] = 0;
    }
    pose.rootPosition[0] = 0;
    pose.rootPosition[1] = 0;
    pose.rootPosition[2] = 0;
    return pose;
  }

  const sorted = getSortedKeyframes(keyframes);
  const clipDuration =
    duration !== undefined && duration > 0
      ? duration
      : sorted[sorted.length - 1].time;
  const evalTime =
    loop && clipDuration > 1e-5
      ? ((time % clipDuration) + clipDuration) % clipDuration
      : time;

  // Evaluate each joint across the keyframes that define it
  for (let jIdx = 0; jIdx < R15_JOINT_NAMES.length; jIdx++) {
    const jointName = R15_JOINT_NAMES[jIdx];

    let firstKf: Keyframe | null = null;
    let lastKf: Keyframe | null = null;
    let prevKf: Keyframe | null = null;
    let nextKf: Keyframe | null = null;

    for (let i = 0; i < sorted.length; i++) {
      const kf = sorted[i];
      if (kf.joints[jointName] !== undefined) {
        if (!firstKf) firstKf = kf;
        lastKf = kf;
        if (kf.time <= evalTime) {
          prevKf = kf;
        }
        if (kf.time >= evalTime && nextKf === null) {
          nextKf = kf;
        }
      }
    }

    const out = pose.joints[jointName];
    if (!firstKf || !lastKf) {
      out[0] = 0;
      out[1] = 0;
      out[2] = 0;
    } else if (!prevKf && nextKf) {
      if (loop && clipDuration > 1e-5 && lastKf !== nextKf) {
        const span = clipDuration + nextKf.time - lastKf.time;
        if (span > 1e-5) {
          const rawAlpha = (evalTime + clipDuration - lastKf.time) / span;
          const alpha = applyEasing(rawAlpha, nextKf.easing);
          slerpEulerDegrees(
            lastKf.joints[jointName]!,
            nextKf.joints[jointName]!,
            alpha,
            out,
          );
          continue;
        }
      }
      const v = nextKf.joints[jointName]!;
      out[0] = v[0];
      out[1] = v[1];
      out[2] = v[2];
    } else if (prevKf && !nextKf) {
      if (loop && clipDuration > 1e-5 && firstKf !== prevKf) {
        const span = clipDuration + firstKf.time - prevKf.time;
        if (span > 1e-5) {
          const rawAlpha = (evalTime - prevKf.time) / span;
          const alpha = applyEasing(rawAlpha, firstKf.easing);
          slerpEulerDegrees(
            prevKf.joints[jointName]!,
            firstKf.joints[jointName]!,
            alpha,
            out,
          );
          continue;
        }
      }
      const v = prevKf.joints[jointName]!;
      out[0] = v[0];
      out[1] = v[1];
      out[2] = v[2];
    } else if (prevKf && nextKf) {
      if (prevKf === nextKf || Math.abs(nextKf.time - prevKf.time) < 1e-5) {
        const v = prevKf.joints[jointName]!;
        out[0] = v[0];
        out[1] = v[1];
        out[2] = v[2];
      } else {
        const rawAlpha =
          (evalTime - prevKf.time) / (nextKf.time - prevKf.time);
        const alpha = applyEasing(rawAlpha, nextKf.easing);
        slerpEulerDegrees(
          prevKf.joints[jointName]!,
          nextKf.joints[jointName]!,
          alpha,
          out,
        );
      }
    }
  }

  // Evaluate rootPosition track
  let firstPosKf: Keyframe | null = null;
  let lastPosKf: Keyframe | null = null;
  let prevPosKf: Keyframe | null = null;
  let nextPosKf: Keyframe | null = null;
  for (let i = 0; i < sorted.length; i++) {
    const kf = sorted[i];
    if (kf.rootPosition !== undefined) {
      if (!firstPosKf) firstPosKf = kf;
      lastPosKf = kf;
      if (kf.time <= evalTime) {
        prevPosKf = kf;
      }
      if (kf.time >= evalTime && nextPosKf === null) {
        nextPosKf = kf;
      }
    }
  }

  if (!firstPosKf || !lastPosKf) {
    pose.rootPosition[0] = 0;
    pose.rootPosition[1] = 0;
    pose.rootPosition[2] = 0;
  } else if (!prevPosKf && nextPosKf) {
    if (loop && clipDuration > 1e-5 && lastPosKf !== nextPosKf) {
      const span = clipDuration + nextPosKf.time - lastPosKf.time;
      if (span > 1e-5) {
        const rawAlpha = (evalTime + clipDuration - lastPosKf.time) / span;
        const alpha = applyEasing(rawAlpha, nextPosKf.easing);
        const a = lastPosKf.rootPosition!;
        const b = nextPosKf.rootPosition!;
        pose.rootPosition[0] = a[0] + (b[0] - a[0]) * alpha;
        pose.rootPosition[1] = a[1] + (b[1] - a[1]) * alpha;
        pose.rootPosition[2] = a[2] + (b[2] - a[2]) * alpha;
        return pose;
      }
    }
    const p = nextPosKf.rootPosition!;
    pose.rootPosition[0] = p[0];
    pose.rootPosition[1] = p[1];
    pose.rootPosition[2] = p[2];
  } else if (prevPosKf && !nextPosKf) {
    if (loop && clipDuration > 1e-5 && firstPosKf !== prevPosKf) {
      const span = clipDuration + firstPosKf.time - prevPosKf.time;
      if (span > 1e-5) {
        const rawAlpha = (evalTime - prevPosKf.time) / span;
        const alpha = applyEasing(rawAlpha, firstPosKf.easing);
        const a = prevPosKf.rootPosition!;
        const b = firstPosKf.rootPosition!;
        pose.rootPosition[0] = a[0] + (b[0] - a[0]) * alpha;
        pose.rootPosition[1] = a[1] + (b[1] - a[1]) * alpha;
        pose.rootPosition[2] = a[2] + (b[2] - a[2]) * alpha;
        return pose;
      }
    }
    const p = prevPosKf.rootPosition!;
    pose.rootPosition[0] = p[0];
    pose.rootPosition[1] = p[1];
    pose.rootPosition[2] = p[2];
  } else if (prevPosKf && nextPosKf) {
    if (
      prevPosKf === nextPosKf ||
      Math.abs(nextPosKf.time - prevPosKf.time) < 1e-5
    ) {
      const p = prevPosKf.rootPosition!;
      pose.rootPosition[0] = p[0];
      pose.rootPosition[1] = p[1];
      pose.rootPosition[2] = p[2];
    } else {
      const rawAlpha =
        (evalTime - prevPosKf.time) / (nextPosKf.time - prevPosKf.time);
      const alpha = applyEasing(rawAlpha, nextPosKf.easing);
      const a = prevPosKf.rootPosition!;
      const b = nextPosKf.rootPosition!;
      pose.rootPosition[0] = a[0] + (b[0] - a[0]) * alpha;
      pose.rootPosition[1] = a[1] + (b[1] - a[1]) * alpha;
      pose.rootPosition[2] = a[2] + (b[2] - a[2]) * alpha;
    }
  }

  return pose;
}
