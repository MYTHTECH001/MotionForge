import {
  R15_JOINT_NAMES,
  createNeutralPose,
  type EvaluatedPose,
  type R15JointName,
  type Vec3Tuple,
} from './types.ts';

export type LibraryCategory = 'All' | 'Movement' | 'Combat' | 'Tools' | 'Emotes';

export const PRESET_CATEGORY_MAP: Record<string, Exclude<LibraryCategory, 'All'>> = {
  'net-swing': 'Tools',
  'sword-attack': 'Combat',
  jumping: 'Movement',
  waving: 'Emotes',
  dancing: 'Emotes',
  celebration: 'Emotes',
};

const OPPOSITE_JOINT_MAP: Partial<Record<R15JointName, R15JointName>> = {
  LeftUpperArm: 'RightUpperArm',
  RightUpperArm: 'LeftUpperArm',
  LeftLowerArm: 'RightLowerArm',
  RightLowerArm: 'LeftLowerArm',
  LeftHand: 'RightHand',
  RightHand: 'LeftHand',
  LeftUpperLeg: 'RightUpperLeg',
  RightUpperLeg: 'LeftUpperLeg',
  LeftLowerLeg: 'RightLowerLeg',
  RightLowerLeg: 'LeftLowerLeg',
  LeftFoot: 'RightFoot',
  RightFoot: 'LeftFoot',
};

export function clonePose(pose: EvaluatedPose): EvaluatedPose {
  const joints = {} as Record<R15JointName, Vec3Tuple>;
  for (const j of R15_JOINT_NAMES) {
    joints[j] = [...pose.joints[j]] as Vec3Tuple;
  }
  return {
    joints,
    rootPosition: [...pose.rootPosition] as Vec3Tuple,
  };
}

function mirrorEulerAcrossYZ(rot: Vec3Tuple): Vec3Tuple {
  // Mirroring across the X=0 (YZ) plane preserves X pitch and negates Y yaw and Z roll
  return [
    Math.round(rot[0] * 100) / 100,
    Math.round(-rot[1] * 100) / 100,
    Math.round(-rot[2] * 100) / 100,
  ];
}

/**
 * Mirrors an entire R15 pose across the character's X-axis (Left <-> Right symmetry).
 */
export function mirrorPoseAcrossX(pose: EvaluatedPose): EvaluatedPose {
  const next = createNeutralPose();
  next.rootPosition = [
    Math.round(-pose.rootPosition[0] * 100) / 100,
    pose.rootPosition[1],
    pose.rootPosition[2],
  ];

  for (const j of R15_JOINT_NAMES) {
    const opp = OPPOSITE_JOINT_MAP[j];
    if (opp) {
      next.joints[j] = mirrorEulerAcrossYZ(pose.joints[opp]);
    } else {
      next.joints[j] = mirrorEulerAcrossYZ(pose.joints[j]);
    }
  }
  return next;
}

/**
 * Mirrors the selected joint (or flips centerline joint Y/Z) onto its opposite limb.
 */
export function mirrorJointToOpposite(
  pose: EvaluatedPose,
  joint: R15JointName,
): { pose: EvaluatedPose; targetJoint: R15JointName } {
  const next = clonePose(pose);
  const opp = OPPOSITE_JOINT_MAP[joint];
  if (opp) {
    next.joints[opp] = mirrorEulerAcrossYZ(pose.joints[joint]);
    return { pose: next, targetJoint: opp };
  }
  next.joints[joint] = mirrorEulerAcrossYZ(pose.joints[joint]);
  if (joint === 'HumanoidRootPart') {
    next.rootPosition[0] = -next.rootPosition[0];
  }
  return { pose: next, targetJoint: joint };
}

export function getOppositeJoint(joint: R15JointName): R15JointName | null {
  return OPPOSITE_JOINT_MAP[joint] ?? null;
}

export type SnapIncrementOption = 'frame' | 0.05 | 0.1 | 0.25 | 0.5;

export function resolveSnapStep(
  option: SnapIncrementOption,
  fps: number,
): number {
  if (option === 'frame') {
    return 1 / Math.max(1, fps || 30);
  }
  return option;
}

export function snapTimeToGrid(
  time: number,
  duration: number,
  stepSeconds: number,
): number {
  const safeDur = Math.max(0.01, duration);
  const clamped = Math.max(0, Math.min(safeDur, time));
  if (!(stepSeconds > 0)) {
    return Math.round(clamped * 1000) / 1000;
  }
  const snappedGrid = Math.round(clamped / stepSeconds) * stepSeconds;
  const candidate =
    Math.abs(clamped - safeDur) < Math.abs(clamped - snappedGrid)
      ? safeDur
      : snappedGrid;
  const bounded = Math.max(0, Math.min(safeDur, candidate));
  return Math.round(bounded * 1000) / 1000;
}
