import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { OrbitControls as ThreeOrbitControls } from 'three/addons/controls/OrbitControls.js';
import {
  Grid3x3,
  Bone,
  Layers,
  Maximize2,
  Minimize2,
  SlidersHorizontal,
  Square,
  Columns2,
  LayoutGrid,
} from 'lucide-react';
import {
  R15_JOINT_META,
  type EvaluatedPose,
  type Keyframe,
  type PropType,
  type R15JointName,
} from '../animation/types.ts';
import { R15Character } from '../rig/R15Character.tsx';
import { R15GhostCharacter } from '../rig/R15GhostCharacter.tsx';
import {
  createContactShadowTexture,
  createStudioFloorTexture,
} from '../rig/r15Geometry.ts';

export type CameraPreset = 'perspective' | 'front' | 'side' | 'top';
export type ViewLayout = 'single' | 'split' | 'quad';

const CAMERA_PRESETS: Record<
  CameraPreset,
  { label: string; pos: [number, number, number]; target: [number, number, number] }
> = {
  perspective: { label: 'Perspective', pos: [5.4, 4.1, 6.8], target: [0, 2.4, 0] },
  front: { label: 'Front', pos: [0, 2.8, 7.6], target: [0, 2.4, 0] },
  side: { label: 'Side', pos: [7.6, 2.8, 0], target: [0, 2.4, 0] },
  top: { label: 'Top', pos: [0, 9.2, 2.6], target: [0, 2.2, 0] },
};

const DEFAULT_LAYOUT_PRESETS: Record<ViewLayout, CameraPreset[]> = {
  single: ['perspective'],
  split: ['perspective', 'side'],
  quad: ['perspective', 'front', 'side', 'top'],
};

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) ?? '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return false;
  }
}

function findR15JointFromObject(obj: THREE.Object3D | null): R15JointName | null {
  let curr: THREE.Object3D | null = obj;
  while (curr) {
    if (curr.userData && typeof curr.userData.r15Joint === 'string') {
      return curr.userData.r15Joint as R15JointName;
    }
    curr = curr.parent;
  }
  return null;
}

function StudioEnvironment({
  isSoftwareGl,
  gridVisible,
}: {
  isSoftwareGl: boolean;
  gridVisible: boolean;
}) {
  const { gl, scene } = useThree();

  useEffect(() => {
    gl.outputColorSpace = THREE.SRGBColorSpace;
    gl.toneMapping = THREE.ACESFilmicToneMapping;
    gl.toneMappingExposure = 1.08;

    const pmrem = new THREE.PMREMGenerator(gl);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmrem.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmrem.dispose();

    return () => {
      envTarget.dispose();
    };
  }, [gl, scene]);

  const maxAniso = useMemo(
    () => Math.min(8, gl.capabilities.getMaxAnisotropy()),
    [gl],
  );
  const floorTex = useMemo(() => createStudioFloorTexture(maxAniso), [maxAniso]);
  const shadowTex = useMemo(() => createContactShadowTexture(), []);

  useEffect(() => {
    return () => {
      floorTex.dispose();
      shadowTex.dispose();
    };
  }, [floorTex, shadowTex]);

  return (
    <>
      <color attach="background" args={['#0B0E14']} />
      <fog attach="fog" args={['#0B0E14', 16, 42]} />

      <hemisphereLight args={['#B8D4FF', '#1E2430', 0.65]} />
      <directionalLight
        position={[6, 10, 7]}
        intensity={2.1}
        color="#FFF5E4"
        castShadow={!isSoftwareGl}
        shadow-mapSize={[1024, 1024]}
        shadow-camera-near={1}
        shadow-camera-far={28}
        shadow-camera-left={-6}
        shadow-camera-right={6}
        shadow-camera-top={7}
        shadow-camera-bottom={-3}
        shadow-bias={-0.0005}
        shadow-normalBias={0.02}
      />
      <directionalLight position={[-6, 5, -6]} intensity={0.9} color="#7DD3FC" />

      {gridVisible && (
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
          <circleGeometry args={[24, 48]} />
          <meshStandardMaterial
            map={floorTex}
            roughness={0.85}
            metalness={0.08}
          />
        </mesh>
      )}

      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.008, 0]}>
        <planeGeometry args={[3.4, 3.4]} />
        <meshBasicMaterial
          map={shadowTex}
          transparent
          opacity={0.75}
          depthWrite={false}
        />
      </mesh>
    </>
  );
}

interface PaneRuntime {
  camera: THREE.PerspectiveCamera;
  controls: ThreeOrbitControls | null;
  domElement: HTMLDivElement | null;
  animating: boolean;
  posTarget: THREE.Vector3;
  lookTarget: THREE.Vector3;
}

const _raycaster = new THREE.Raycaster();
const _ndc = new THREE.Vector2();

function MultiViewRig({
  paneCount,
  panePresets,
  paneDomRefs,
  cameraRequest,
  isSoftwareGl,
  onRegisterPicker,
}: {
  paneCount: number;
  panePresets: CameraPreset[];
  paneDomRefs: React.MutableRefObject<(HTMLDivElement | null)[]>;
  cameraRequest: { paneIndex: number; preset: CameraPreset; seq: number } | null;
  isSoftwareGl: boolean;
  onRegisterPicker: (
    fn: (paneIndex: number, clientX: number, clientY: number) => R15JointName | null,
  ) => void;
}) {
  const { gl, scene, size } = useThree();
  const lastSeqRef = useRef(0);

  const runtimesRef = useRef<PaneRuntime[]>(
    (['perspective', 'front', 'side', 'top'] as CameraPreset[]).map((preset) => {
      const cfg = CAMERA_PRESETS[preset];
      const cam = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
      cam.position.set(...cfg.pos);
      cam.lookAt(...cfg.target);
      return {
        camera: cam,
        controls: null,
        domElement: null,
        animating: false,
        posTarget: new THREE.Vector3(...cfg.pos),
        lookTarget: new THREE.Vector3(...cfg.target),
      };
    }),
  );

  // Sync OrbitControls instances to the active pane overlay divs
  useEffect(() => {
    const runtimes = runtimesRef.current;

    for (let i = 0; i < 4; i++) {
      const rt = runtimes[i];
      const shouldAttach = i < paneCount ? paneDomRefs.current[i] : null;

      if (rt.domElement !== shouldAttach) {
        if (rt.controls) {
          rt.controls.dispose();
          rt.controls = null;
        }
        rt.domElement = shouldAttach;

        if (shouldAttach) {
          const presetCfg = CAMERA_PRESETS[panePresets[i] ?? 'perspective'];
          const ctrl = new ThreeOrbitControls(rt.camera, shouldAttach);
          ctrl.target.set(...presetCfg.target);
          ctrl.enableDamping = !isSoftwareGl;
          ctrl.dampingFactor = 0.07;
          ctrl.minDistance = 3.2;
          ctrl.maxDistance = 18;
          ctrl.maxPolarAngle = Math.PI * 0.49;
          ctrl.addEventListener('start', () => {
            rt.animating = false;
          });
          ctrl.update();
          rt.controls = ctrl;
        }
      }
    }
  }, [paneCount, panePresets, paneDomRefs, isSoftwareGl]);

  // Dispose controls and restore viewport on unmount
  useEffect(() => {
    const runtimes = runtimesRef.current;
    return () => {
      for (const rt of runtimes) {
        rt.controls?.dispose();
        rt.controls = null;
        rt.domElement = null;
      }
      gl.setScissorTest(false);
    };
  }, [gl]);

  // Trigger camera preset transition on requested pane
  useEffect(() => {
    if (!cameraRequest || cameraRequest.seq === lastSeqRef.current) return;
    lastSeqRef.current = cameraRequest.seq;
    const rt = runtimesRef.current[cameraRequest.paneIndex];
    if (!rt) return;
    const cfg = CAMERA_PRESETS[cameraRequest.preset];
    rt.posTarget.set(...cfg.pos);
    rt.lookTarget.set(...cfg.target);
    rt.animating = true;
  }, [cameraRequest]);

  // Reset camera positions cleanly when pane presets change on layout switch
  const prevPaneCountRef = useRef(paneCount);
  useEffect(() => {
    if (paneCount !== prevPaneCountRef.current) {
      for (let i = 1; i < paneCount; i++) {
        const rt = runtimesRef.current[i];
        const cfg = CAMERA_PRESETS[panePresets[i] ?? 'side'];
        rt.camera.position.set(...cfg.pos);
        rt.posTarget.set(...cfg.pos);
        rt.lookTarget.set(...cfg.target);
        rt.animating = false;
        if (rt.controls) {
          rt.controls.target.set(...cfg.target);
          rt.controls.update();
        }
      }
      prevPaneCountRef.current = paneCount;
    }
  }, [paneCount, panePresets]);

  // Expose raycast picker for all panes
  useEffect(() => {
    onRegisterPicker((paneIndex, clientX, clientY) => {
      const rt = runtimesRef.current[paneIndex];
      const el = paneDomRefs.current[paneIndex];
      if (!rt || !el) return null;
      const rect = el.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) return null;
      _ndc.set(
        ((clientX - rect.left) / rect.width) * 2 - 1,
        -((clientY - rect.top) / rect.height) * 2 + 1,
      );
      _raycaster.setFromCamera(_ndc, rt.camera);
      const hits = _raycaster.intersectObjects(scene.children, true);
      for (let i = 0; i < hits.length; i++) {
        const joint = findR15JointFromObject(hits[i].object);
        if (joint) return joint;
      }
      return null;
    });
  }, [onRegisterPicker, paneDomRefs, scene]);

  // Priority-1 scissor render pass across all active panes
  useFrame((_state, delta) => {
    const canvasRect = gl.domElement.getBoundingClientRect();
    if (canvasRect.width <= 0 || canvasRect.height <= 0) return;

    const dt = Math.min(delta, 0.05);
    const alpha = 1 - Math.exp(-8 * dt);
    const prevAutoClear = gl.autoClear;
    gl.autoClear = false;
    gl.setClearColor('#0B0E14', 1);

    for (let i = 0; i < paneCount; i++) {
      const rt = runtimesRef.current[i];
      const paneEl = paneDomRefs.current[i];
      if (!rt || !paneEl) continue;

      if (rt.animating && rt.controls) {
        rt.camera.position.lerp(rt.posTarget, alpha);
        rt.controls.target.lerp(rt.lookTarget, alpha);
        if (
          rt.camera.position.distanceTo(rt.posTarget) < 0.02 &&
          rt.controls.target.distanceTo(rt.lookTarget) < 0.02
        ) {
          rt.camera.position.copy(rt.posTarget);
          rt.controls.target.copy(rt.lookTarget);
          rt.animating = false;
        }
      }

      rt.controls?.update();

      const paneRect = paneEl.getBoundingClientRect();
      const width = paneRect.width;
      const height = paneRect.height;
      if (width <= 2 || height <= 2) continue;

      const left = paneRect.left - canvasRect.left;
      const bottom = canvasRect.bottom - paneRect.bottom;

      const nextAspect = width / height;
      if (Math.abs(rt.camera.aspect - nextAspect) > 1e-4) {
        rt.camera.aspect = nextAspect;
        rt.camera.updateProjectionMatrix();
      }

      gl.setViewport(left, bottom, width, height);
      gl.setScissor(left, bottom, width, height);
      gl.setScissorTest(true);
      gl.clear(true, true, true);
      gl.render(scene, rt.camera);
    }

    gl.setScissorTest(false);
    gl.autoClear = prevAutoClear;
    gl.setViewport(0, 0, size.width, size.height);
  }, 1);

  return null;
}

interface Viewport3DProps {
  keyframes: Keyframe[];
  duration: number;
  isPlaying: boolean;
  loop: boolean;
  playbackSpeed: number;
  currentTimeRef: React.MutableRefObject<number>;
  onTimeTick: (time: number, ended?: boolean) => void;
  selectedJoint: R15JointName | null;
  onSelectJoint: (joint: R15JointName) => void;
  showSkeleton: boolean;
  onToggleSkeleton: () => void;
  gridVisible: boolean;
  onToggleGrid: () => void;
  onionSkinEnabled: boolean;
  onToggleOnionSkin: () => void;
  onionOpacity: number;
  prevGhostPose: EvaluatedPose | null;
  nextGhostPose: EvaluatedPose | null;
  viewLayout: ViewLayout;
  onChangeViewLayout: (layout: ViewLayout) => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  inspectorOpen: boolean;
  onOpenInspector: () => void;
  prop: PropType;
  manualPoseOverride: EvaluatedPose | null;
  previewBanner?: {
    name: string;
    onApply: () => void;
    onCancel: () => void;
  } | null;
}

export function Viewport3D({
  keyframes,
  duration,
  isPlaying,
  loop,
  playbackSpeed,
  currentTimeRef,
  onTimeTick,
  selectedJoint,
  onSelectJoint,
  showSkeleton,
  onToggleSkeleton,
  gridVisible,
  onToggleGrid,
  onionSkinEnabled,
  onToggleOnionSkin,
  onionOpacity,
  prevGhostPose,
  nextGhostPose,
  viewLayout,
  onChangeViewLayout,
  isFullscreen,
  onToggleFullscreen,
  inspectorOpen,
  onOpenInspector,
  prop,
  manualPoseOverride,
  previewBanner,
}: Viewport3DProps) {
  const isSoftwareGl = useMemo(() => detectSoftwareWebGL(), []);
  const [hoveredJoint, setHoveredJoint] = useState<R15JointName | null>(null);
  const [contextLost, setContextLost] = useState(false);
  const [focusedPane, setFocusedPane] = useState(0);
  const [panePresets, setPanePresets] = useState<CameraPreset[]>(
    DEFAULT_LAYOUT_PRESETS[viewLayout],
  );
  const [cameraRequest, setCameraRequest] = useState<{
    paneIndex: number;
    preset: CameraPreset;
    seq: number;
  } | null>(null);

  const paneDomRefs = useRef<(HTMLDivElement | null)[]>([
    null,
    null,
    null,
    null,
  ]);
  const pickerRef = useRef<
    ((paneIndex: number, clientX: number, clientY: number) => R15JointName | null) | null
  >(null);
  const downInfoRef = useRef<{ x: number; y: number; paneIndex: number } | null>(
    null,
  );

  // Sync pane presets when layout changes
  useEffect(() => {
    setPanePresets(DEFAULT_LAYOUT_PRESETS[viewLayout]);
    setFocusedPane((curr) =>
      Math.min(curr, DEFAULT_LAYOUT_PRESETS[viewLayout].length - 1),
    );
  }, [viewLayout]);

  const registerPicker = useCallback(
    (
      fn: (
        paneIndex: number,
        clientX: number,
        clientY: number,
      ) => R15JointName | null,
    ) => {
      pickerRef.current = fn;
    },
    [],
  );

  const requestCamera = (preset: CameraPreset) => {
    const targetPane =
      focusedPane < panePresets.length ? focusedPane : 0;
    setPanePresets((prev) =>
      prev.map((p, idx) => (idx === targetPane ? preset : p)),
    );
    setCameraRequest((prev) => ({
      paneIndex: targetPane,
      preset,
      seq: (prev?.seq ?? 0) + 1,
    }));
  };

  const handlePanePointerDown = (
    paneIndex: number,
    e: React.PointerEvent<HTMLDivElement>,
  ) => {
    setFocusedPane(paneIndex);
    downInfoRef.current = { x: e.clientX, y: e.clientY, paneIndex };
  };

  const handlePanePointerUp = (
    paneIndex: number,
    e: React.PointerEvent<HTMLDivElement>,
  ) => {
    const down = downInfoRef.current;
    downInfoRef.current = null;
    if (!down || down.paneIndex !== paneIndex || e.button !== 0) return;
    if (Math.hypot(e.clientX - down.x, e.clientY - down.y) < 5) {
      const hit = pickerRef.current?.(paneIndex, e.clientX, e.clientY);
      if (hit) {
        onSelectJoint(hit);
      }
    }
  };

  const handlePanePointerMove = (
    paneIndex: number,
    e: React.PointerEvent<HTMLDivElement>,
  ) => {
    if (e.buttons !== 0) return;
    const hit = pickerRef.current?.(paneIndex, e.clientX, e.clientY) ?? null;
    setHoveredJoint(hit);
    e.currentTarget.style.cursor = hit ? 'pointer' : 'grab';
  };

  const paneCount = panePresets.length;
  const gridClass =
    viewLayout === 'quad'
      ? 'grid-cols-2 grid-rows-2'
      : viewLayout === 'split'
        ? 'grid-cols-2 grid-rows-1'
        : 'grid-cols-1 grid-rows-1';

  return (
    <div className="relative w-full h-full bg-[#0B0E14] select-none overflow-hidden">
      {contextLost ? (
        <div className="flex flex-col items-center justify-center w-full h-full text-slate-300 gap-2 p-6 text-center">
          <p className="text-sm font-medium">3D WebGL context paused</p>
          <p className="text-xs text-slate-400">
            Restoring hardware graphics surface...
          </p>
        </div>
      ) : (
        <>
          <Canvas
            shadows={!isSoftwareGl}
            dpr={isSoftwareGl ? 1 : [1, 2]}
            camera={{ position: [5.4, 4.1, 6.8], fov: 42, near: 0.1, far: 100 }}
            gl={{
              antialias: !isSoftwareGl,
              powerPreference: 'high-performance',
              toneMapping: THREE.ACESFilmicToneMapping,
            }}
            onCreated={({ gl }) => {
              const canvas = gl.domElement;
              canvas.addEventListener('webglcontextlost', (e) => {
                e.preventDefault();
                setContextLost(true);
              });
              canvas.addEventListener('webglcontextrestored', () => {
                setContextLost(false);
              });
            }}
          >
            <StudioEnvironment
              isSoftwareGl={isSoftwareGl}
              gridVisible={gridVisible}
            />

            {/* Onion Skin Ghost Frames (Prev Keyframe = Sky Blue, Next Keyframe = Emerald) */}
            {onionSkinEnabled && prevGhostPose && (
              <R15GhostCharacter
                pose={prevGhostPose}
                color="#38BDF8"
                opacity={onionOpacity}
              />
            )}
            {onionSkinEnabled && nextGhostPose && (
              <R15GhostCharacter
                pose={nextGhostPose}
                color="#34D399"
                opacity={onionOpacity}
              />
            )}

            <R15Character
              keyframes={keyframes}
              duration={duration}
              isPlaying={isPlaying}
              loop={loop}
              playbackSpeed={playbackSpeed}
              currentTimeRef={currentTimeRef}
              onTimeTick={onTimeTick}
              selectedJoint={selectedJoint}
              hoveredJoint={hoveredJoint}
              onSelectJoint={onSelectJoint}
              onHoverJoint={setHoveredJoint}
              showSkeleton={showSkeleton}
              prop={prop}
              manualPoseOverride={manualPoseOverride}
              isDriver
            />

            <MultiViewRig
              paneCount={paneCount}
              panePresets={panePresets}
              paneDomRefs={paneDomRefs}
              cameraRequest={cameraRequest}
              isSoftwareGl={isSoftwareGl}
              onRegisterPicker={registerPicker}
            />
          </Canvas>

          {/* Interactive Pane Overlays (1, 2, or 4 independent camera regions) */}
          <div className={`absolute inset-0 grid ${gridClass}`}>
            {panePresets.map((preset, idx) => {
              const isFocused = focusedPane === idx && paneCount > 1;
              return (
                <div
                  key={`${viewLayout}-${idx}`}
                  ref={(el) => {
                    paneDomRefs.current[idx] = el;
                  }}
                  onPointerDown={(e) => handlePanePointerDown(idx, e)}
                  onPointerUp={(e) => handlePanePointerUp(idx, e)}
                  onPointerMove={(e) => handlePanePointerMove(idx, e)}
                  onPointerLeave={() => setHoveredJoint(null)}
                  className={`relative w-full h-full touch-none ${
                    paneCount > 1
                      ? isFocused
                        ? 'border border-[#3B82F6]/70'
                        : 'border border-[#232B3E]'
                      : ''
                  }`}
                >
                  {paneCount > 1 && (
                    <div
                      className={`pointer-events-none absolute bottom-2 right-2.5 px-1.5 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider bg-[#111622]/90 border ${
                        isFocused
                          ? 'border-[#3B82F6]/70 text-sky-300'
                          : 'border-[#232B3E] text-slate-400'
                      }`}
                    >
                      {CAMERA_PRESETS[preset].label}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}

      {/* Top Overlay Row: Selected Joint Indicator (Left) & Camera/View Layout Controls (Right) */}
      <div className="pointer-events-none absolute top-3 inset-x-3 z-10 flex flex-wrap items-start justify-between gap-2">
        <div className="pointer-events-auto flex flex-col items-start gap-2">
          <div className="flex items-center gap-2 bg-[#111622]/95 border border-[#232B3E] rounded-md px-2.5 py-1.5 text-xs">
            {selectedJoint ? (
              <>
                <span className="text-amber-400 font-medium whitespace-nowrap">
                  {selectedJoint}
                </span>
                <span className="text-slate-600" aria-hidden="true">
                  ·
                </span>
                <span className="text-slate-400 font-mono text-[11px] whitespace-nowrap">
                  {R15_JOINT_META[selectedJoint].motorName}
                </span>
              </>
            ) : (
              <span className="text-slate-400 whitespace-nowrap">
                Click any limb to inspect joint
              </span>
            )}
            {hoveredJoint && hoveredJoint !== selectedJoint && (
              <>
                <span className="text-slate-600" aria-hidden="true">
                  /
                </span>
                <span className="text-sky-400 whitespace-nowrap">
                  {hoveredJoint}
                </span>
              </>
            )}
          </div>

          {previewBanner && (
            <div className="flex items-center gap-3 bg-[#111622] border border-[#3B82F6]/60 rounded-md px-3 py-2 text-xs shadow-lg">
              <span className="text-slate-200 whitespace-nowrap">
                Previewing: <strong>{previewBanner.name}</strong>
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={previewBanner.onApply}
                  className="px-2.5 py-1 bg-[#3B82F6] hover:bg-[#2563EB] text-white font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Apply
                </button>
                <button
                  type="button"
                  onClick={previewBanner.onCancel}
                  className="px-2.5 py-1 bg-[#1A2133] hover:bg-[#232C42] text-slate-300 rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Top-Right Compact Camera, View Layout (1 / 2 / 4 Views) & Viewport Controls */}
        <div className="pointer-events-auto flex items-center gap-1 bg-[#111622]/95 border border-[#232B3E] rounded-md p-1 flex-wrap">
          {(
            [
              ['perspective', 'Perspective'],
              ['front', 'Front'],
              ['side', 'Side'],
              ['top', 'Top'],
            ] as [CameraPreset, string][]
          ).map(([preset, label]) => (
            <button
              key={preset}
              type="button"
              title={`Set ${paneCount > 1 ? `pane ${focusedPane + 1}` : 'camera'} to ${label} view`}
              onClick={() => requestCamera(preset)}
              className="px-2 py-1 text-xs font-medium text-slate-300 hover:text-white hover:bg-[#1B2233] rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#3B82F6]"
            >
              {label}
            </button>
          ))}

          <div className="w-px h-4 bg-[#232B3E] mx-0.5" />

          {/* View Layout Switcher: Single / 2-Split / Quad */}
          <button
            type="button"
            onClick={() => onChangeViewLayout('single')}
            title="Single Viewport"
            aria-pressed={viewLayout === 'single'}
            className={`p-1.5 rounded transition-colors cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#3B82F6] ${
              viewLayout === 'single'
                ? 'bg-[#1D2842] text-[#60A5FA]'
                : 'text-slate-400 hover:text-white hover:bg-[#1B2233]'
            }`}
          >
            <Square className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onChangeViewLayout('split')}
            title="Dual Split View (Perspective + Side)"
            aria-pressed={viewLayout === 'split'}
            className={`p-1.5 rounded transition-colors cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#3B82F6] ${
              viewLayout === 'split'
                ? 'bg-[#1D2842] text-[#60A5FA]'
                : 'text-slate-400 hover:text-white hover:bg-[#1B2233]'
            }`}
          >
            <Columns2 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onChangeViewLayout('quad')}
            title="Quad View (Perspective, Front, Side, Top)"
            aria-pressed={viewLayout === 'quad'}
            className={`p-1.5 rounded transition-colors cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#3B82F6] ${
              viewLayout === 'quad'
                ? 'bg-[#1D2842] text-[#60A5FA]'
                : 'text-slate-400 hover:text-white hover:bg-[#1B2233]'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
          </button>

          <div className="w-px h-4 bg-[#232B3E] mx-0.5" />

          <button
            type="button"
            onClick={onToggleGrid}
            title="Toggle studio floor grid (G)"
            aria-pressed={gridVisible}
            className={`p-1.5 rounded transition-colors cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#3B82F6] ${
              gridVisible
                ? 'bg-[#1D2842] text-[#60A5FA]'
                : 'text-slate-400 hover:text-white hover:bg-[#1B2233]'
            }`}
          >
            <Grid3x3 className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={onToggleSkeleton}
            title="Toggle R15 joint gizmos (J)"
            aria-pressed={showSkeleton}
            className={`p-1.5 rounded transition-colors cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#3B82F6] ${
              showSkeleton
                ? 'bg-[#1D2842] text-[#60A5FA]'
                : 'text-slate-400 hover:text-white hover:bg-[#1B2233]'
            }`}
          >
            <Bone className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={onToggleOnionSkin}
            title="Toggle Onion Skinning prev/next ghosts (O)"
            aria-pressed={onionSkinEnabled}
            className={`p-1.5 rounded transition-colors cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#3B82F6] ${
              onionSkinEnabled
                ? 'bg-[#1D2842] text-[#38BDF8]'
                : 'text-slate-400 hover:text-white hover:bg-[#1B2233]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={onToggleFullscreen}
            title={isFullscreen ? 'Exit fullscreen viewport (Esc)' : 'Fullscreen viewport'}
            aria-pressed={isFullscreen}
            className={`p-1.5 rounded transition-colors cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#3B82F6] ${
              isFullscreen
                ? 'bg-[#3B82F6] text-white'
                : 'text-slate-400 hover:text-white hover:bg-[#1B2233]'
            }`}
          >
            {isFullscreen ? (
              <Minimize2 className="w-3.5 h-3.5" />
            ) : (
              <Maximize2 className="w-3.5 h-3.5" />
            )}
          </button>

          {!inspectorOpen && (
            <>
              <div className="w-px h-4 bg-[#232B3E] mx-0.5" />
              <button
                type="button"
                onClick={onOpenInspector}
                title="Open Joint Inspector"
                className="flex items-center gap-1 px-2 py-1 text-xs font-medium text-slate-300 hover:text-white hover:bg-[#1B2233] rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Inspector</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Bottom-Left Controls Hint & Onion Legend */}
      <div className="pointer-events-none absolute bottom-2.5 left-3 flex items-center gap-3 text-[11px] text-slate-500 z-10">
        <span>Click limb to select · Drag to orbit · Scroll to zoom</span>
        {onionSkinEnabled && (
          <span className="flex items-center gap-2 text-slate-400">
            <span aria-hidden="true">·</span>
            <span className="text-sky-400">Prev Key</span>
            <span className="text-emerald-400">Next Key</span>
          </span>
        )}
      </div>
    </div>
  );
}
