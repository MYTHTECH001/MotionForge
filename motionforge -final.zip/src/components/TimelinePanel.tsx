import React, { useMemo, useRef, useState } from 'react';
import {
  Play,
  Pause,
  Square,
  Repeat,
  Plus,
  Trash2,
  Copy,
  SkipBack,
  SkipForward,
  ChevronDown,
  ChevronUp,
  ZoomIn,
  ZoomOut,
  Activity,
  Magnet,
} from 'lucide-react';
import type { EasingMode, Keyframe } from '../animation/types.ts';
import {
  applyEasing,
  computePoseDeltaMagnitude,
  evaluatePoseAtTime,
  getEasingVelocity,
} from '../animation/interpolation.ts';
import {
  resolveSnapStep,
  snapTimeToGrid,
  type SnapIncrementOption,
} from '../animation/poseUtils.ts';

interface TimelinePanelProps {
  height: number;
  keyframes: Keyframe[];
  duration: number;
  fps: number;
  currentTime: number;
  isPlaying: boolean;
  loop: boolean;
  playbackSpeed: number;
  selectedKeyframeId: string | null;
  snapEnabled: boolean;
  snapIncrement: SnapIncrementOption;
  onToggleSnap: () => void;
  onChangeSnapIncrement: (inc: SnapIncrementOption) => void;
  onTogglePlay: () => void;
  onStop: () => void;
  onToggleLoop: () => void;
  onChangeSpeed: (speed: number) => void;
  onChangeDuration: (duration: number) => void;
  onScrub: (time: number) => void;
  onSelectKeyframe: (kf: Keyframe) => void;
  onBeginMoveKeyframe?: () => void;
  onMoveKeyframe: (kfId: string, newTime: number) => void;
  onChangeKeyframeEasing?: (kfId: string, easing: EasingMode) => void;
  onAddKeyframeAtPlayhead: () => void;
  onDuplicateKeyframe: (kfId: string) => void;
  onDeleteKeyframe: (kfId: string) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onStartResizeHeight: (e: React.PointerEvent<HTMLDivElement>) => void;
}

const SPEEDS = [0.25, 0.5, 1, 1.5, 2];

const EASING_ORDER: EasingMode[] = [
  'easeInOut',
  'easeOut',
  'easeIn',
  'linear',
  'constant',
  'bounce',
  'elastic',
];

const EASING_META: Record<
  EasingMode,
  { short: string; label: string; color: string; textClass: string }
> = {
  easeInOut: {
    short: 'In-Out',
    label: 'Ease In-Out',
    color: '#3B82F6',
    textClass: 'text-blue-400',
  },
  easeOut: {
    short: 'Out',
    label: 'Ease Out (Decelerate)',
    color: '#10B981',
    textClass: 'text-emerald-400',
  },
  easeIn: {
    short: 'In',
    label: 'Ease In (Accelerate)',
    color: '#F59E0B',
    textClass: 'text-amber-400',
  },
  linear: {
    short: 'Lin',
    label: 'Linear',
    color: '#64748B',
    textClass: 'text-slate-400',
  },
  constant: {
    short: 'Const',
    label: 'Constant (Step Hold)',
    color: '#A855F7',
    textClass: 'text-purple-400',
  },
  bounce: {
    short: 'Bnc',
    label: 'Bounce (Ease Out)',
    color: '#EC4899',
    textClass: 'text-pink-400',
  },
  elastic: {
    short: 'Elast',
    label: 'Elastic (Spring)',
    color: '#06B6D4',
    textClass: 'text-cyan-400',
  },
};

interface VelocitySegment {
  id: string;
  targetKeyframeId: string;
  startTime: number;
  endTime: number;
  startPct: number;
  widthPct: number;
  easing: EasingMode;
  deltaDeg: number;
  isHold: boolean;
  areaPath: string;
  linePath: string;
  spacingTicksPct: number[];
}

function buildVelocitySegmentPaths(
  easing: EasingMode,
  amplitudeScale: number,
): { areaPath: string; linePath: string; spacingTicksPct: number[] } {
  const steps = 24;
  const baselineY = 38;
  const maxLift = 30 * amplitudeScale;
  const points: string[] = [];

  for (let i = 0; i <= steps; i++) {
    const u = i / steps;
    const x = Number((u * 100).toFixed(2));
    const normVel = getEasingVelocity(u, easing) / 3;
    const y = Number((baselineY - normVel * maxLift).toFixed(2));
    points.push(`${i === 0 ? 'M' : 'L'} ${x} ${y}`);
  }

  const linePath = points.join(' ');
  const areaPath = `${linePath} L 100 ${baselineY} L 0 ${baselineY} Z`;

  const spacingTicksPct: number[] = [];
  for (let k = 1; k <= 9; k++) {
    spacingTicksPct.push(
      Number((applyEasing(k / 10, easing) * 100).toFixed(2)),
    );
  }

  return { areaPath, linePath, spacingTicksPct };
}

export function TimelinePanel({
  height,
  keyframes,
  duration,
  fps,
  currentTime,
  isPlaying,
  loop,
  playbackSpeed,
  selectedKeyframeId,
  snapEnabled,
  snapIncrement,
  onToggleSnap,
  onChangeSnapIncrement,
  onTogglePlay,
  onStop,
  onToggleLoop,
  onChangeSpeed,
  onChangeDuration,
  onScrub,
  onSelectKeyframe,
  onBeginMoveKeyframe,
  onMoveKeyframe,
  onChangeKeyframeEasing,
  onAddKeyframeAtPlayhead,
  onDuplicateKeyframe,
  onDeleteKeyframe,
  isCollapsed,
  onToggleCollapse,
  onStartResizeHeight,
}: TimelinePanelProps) {
  const trackRef = useRef<HTMLDivElement | null>(null);
  const [zoom, setZoom] = useState(1);
  const [showVelocity, setShowVelocity] = useState(true);
  const [draggingKf, setDraggingKf] = useState<{
    id: string;
    time: number;
    snapped: boolean;
  } | null>(null);

  const snapStepSeconds = useMemo(
    () => resolveSnapStep(snapIncrement, fps),
    [snapIncrement, fps],
  );

  const snapGridLinesPct = useMemo(() => {
    if (!snapEnabled || !(snapStepSeconds > 0)) return [];
    const safeDur = Math.max(0.01, duration);
    const total = Math.floor(safeDur / snapStepSeconds);
    if (total > 75) return [];
    const lines: number[] = [];
    for (let i = 1; i <= total; i++) {
      const t = i * snapStepSeconds;
      if (t < safeDur - 0.002) {
        lines.push((t / safeDur) * 100);
      }
    }
    return lines;
  }, [snapEnabled, snapStepSeconds, duration]);

  const sortedKeyframes = useMemo(
    () => [...keyframes].sort((a, b) => a.time - b.time),
    [keyframes],
  );

  const velocitySegments = useMemo<VelocitySegment[]>(() => {
    if (!showVelocity || sortedKeyframes.length < 2) return [];
    const safeDur = Math.max(0.01, duration);
    const segments: VelocitySegment[] = [];

    for (let i = 0; i < sortedKeyframes.length - 1; i++) {
      const kfA = sortedKeyframes[i];
      const kfB = sortedKeyframes[i + 1];
      const span = kfB.time - kfA.time;
      if (span <= 0.005) continue;

      const poseA = evaluatePoseAtTime(sortedKeyframes, kfA.time);
      const poseB = evaluatePoseAtTime(sortedKeyframes, kfB.time);
      const deltaDeg = computePoseDeltaMagnitude(poseA, poseB);
      const isHold = deltaDeg < 0.5;
      const amplitudeScale = isHold
        ? 0
        : 0.42 + 0.58 * Math.min(1, deltaDeg / 90);

      const { areaPath, linePath, spacingTicksPct } = buildVelocitySegmentPaths(
        kfB.easing,
        amplitudeScale,
      );

      segments.push({
        id: `${kfA.id}->${kfB.id}`,
        targetKeyframeId: kfB.id,
        startTime: kfA.time,
        endTime: kfB.time,
        startPct: (kfA.time / safeDur) * 100,
        widthPct: (span / safeDur) * 100,
        easing: kfB.easing,
        deltaDeg,
        isHold,
        areaPath,
        linePath,
        spacingTicksPct,
      });
    }

    return segments;
  }, [showVelocity, sortedKeyframes, duration]);

  const ticks = useMemo(() => {
    const baseStep =
      duration <= 1.5
        ? 0.1
        : duration <= 4
          ? 0.25
          : duration <= 12
            ? 0.5
            : 1.0;
    const step = zoom >= 2.5 && baseStep > 0.1 ? baseStep / 2 : baseStep;
    const majorEvery =
      duration <= 1.5 ? 0.5 : duration <= 10 ? 1 : duration <= 20 ? 2 : 5;
    const count = Math.floor(duration / step) + 1;
    const list: { time: number; major: boolean }[] = [];
    for (let i = 0; i < count; i++) {
      const t = Math.round(i * step * 100) / 100;
      const mod = t % majorEvery;
      const major = mod < 0.01 || Math.abs(mod - majorEvery) < 0.01;
      list.push({ time: t, major });
    }
    return list;
  }, [duration, zoom]);

  const rawTimeFromPointer = (clientX: number): number => {
    const el = trackRef.current;
    if (!el) return 0;
    const rect = el.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    return Math.round(ratio * duration * 1000) / 1000;
  };

  const handleTrackPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    const t = Math.round(rawTimeFromPointer(e.clientX) * 100) / 100;
    onScrub(t);

    const onMove = (ev: PointerEvent) => {
      onScrub(Math.round(rawTimeFromPointer(ev.clientX) * 100) / 100);
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const handleKeyframePointerDown = (
    e: React.PointerEvent<HTMLButtonElement>,
    kf: Keyframe,
  ) => {
    e.stopPropagation();
    e.preventDefault();
    onSelectKeyframe(kf);
    let moved = false;
    setDraggingKf({ id: kf.id, time: kf.time, snapped: snapEnabled && !e.shiftKey });

    const onMove = (ev: PointerEvent) => {
      if (!moved) {
        moved = true;
        onBeginMoveKeyframe?.();
      }
      const rawTime = rawTimeFromPointer(ev.clientX);
      const useSnap = snapEnabled && !ev.shiftKey;
      const nextTime = useSnap
        ? snapTimeToGrid(rawTime, duration, snapStepSeconds)
        : Math.round(rawTime * 100) / 100;
      setDraggingKf({ id: kf.id, time: nextTime, snapped: useSnap });
      onMoveKeyframe(kf.id, nextTime);
      onScrub(nextTime);
    };
    const onUp = () => {
      setDraggingKf(null);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const cycleSegmentEasing = (
    e: React.MouseEvent<HTMLButtonElement>,
    seg: VelocitySegment,
  ) => {
    e.stopPropagation();
    if (!onChangeKeyframeEasing) return;
    const idx = EASING_ORDER.indexOf(seg.easing);
    const next = EASING_ORDER[(idx + 1) % EASING_ORDER.length];
    onChangeKeyframeEasing(seg.targetKeyframeId, next);
  };

  const jumpPrevKeyframe = () => {
    const prev = [...sortedKeyframes]
      .reverse()
      .find((k) => k.time < currentTime - 0.015);
    if (prev) onSelectKeyframe(prev);
    else if (sortedKeyframes[0]) onSelectKeyframe(sortedKeyframes[0]);
  };

  const jumpNextKeyframe = () => {
    const next = sortedKeyframes.find((k) => k.time > currentTime + 0.015);
    if (next) onSelectKeyframe(next);
    else if (sortedKeyframes[sortedKeyframes.length - 1]) {
      onSelectKeyframe(sortedKeyframes[sortedKeyframes.length - 1]);
    }
  };

  const playheadPct = Math.max(
    0,
    Math.min(100, (currentTime / Math.max(0.01, duration)) * 100),
  );

  return (
    <section
      style={{ height: isCollapsed ? 40 : height }}
      className="shrink-0 bg-[#111622] border-t border-[#232B3E] flex flex-col select-none relative"
    >
      {/* Top Resize Handle when expanded */}
      {!isCollapsed && (
        <div
          onPointerDown={onStartResizeHeight}
          title="Drag to resize timeline height"
          className="h-1.5 -mt-0.5 w-full cursor-row-resize hover:bg-[#3B82F6]/40 transition-colors shrink-0"
        />
      )}

      {/* Compact Transport Bar */}
      <div className="h-10 px-3 border-b border-[#232B3E] flex items-center justify-between gap-2 shrink-0">
        {/* Left: Transport */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onStop}
            title="Stop & Rewind to 0.00s"
            className="p-1.5 text-slate-300 hover:text-white hover:bg-[#1B2233] rounded transition-colors cursor-pointer"
          >
            <Square className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={jumpPrevKeyframe}
            title="Previous Keyframe"
            className="p-1.5 text-slate-300 hover:text-white hover:bg-[#1B2233] rounded transition-colors cursor-pointer"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={onTogglePlay}
            title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
            className="flex items-center gap-1 px-2.5 py-1 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {isPlaying ? (
              <Pause className="w-3.5 h-3.5" />
            ) : (
              <Play className="w-3.5 h-3.5" />
            )}
            <span>{isPlaying ? 'Pause' : 'Play'}</span>
          </button>

          <button
            type="button"
            onClick={jumpNextKeyframe}
            title="Next Keyframe"
            className="p-1.5 text-slate-300 hover:text-white hover:bg-[#1B2233] rounded transition-colors cursor-pointer"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={onToggleLoop}
            title="Toggle Loop Playback"
            aria-pressed={loop}
            className={`p-1.5 rounded transition-colors cursor-pointer ${
              loop
                ? 'bg-[#1D2842] text-[#60A5FA]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#1B2233]'
            }`}
          >
            <Repeat className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Center: Timecode, Speed, Duration */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div
            title="Current Playhead Time"
            className="text-xs font-mono tabular-nums text-slate-100 bg-[#0B0E14] border border-[#232B3E] rounded px-2 py-0.5"
          >
            {currentTime.toFixed(2)}s
          </div>

          <div className="hidden md:flex items-center gap-0.5 bg-[#0B0E14] border border-[#232B3E] rounded p-0.5">
            {SPEEDS.map((spd) => (
              <button
                key={spd}
                type="button"
                title={`Playback speed ${spd}x`}
                onClick={() => onChangeSpeed(spd)}
                className={`px-1.5 py-0.5 text-[11px] font-mono tabular-nums rounded transition-colors cursor-pointer ${
                  playbackSpeed === spd
                    ? 'bg-[#3B82F6] text-white'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {spd}x
              </button>
            ))}
          </div>

          <div className="hidden sm:flex items-center gap-1 text-xs text-slate-400">
            <span className="text-[11px]">Dur</span>
            <input
              type="number"
              min={0.2}
              max={30}
              step={0.1}
              title="Animation duration in seconds (0.2s - 30s)"
              value={Number(duration.toFixed(2))}
              onChange={(e) => {
                const val = Number(e.target.value);
                if (Number.isFinite(val)) {
                  onChangeDuration(Math.max(0.2, Math.min(30, val)));
                }
              }}
              className="w-14 bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded px-1.5 py-0.5 text-xs font-mono tabular-nums text-slate-100 outline-none"
            />
            <span className="text-[11px]">s</span>
          </div>
        </div>

        {/* Right: Keyframe Tools, Velocity Toggle, Zoom, Collapse */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onAddKeyframeAtPlayhead}
            title="Add / Update Keyframe at Playhead (K)"
            className="flex items-center gap-1 px-2 py-1 bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] text-slate-200 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Key</span>
          </button>

          <button
            type="button"
            disabled={!selectedKeyframeId}
            onClick={() => selectedKeyframeId && onDuplicateKeyframe(selectedKeyframeId)}
            title="Duplicate Selected Keyframe"
            className="p-1.5 text-slate-300 hover:text-white hover:bg-[#1B2233] disabled:opacity-35 disabled:cursor-not-allowed rounded transition-colors cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            disabled={!selectedKeyframeId || keyframes.length <= 1}
            onClick={() => selectedKeyframeId && onDeleteKeyframe(selectedKeyframeId)}
            title="Delete Selected Keyframe"
            className="p-1.5 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 disabled:opacity-35 disabled:cursor-not-allowed rounded transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          <div className="w-px h-4 bg-[#232B3E] mx-0.5" />

          {/* Snap to Grid Toggle & Frame/Time Increment Selector */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onToggleSnap}
              aria-pressed={snapEnabled}
              title={`Snap keyframes to grid (S) — hold Shift while dragging to bypass`}
              className={`flex items-center gap-1 px-1.5 py-1 rounded text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                snapEnabled
                  ? 'bg-[#1D2842] text-[#60A5FA]'
                  : 'text-slate-400 hover:text-white hover:bg-[#1B2233]'
              }`}
            >
              <Magnet className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Snap</span>
            </button>
            <select
              aria-label="Snap grid increment"
              title="Snap increment"
              value={snapIncrement === 'frame' ? 'frame' : String(snapIncrement)}
              onChange={(e) => {
                const v = e.target.value;
                onChangeSnapIncrement(
                  v === 'frame' ? 'frame' : (Number(v) as SnapIncrementOption),
                );
              }}
              className="bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded px-1.5 py-0.5 text-[11px] font-mono text-slate-200 outline-none cursor-pointer"
            >
              <option value="frame">1f ({fps}fps)</option>
              <option value="0.05">0.05s</option>
              <option value="0.1">0.10s</option>
              <option value="0.25">0.25s</option>
              <option value="0.5">0.50s</option>
            </select>
          </div>

          <div className="w-px h-4 bg-[#232B3E] mx-0.5" />

          <button
            type="button"
            onClick={() => setShowVelocity((v) => !v)}
            aria-pressed={showVelocity}
            title="Toggle easing velocity curves & spacing indicators"
            className={`p-1.5 rounded transition-colors cursor-pointer ${
              showVelocity
                ? 'bg-[#1D2842] text-[#60A5FA]'
                : 'text-slate-400 hover:text-white hover:bg-[#1B2233]'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
          </button>

          <div className="w-px h-4 bg-[#232B3E] mx-0.5" />

          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(1, Number((z - 0.5).toFixed(1))))}
            disabled={zoom <= 1}
            title="Zoom Out Timeline"
            className="p-1.5 text-slate-400 hover:text-white hover:bg-[#1B2233] disabled:opacity-35 rounded transition-colors cursor-pointer"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="text-[11px] font-mono tabular-nums text-slate-400 w-7 text-center">
            {zoom}x
          </span>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(4, Number((z + 0.5).toFixed(1))))}
            disabled={zoom >= 4}
            title="Zoom In Timeline"
            className="p-1.5 text-slate-400 hover:text-white hover:bg-[#1B2233] disabled:opacity-35 rounded transition-colors cursor-pointer"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>

          <div className="w-px h-4 bg-[#232B3E] mx-0.5" />

          <button
            type="button"
            onClick={onToggleCollapse}
            title={isCollapsed ? 'Expand Timeline' : 'Collapse Timeline'}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-[#1B2233] rounded transition-colors cursor-pointer"
          >
            {isCollapsed ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>

      {/* Scrollable Zoomed Keyframe Track */}
      {!isCollapsed && (
        <div className="flex-1 px-4 py-2 overflow-x-auto overflow-y-hidden">
          <div
            ref={trackRef}
            onPointerDown={handleTrackPointerDown}
            style={{ width: `${zoom * 100}%`, minWidth: '100%' }}
            className="relative h-full bg-[#0B0E14] border border-[#232B3E] rounded-md cursor-crosshair overflow-hidden"
          >
            {/* Time Ruler */}
            <div className="absolute inset-x-0 top-0 h-6 border-b border-[#232B3E] bg-[#10141E] pointer-events-none">
              {ticks.map((tick) => {
                const leftPct = (tick.time / Math.max(0.01, duration)) * 100;
                return (
                  <div
                    key={tick.time}
                    style={{ left: `${leftPct}%` }}
                    className="absolute top-0 bottom-0 flex flex-col items-start"
                  >
                    <div
                      className={`w-px ${
                        tick.major ? 'h-2.5 bg-slate-500' : 'h-1.5 bg-slate-700'
                      }`}
                    />
                    {tick.major && (
                      <span className="text-[10px] font-mono tabular-nums text-slate-400 pl-1">
                        {tick.time.toFixed(1)}s
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Vertical Grid Lines & Snap Alignment Guides */}
            <div className="absolute inset-x-0 top-6 bottom-0 pointer-events-none">
              {snapGridLinesPct.map((leftPct, idx) => (
                <div
                  key={`snap-${idx}`}
                  style={{ left: `${leftPct}%` }}
                  className="absolute top-0 bottom-0 w-px bg-[#1E2A42]/60"
                />
              ))}
              {ticks
                .filter((t) => t.major)
                .map((tick) => {
                  const leftPct = (tick.time / Math.max(0.01, duration)) * 100;
                  return (
                    <div
                      key={tick.time}
                      style={{ left: `${leftPct}%` }}
                      className="absolute top-0 bottom-0 w-px bg-[#192030]"
                    />
                  );
                })}
            </div>

            {/* Keyframe Diamonds & Velocity Indicators Lane */}
            <div className="absolute inset-x-0 top-6 bottom-6 border-b border-[#192030] flex items-center">
              {(!showVelocity || velocitySegments.length === 0) && (
                <span className="pointer-events-none pl-2.5 text-[11px] font-medium text-slate-600">
                  R15 Keyframes
                </span>
              )}

              {/* Visual Velocity Curves & Spacing Ticks Between Keyframes */}
              {showVelocity &&
                velocitySegments.map((seg) => {
                  const meta = EASING_META[seg.easing];
                  const showLabel = seg.widthPct * zoom >= 9;
                  const tooltip = seg.isHold
                    ? `${seg.startTime.toFixed(2)}s → ${seg.endTime.toFixed(2)}s · Static Hold (0° delta)`
                    : `${seg.startTime.toFixed(2)}s → ${seg.endTime.toFixed(2)}s · ${meta.label} · ${Math.round(seg.deltaDeg)}° peak delta${onChangeKeyframeEasing ? ' (click label to cycle easing)' : ''}`;

                  return (
                    <div
                      key={seg.id}
                      style={{
                        left: `${seg.startPct}%`,
                        width: `${seg.widthPct}%`,
                      }}
                      title={tooltip}
                      className="absolute inset-y-0 z-0 pointer-events-none"
                    >
                      {seg.isHold ? (
                        <div className="absolute inset-x-0 top-1/2 border-t border-dashed border-slate-700/80" />
                      ) : (
                        <>
                          {/* Speed Graph Velocity Envelope */}
                          <svg
                            viewBox="0 0 100 40"
                            preserveAspectRatio="none"
                            aria-hidden="true"
                            className="w-full h-full block"
                          >
                            <path
                              d={seg.areaPath}
                              fill={meta.color}
                              fillOpacity={0.16}
                            />
                            <path
                              d={seg.linePath}
                              fill="none"
                              stroke={meta.color}
                              strokeOpacity={0.85}
                              strokeWidth={1.6}
                              vectorEffect="non-scaling-stroke"
                            />
                          </svg>

                          {/* Centerline Animator Spacing Ticks (dense = slow, wide = fast) */}
                          <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-2 pointer-events-none">
                            <div
                              style={{ backgroundColor: meta.color }}
                              className="absolute inset-x-0 top-1/2 h-px opacity-25"
                            />
                            {seg.spacingTicksPct.map((pct, idx) => (
                              <span
                                key={idx}
                                style={{
                                  left: `${pct}%`,
                                  backgroundColor: meta.color,
                                }}
                                className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 w-[2px] h-1.5 rounded-full opacity-75"
                              />
                            ))}
                          </div>
                        </>
                      )}

                      {showLabel && (
                        <button
                          type="button"
                          onPointerDown={(e) => e.stopPropagation()}
                          onClick={(e) => cycleSegmentEasing(e, seg)}
                          disabled={!onChangeKeyframeEasing || seg.isHold}
                          title={tooltip}
                          className={`pointer-events-auto absolute top-1 left-1/2 -translate-x-1/2 px-1 py-0 text-[10px] font-mono leading-tight rounded bg-[#0B0E14]/80 border border-[#232B3E]/80 whitespace-nowrap transition-colors ${
                            seg.isHold
                              ? 'text-slate-500 cursor-default'
                              : `${meta.textClass} hover:border-slate-500 cursor-pointer`
                          }`}
                        >
                          {seg.isHold ? 'Hold' : meta.short}
                        </button>
                      )}
                    </div>
                  );
                })}

              {sortedKeyframes.map((kf) => {
                const leftPct = (kf.time / Math.max(0.01, duration)) * 100;
                const isSelected = selectedKeyframeId === kf.id;
                const isNearPlayhead = Math.abs(kf.time - currentTime) < 0.015;
                const isDraggingThis = draggingKf?.id === kf.id;
                return (
                  <React.Fragment key={kf.id}>
                    <button
                      type="button"
                      onPointerDown={(e) => handleKeyframePointerDown(e, kf)}
                      style={{ left: `${leftPct}%` }}
                      title={`Keyframe @ ${kf.time.toFixed(snapIncrement === 'frame' ? 3 : 2)}s (${kf.easing}) — drag to retime${snapEnabled ? ' · snaps to grid (Shift = free)' : ''}`}
                      className={`absolute top-1/2 -translate-x-1/2 -translate-y-1/2 w-3.5 h-3.5 rotate-45 border transition-transform cursor-grab active:cursor-grabbing z-10 ${
                        isSelected
                          ? 'bg-[#F59E0B] border-white scale-125'
                          : isNearPlayhead
                            ? 'bg-[#3B82F6] border-white scale-110'
                            : 'bg-[#3B82F6]/85 border-[#93C5FD] hover:scale-115'
                      }`}
                    />
                    {isDraggingThis && (
                      <div
                        style={{ left: `${leftPct}%` }}
                        className="pointer-events-none absolute top-0.5 -translate-x-1/2 px-1.5 py-0.5 rounded bg-[#0B0E14] border border-amber-400/70 text-[10px] font-mono tabular-nums text-amber-300 whitespace-nowrap z-30 shadow"
                      >
                        {draggingKf.time.toFixed(
                          snapIncrement === 'frame' ? 3 : 2,
                        )}
                        s{draggingKf.snapped ? ' · snap' : ''}
                      </div>
                    )}
                  </React.Fragment>
                );
              })}
            </div>

            {/* Joint Coverage Footer Strip */}
            <div className="absolute inset-x-0 bottom-0 h-6 flex items-center">
              <span className="pointer-events-none pl-2.5 text-[10px] text-slate-600">
                Active Joints
              </span>
              {sortedKeyframes.map((kf) => {
                const leftPct = (kf.time / Math.max(0.01, duration)) * 100;
                const count = Object.keys(kf.joints).length;
                return (
                  <div
                    key={kf.id}
                    style={{ left: `${leftPct}%` }}
                    className="pointer-events-none absolute -translate-x-1/2 text-[10px] font-mono tabular-nums text-slate-400"
                  >
                    {count}j
                  </div>
                );
              })}
            </div>

            {/* Playhead Needle */}
            <div
              style={{ left: `${playheadPct}%` }}
              className="pointer-events-none absolute top-0 bottom-0 w-0.5 bg-[#EF4444] z-20"
            >
              <div className="w-2.5 h-2 -ml-[4px] bg-[#EF4444] rounded-b-sm" />
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

