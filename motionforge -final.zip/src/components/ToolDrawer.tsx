import React, { useMemo, useState } from 'react';
import {
  X,
  Sparkles,
  Play,
  Search,
  BookmarkPlus,
  Trash2,
  Eye,
  FlipHorizontal2,
  RotateCcw,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import {
  R15_JOINT_META,
  R15_JOINT_NAMES,
  type AnimationProject,
  type EvaluatedPose,
  type PropType,
  type R15JointName,
} from '../animation/types.ts';
import { ANIMATION_PRESETS } from '../animation/presets.ts';
import {
  PRESET_CATEGORY_MAP,
  type LibraryCategory,
} from '../animation/poseUtils.ts';
import type { LeftToolId } from './LeftToolRail.tsx';

export interface SavedLibraryItem {
  id: string;
  savedAt: string;
  category: Exclude<LibraryCategory, 'All'>;
  project: AnimationProject;
}

interface ToolDrawerProps {
  activeTool: LeftToolId;
  width: number;
  onClose: () => void;
  // Project & Pose
  project: AnimationProject;
  displayPose: EvaluatedPose;
  selectedJoint: R15JointName | null;
  onSelectJoint: (joint: R15JointName) => void;
  onLoadProject: (
    project: AnimationProject,
    notice?: string,
    opts?: { newTab?: boolean },
  ) => void;
  onChangeProp: (prop: PropType) => void;
  onMirrorFullPose: () => void;
  onResetFullPose: () => void;
  onEditRootPosition: (axis: 0 | 1 | 2, val: number) => void;
  onApplyQuickTemplate: (template: 'neutral' | 'ready' | 'tpose') => void;
  // Library & History
  savedAnimations: SavedLibraryItem[];
  recentProjects: AnimationProject[];
  recentGenerations: AnimationProject[];
  onAddRecentGeneration: (project: AnimationProject) => void;
  onSaveCurrentToLibrary: (category: Exclude<LibraryCategory, 'All'>) => void;
  onDeleteSavedAnimation: (id: string) => void;
  onStartPreview: (project: AnimationProject) => void;
  // Settings
  onionSkinEnabled: boolean;
  onToggleOnionSkin: () => void;
  onionOpacity: number;
  onChangeOnionOpacity: (opacity: number) => void;
  gridVisible: boolean;
  onToggleGrid: () => void;
  showSkeleton: boolean;
  onToggleSkeleton: () => void;
  persistLayout: boolean;
  onTogglePersistLayout: () => void;
  onResetWorkspaceLayout: () => void;
}

const TOOL_TITLES: Record<LeftToolId, string> = {
  select: 'Select & Rig Hierarchy',
  ai: 'AI Animation Generator',
  library: 'Animation Library',
  pose: 'Pose Editor',
  props: 'Character Props',
  settings: 'Workspace Settings',
};

const ANIMATION_STYLES = [
  'Natural',
  'Snappy Action',
  'Combat',
  'Expressive Emote',
  'Athletic',
];

const EXAMPLE_PROMPTS = [
  '1-second R15 net swing overhead',
  '2.5-second combo sword slash and spin',
  '3-second energetic victory jump and wave',
  '4-second celebratory dance routine',
];

const DURATION_PRESETS = [1, 2, 3, 5, 10];

const CATEGORIES: LibraryCategory[] = [
  'All',
  'Movement',
  'Combat',
  'Tools',
  'Emotes',
];

export function ToolDrawer({
  activeTool,
  width,
  onClose,
  project,
  displayPose,
  selectedJoint,
  onSelectJoint,
  onLoadProject,
  onChangeProp,
  onMirrorFullPose,
  onResetFullPose,
  onEditRootPosition,
  onApplyQuickTemplate,
  savedAnimations,
  recentProjects,
  recentGenerations,
  onAddRecentGeneration,
  onSaveCurrentToLibrary,
  onDeleteSavedAnimation,
  onStartPreview,
  onionSkinEnabled,
  onToggleOnionSkin,
  onionOpacity,
  onChangeOnionOpacity,
  gridVisible,
  onToggleGrid,
  showSkeleton,
  onToggleSkeleton,
  persistLayout,
  onTogglePersistLayout,
  onResetWorkspaceLayout,
}: ToolDrawerProps) {
  // AI Generator state
  const [prompt, setPrompt] = useState('1-second R15 net swing overhead');
  const [duration, setDuration] = useState(2.0);
  const [style, setStyle] = useState('Natural');
  const [genProp, setGenProp] = useState<PropType | 'auto'>('auto');
  const [genLoop, setGenLoop] = useState(true);
  const [openInNewTab, setOpenInNewTab] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);
  const [genStatus, setGenStatus] = useState<string | null>(null);
  const [refineInstruction, setRefineInstruction] = useState('');
  const [isRefining, setIsRefining] = useState(false);

  // Library state
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<LibraryCategory>('All');
  const [saveCategory, setSaveCategory] =
    useState<Exclude<LibraryCategory, 'All'>>('Movement');

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    setGenError(null);
    setGenStatus(null);

    const controller = new AbortController();
    const timeoutId = window.setTimeout(() => controller.abort(), 45000);

    const styledPrompt =
      style === 'Natural'
        ? prompt.trim()
        : `${prompt.trim()} (Style: ${style})`;

    try {
      const res = await fetch('/api/generate-animation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          prompt: styledPrompt,
          duration,
          prop: genProp,
          loop: genLoop,
        }),
      });

      const rawText = await res.text();
      let data: {
        project?: AnimationProject;
        warnings?: string[];
        error?: string;
      } = {};

      if (rawText) {
        try {
          data = JSON.parse(rawText) as typeof data;
        } catch {
          setGenError(
            `Generation server returned an unexpected response (HTTP ${res.status}). Please retry.`,
          );
          return;
        }
      }

      if (!res.ok || !data.project) {
        setGenError(
          data.error || `Failed to generate animation (HTTP ${res.status}).`,
        );
        return;
      }

      onAddRecentGeneration(data.project);
      onLoadProject(data.project, `Generated "${data.project.name}"`, {
        newTab: openInNewTab,
      });
      setGenStatus(
        `Generated ${data.project.keyframes.length} keyframes (${data.project.duration.toFixed(2)}s).`,
      );
    } catch (err: unknown) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        setGenError('Generation request timed out. Please retry.');
      } else {
        setGenError(
          'Unable to reach the generation server. Check your connection and retry.',
        );
      }
    } finally {
      window.clearTimeout(timeoutId);
      setIsGenerating(false);
    }
  };

  const handleRefine = async (e: React.FormEvent) => {
    e.preventDefault();
    const instruction = refineInstruction.trim();
    if (!instruction || isRefining || isGenerating) return;

    setIsRefining(true);
    setGenError(null);
    setGenStatus(null);

    const controller = new AbortController();
    const timeoutId = window.setTimeout(() => controller.abort(), 45000);

    try {
      const res = await fetch('/api/refine-animation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          project,
          instruction,
        }),
      });

      const rawText = await res.text();
      let data: {
        project?: AnimationProject;
        warnings?: string[];
        error?: string;
      } = {};

      if (rawText) {
        try {
          data = JSON.parse(rawText) as typeof data;
        } catch {
          setGenError(
            `Refinement server returned an unexpected response (HTTP ${res.status}). Please retry.`,
          );
          return;
        }
      }

      if (!res.ok || !data.project) {
        setGenError(
          data.error || `Failed to refine animation (HTTP ${res.status}).`,
        );
        return;
      }

      onAddRecentGeneration(data.project);
      onLoadProject(data.project, `Refined "${data.project.name}"`, {
        newTab: false,
      });
      setGenStatus(
        `Refined "${data.project.name}" (${data.project.keyframes.length} keyframes).`,
      );
      setRefineInstruction('');
    } catch (err: unknown) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        setGenError('Refinement request timed out. Please retry.');
      } else {
        setGenError(
          'Unable to reach the generation server. Check your connection and retry.',
        );
      }
    } finally {
      window.clearTimeout(timeoutId);
      setIsRefining(false);
    }
  };

  const filteredPresets = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return ANIMATION_PRESETS.filter((preset) => {
      const cat = PRESET_CATEGORY_MAP[preset.id] ?? 'Movement';
      if (categoryFilter !== 'All' && cat !== categoryFilter) return false;
      if (!q) return true;
      return (
        preset.label.toLowerCase().includes(q) ||
        preset.summary.toLowerCase().includes(q) ||
        cat.toLowerCase().includes(q)
      );
    });
  }, [searchQuery, categoryFilter]);

  const filteredSaved = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return savedAnimations.filter((item) => {
      if (categoryFilter !== 'All' && item.category !== categoryFilter) {
        return false;
      }
      if (!q) return true;
      return item.project.name.toLowerCase().includes(q);
    });
  }, [savedAnimations, searchQuery, categoryFilter]);

  return (
    <aside
      style={{ width }}
      className="shrink-0 bg-[#111622] border-r border-[#232B3E] flex flex-col h-full overflow-hidden"
    >
      {/* Drawer Header */}
      <div className="h-10 px-3 border-b border-[#232B3E] flex items-center justify-between shrink-0">
        <h2 className="text-xs font-semibold text-slate-200 truncate">
          {TOOL_TITLES[activeTool]}
        </h2>
        <button
          type="button"
          onClick={onClose}
          title="Close panel (Esc)"
          className="p-1 text-slate-400 hover:text-white hover:bg-[#1B2233] rounded transition-colors cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Drawer Content */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {/* 1. SELECT & HIERARCHY */}
        {activeTool === 'select' && (
          <div className="space-y-3">
            <p className="text-xs text-slate-400 leading-relaxed">
              Click any limb in the 3D viewport or pick a joint below to open
              rotation controls in the Inspector.
            </p>
            <div className="space-y-1">
              {R15_JOINT_NAMES.map((jName) => {
                const isSel = selectedJoint === jName;
                const meta = R15_JOINT_META[jName];
                return (
                  <button
                    key={jName}
                    type="button"
                    onClick={() => onSelectJoint(jName)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-xs transition-colors cursor-pointer ${
                      isSel
                        ? 'bg-[#1D2842] border border-[#3B82F6] text-white'
                        : 'bg-[#161C2B] hover:bg-[#1C2438] border border-transparent text-slate-300'
                    }`}
                  >
                    <span className="font-medium truncate">{jName}</span>
                    <span className="text-[11px] font-mono text-slate-500 ml-2 shrink-0">
                      {meta.motorName}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 2. AI ANIMATION GENERATOR */}
        {activeTool === 'ai' && (
          <div className="space-y-4">
            <form onSubmit={handleGenerate} className="space-y-3">
              <div>
                <label
                  htmlFor="ai-prompt"
                  className="block text-[11px] font-medium text-slate-300 mb-1"
                >
                  Prompt
                </label>
                <textarea
                  id="ai-prompt"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={3}
                  maxLength={600}
                  placeholder="Describe R15 motion, e.g. 1-second overhead net swing..."
                  className="w-full bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded-md px-2.5 py-2 text-xs text-slate-100 placeholder:text-slate-600 outline-none resize-none leading-relaxed"
                />
              </div>

              <div className="flex flex-wrap gap-1">
                {EXAMPLE_PROMPTS.map((sample) => (
                  <button
                    key={sample}
                    type="button"
                    onClick={() => setPrompt(sample)}
                    className="text-[11px] text-slate-400 hover:text-slate-100 bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] rounded px-2 py-1 text-left transition-colors cursor-pointer"
                  >
                    {sample}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label
                    htmlFor="ai-duration"
                    className="block text-[11px] text-slate-400 mb-1"
                  >
                    Duration (s)
                  </label>
                  <input
                    id="ai-duration"
                    type="number"
                    min={0.3}
                    max={30}
                    step={0.1}
                    value={duration}
                    onChange={(e) =>
                      setDuration(
                        Math.max(0.3, Math.min(30, Number(e.target.value) || 1)),
                      )
                    }
                    className="w-full bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded px-2 py-1.5 text-xs font-mono tabular-nums text-slate-100 outline-none"
                  />
                </div>

                <div>
                  <label
                    htmlFor="ai-style"
                    className="block text-[11px] text-slate-400 mb-1"
                  >
                    Style
                  </label>
                  <select
                    id="ai-style"
                    value={style}
                    onChange={(e) => setStyle(e.target.value)}
                    className="w-full bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded px-2 py-1.5 text-xs text-slate-100 outline-none"
                  >
                    {ANIMATION_STYLES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Quick Duration Presets (> 1s supported up to 30s) */}
              <div className="flex items-center gap-1">
                {DURATION_PRESETS.map((sec) => (
                  <button
                    key={sec}
                    type="button"
                    onClick={() => setDuration(sec)}
                    className={`flex-1 py-1 text-[11px] font-mono tabular-nums rounded border transition-colors cursor-pointer ${
                      Math.abs(duration - sec) < 0.01
                        ? 'bg-[#1D2842] border-[#3B82F6] text-sky-200'
                        : 'bg-[#161C2B] hover:bg-[#1E263A] border-[#232B3E] text-slate-400'
                    }`}
                  >
                    {sec}s
                  </button>
                ))}
              </div>

              <div>
                <label
                  htmlFor="ai-prop"
                  className="block text-[11px] text-slate-400 mb-1"
                >
                  Hand Prop
                </label>
                <select
                  id="ai-prop"
                  value={genProp}
                  onChange={(e) => setGenProp(e.target.value as PropType | 'auto')}
                  className="w-full bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded px-2 py-1.5 text-xs text-slate-100 outline-none"
                >
                  <option value="auto">Auto-detect from prompt</option>
                  <option value="net">Catching Net</option>
                  <option value="sword">Sword</option>
                  <option value="none">No Prop</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={genLoop}
                    onChange={(e) => setGenLoop(e.target.checked)}
                    className="rounded border-[#232B3E] bg-[#0B0E14] text-[#3B82F6]"
                  />
                  <span>Seamless loop</span>
                </label>
                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={openInNewTab}
                    onChange={(e) => setOpenInNewTab(e.target.checked)}
                    className="rounded border-[#232B3E] bg-[#0B0E14] text-[#3B82F6]"
                  />
                  <span>Open in new clip tab</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={isGenerating || !prompt.trim()}
                className="w-full flex items-center justify-center gap-2 bg-[#3B82F6] hover:bg-[#2563EB] disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-semibold py-2 px-3 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>
                  {isGenerating ? 'Generating Keyframes...' : 'Generate Animation'}
                </span>
              </button>

              {genError && (
                <div className="flex items-start gap-2 text-xs text-rose-300 bg-rose-950/40 border border-rose-800/60 rounded-md p-2.5 leading-snug">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                  <span>{genError}</span>
                </div>
              )}

              {genStatus && (
                <div className="flex items-start gap-2 text-xs text-emerald-300 bg-emerald-950/35 border border-emerald-800/50 rounded-md p-2.5 leading-snug">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                  <span>{genStatus}</span>
                </div>
              )}
            </form>

            {/* Refine Active Animation */}
            <form
              onSubmit={handleRefine}
              className="border-t border-[#232B3E] pt-3 space-y-2"
            >
              <label
                htmlFor="ai-refine"
                className="block text-[11px] font-medium text-slate-300"
              >
                Refine "{project.name}"
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  id="ai-refine"
                  type="text"
                  value={refineInstruction}
                  onChange={(e) => setRefineInstruction(e.target.value)}
                  maxLength={600}
                  placeholder="e.g. make the swing bigger"
                  className="flex-1 min-w-0 bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded-md px-2.5 py-1.5 text-xs text-slate-100 placeholder:text-slate-600 outline-none"
                />
                <button
                  type="submit"
                  disabled={
                    isRefining || isGenerating || !refineInstruction.trim()
                  }
                  className="px-2.5 py-1.5 bg-[#1D2842] hover:bg-[#263557] border border-[#3B82F6]/50 disabled:opacity-50 disabled:cursor-not-allowed text-sky-200 text-xs font-medium rounded-md transition-colors shrink-0 cursor-pointer"
                >
                  {isRefining ? 'Refining...' : 'Refine'}
                </button>
              </div>
            </form>

            {/* Recent AI Generations */}
            <div className="border-t border-[#232B3E] pt-3 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium text-slate-400">
                  Recent Generations
                </span>
                <span className="text-[11px] font-mono tabular-nums text-slate-500">
                  {recentGenerations.length}
                </span>
              </div>
              {recentGenerations.length === 0 ? (
                <p className="text-[11px] text-slate-500">
                  Generated clips appear here for quick recall.
                </p>
              ) : (
                <div className="space-y-1">
                  {recentGenerations.map((item, idx) => (
                    <button
                      key={`${item.name}-${idx}`}
                      type="button"
                      onClick={() =>
                        onLoadProject(
                          structuredClone(item),
                          `Loaded generated clip: ${item.name}`,
                        )
                      }
                      className="w-full flex items-center justify-between px-2.5 py-1.5 bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] rounded text-xs text-slate-200 transition-colors cursor-pointer"
                    >
                      <span className="truncate">{item.name}</span>
                      <span className="text-[11px] font-mono tabular-nums text-slate-400 ml-2 shrink-0">
                        {item.duration.toFixed(1)}s · {item.keyframes.length}k
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* 3. SEARCHABLE ANIMATION LIBRARY */}
        {activeTool === 'library' && (
          <div className="space-y-3">
            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search animations..."
                className="w-full bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded-md pl-8 pr-2.5 py-1.5 text-xs text-slate-100 placeholder:text-slate-600 outline-none"
              />
            </div>

            {/* Category Tabs */}
            <div className="flex flex-wrap gap-1">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategoryFilter(cat)}
                  className={`px-2 py-1 text-[11px] font-medium rounded transition-colors cursor-pointer ${
                    categoryFilter === cat
                      ? 'bg-[#3B82F6] text-white'
                      : 'bg-[#161C2B] hover:bg-[#1E263A] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Save Current to Library */}
            <div className="bg-[#161C2B] border border-[#232B3E] rounded-md p-2.5 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-medium text-slate-300 truncate">
                  Save "{project.name}"
                </span>
                <select
                  value={saveCategory}
                  onChange={(e) =>
                    setSaveCategory(
                      e.target.value as Exclude<LibraryCategory, 'All'>,
                    )
                  }
                  className="bg-[#0B0E14] border border-[#232B3E] rounded px-1.5 py-0.5 text-[11px] text-slate-200 outline-none"
                >
                  <option value="Movement">Movement</option>
                  <option value="Combat">Combat</option>
                  <option value="Tools">Tools</option>
                  <option value="Emotes">Emotes</option>
                </select>
              </div>
              <button
                type="button"
                onClick={() => onSaveCurrentToLibrary(saveCategory)}
                className="w-full flex items-center justify-center gap-1.5 bg-[#1D2842] hover:bg-[#253354] border border-[#3B82F6]/40 text-sky-200 text-xs font-medium py-1.5 px-2.5 rounded transition-colors cursor-pointer"
              >
                <BookmarkPlus className="w-3.5 h-3.5" />
                <span>Save to Library</span>
              </button>
            </div>

            {/* Presets Section */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span className="font-medium">Presets</span>
                <span className="font-mono tabular-nums">
                  {filteredPresets.length}
                </span>
              </div>
              {filteredPresets.length === 0 ? (
                <p className="text-xs text-slate-500 py-2">
                  No matching presets found.
                </p>
              ) : (
                filteredPresets.map((preset) => {
                  const cat = PRESET_CATEGORY_MAP[preset.id] ?? 'Movement';
                  const isActive = project.name === preset.project.name;
                  return (
                    <div
                      key={preset.id}
                      className={`rounded-md p-2.5 border transition-colors ${
                        isActive
                          ? 'bg-[#1D2842] border-[#3B82F6]/70'
                          : 'bg-[#161C2B] border-[#232B3E]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-medium text-slate-100 truncate">
                          {preset.label}
                        </span>
                        <span className="text-[11px] font-mono tabular-nums text-slate-400 shrink-0">
                          {cat} · {preset.project.duration.toFixed(1)}s
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-snug">
                        {preset.summary}
                      </p>
                      <div className="flex items-center gap-1.5 mt-2">
                        <button
                          type="button"
                          onClick={() =>
                            onStartPreview(structuredClone(preset.project))
                          }
                          className="flex items-center gap-1 px-2 py-1 bg-[#111622] hover:bg-[#1E263A] border border-[#232B3E] text-slate-300 text-[11px] font-medium rounded transition-colors cursor-pointer"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Preview</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onLoadProject(
                              structuredClone(preset.project),
                              `Loaded preset: ${preset.label}`,
                            )
                          }
                          className="flex items-center gap-1 px-2.5 py-1 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-[11px] font-medium rounded transition-colors cursor-pointer"
                        >
                          <Play className="w-3 h-3" />
                          <span>Load</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onLoadProject(
                              structuredClone(preset.project),
                              `Opened "${preset.label}" in new clip tab`,
                              { newTab: true },
                            )
                          }
                          title="Open preset in a new clip tab"
                          className="px-2 py-1 bg-[#111622] hover:bg-[#1E263A] border border-[#232B3E] text-slate-300 text-[11px] font-medium rounded transition-colors cursor-pointer"
                        >
                          + Tab
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Saved Animations */}
            {filteredSaved.length > 0 && (
              <div className="border-t border-[#232B3E] pt-3 space-y-1.5">
                <span className="block text-[11px] font-medium text-slate-400">
                  Saved Animations
                </span>
                {filteredSaved.map((item) => (
                  <div
                    key={item.id}
                    className="bg-[#161C2B] border border-[#232B3E] rounded-md p-2.5 space-y-2"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-medium text-slate-100 truncate">
                        {item.project.name}
                      </span>
                      <span className="text-[11px] font-mono tabular-nums text-slate-400 shrink-0">
                        {item.category} · {item.project.duration.toFixed(1)}s
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-1.5">
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            onStartPreview(structuredClone(item.project))
                          }
                          className="flex items-center gap-1 px-2 py-1 bg-[#111622] hover:bg-[#1E263A] border border-[#232B3E] text-slate-300 text-[11px] rounded cursor-pointer"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Preview</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onLoadProject(
                              structuredClone(item.project),
                              `Loaded saved animation: ${item.project.name}`,
                            )
                          }
                          className="flex items-center gap-1 px-2.5 py-1 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-[11px] rounded cursor-pointer"
                        >
                          <Play className="w-3 h-3" />
                          <span>Load</span>
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => onDeleteSavedAnimation(item.id)}
                        title="Delete saved animation"
                        className="p-1 text-rose-400 hover:bg-rose-950/40 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Recent Projects */}
            {recentProjects.length > 0 && (
              <div className="border-t border-[#232B3E] pt-3 space-y-1.5">
                <span className="block text-[11px] font-medium text-slate-400">
                  Recent Projects
                </span>
                {recentProjects.map((proj, idx) => (
                  <button
                    key={`${proj.name}-${idx}`}
                    type="button"
                    onClick={() =>
                      onLoadProject(
                        structuredClone(proj),
                        `Restored: ${proj.name}`,
                      )
                    }
                    className="w-full flex items-center justify-between px-2.5 py-1.5 bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] rounded text-xs text-slate-200 transition-colors cursor-pointer"
                  >
                    <span className="truncate">{proj.name}</span>
                    <span className="text-[11px] font-mono tabular-nums text-slate-400 ml-2 shrink-0">
                      {proj.duration.toFixed(1)}s
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 4. POSE EDITOR */}
        {activeTool === 'pose' && (
          <div className="space-y-4">
            <div className="space-y-2">
              <span className="block text-[11px] font-medium text-slate-400">
                Symmetry & Reset
              </span>
              <button
                type="button"
                onClick={onMirrorFullPose}
                className="w-full flex items-center justify-center gap-2 bg-[#1D2842] hover:bg-[#263557] border border-[#3B82F6]/40 text-sky-200 text-xs font-medium py-2 px-3 rounded-md transition-colors cursor-pointer"
              >
                <FlipHorizontal2 className="w-3.5 h-3.5" />
                <span>Mirror Full Pose (L ↔ R)</span>
              </button>
              <button
                type="button"
                onClick={onResetFullPose}
                className="w-full flex items-center justify-center gap-2 bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] text-slate-200 text-xs font-medium py-2 px-3 rounded-md transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Full Pose</span>
              </button>
            </div>

            <div className="border-t border-[#232B3E] pt-3 space-y-2">
              <span className="block text-[11px] font-medium text-slate-400">
                Quick Pose Stances
              </span>
              <div className="grid grid-cols-1 gap-1.5">
                <button
                  type="button"
                  onClick={() => onApplyQuickTemplate('neutral')}
                  className="px-3 py-1.5 text-left text-xs bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] rounded text-slate-200 cursor-pointer"
                >
                  Neutral Stand
                </button>
                <button
                  type="button"
                  onClick={() => onApplyQuickTemplate('ready')}
                  className="px-3 py-1.5 text-left text-xs bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] rounded text-slate-200 cursor-pointer"
                >
                  Athletic Ready Stance
                </button>
                <button
                  type="button"
                  onClick={() => onApplyQuickTemplate('tpose')}
                  className="px-3 py-1.5 text-left text-xs bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] rounded text-slate-200 cursor-pointer"
                >
                  T-Pose Calibration
                </button>
              </div>
            </div>

            <div className="border-t border-[#232B3E] pt-3 space-y-2">
              <span className="block text-[11px] font-medium text-slate-400">
                Root Translation (studs)
              </span>
              {(['X', 'Y', 'Z'] as const).map((label, axis) => {
                const val =
                  Math.round(displayPose.rootPosition[axis as 0 | 1 | 2] * 100) /
                  100;
                return (
                  <div key={label} className="flex items-center gap-2">
                    <span className="text-xs font-mono text-slate-400 w-4">
                      {label}
                    </span>
                    <input
                      type="range"
                      min={-3}
                      max={3}
                      step={0.05}
                      value={val}
                      onChange={(e) =>
                        onEditRootPosition(
                          axis as 0 | 1 | 2,
                          Number(e.target.value),
                        )
                      }
                      className="studio-slider flex-1"
                    />
                    <span className="w-12 text-right text-xs font-mono tabular-nums text-slate-200">
                      {val.toFixed(2)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 5. PROPS */}
        {activeTool === 'props' && (
          <div className="space-y-2.5">
            <p className="text-xs text-slate-400 leading-relaxed">
              Attach a procedural prop to the character&apos;s RightHand bone.
            </p>
            {(
              [
                ['none', 'No Prop', 'Clean R15 hand for emotes, jumping, and dancing.'],
                ['net', 'Catching Net', 'Lightweight aluminum hoop net for swing animations.'],
                ['sword', 'Steel Sword', 'Crossguard blade for guard and slash animations.'],
              ] as [PropType, string, string][]
            ).map(([id, title, desc]) => {
              const active = project.prop === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => onChangeProp(id)}
                  className={`w-full text-left rounded-md p-3 border transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#1D2842] border-[#3B82F6] text-white'
                      : 'bg-[#161C2B] hover:bg-[#1E263A] border-[#232B3E] text-slate-200'
                  }`}
                >
                  <div className="text-xs font-semibold">{title}</div>
                  <div className="text-[11px] text-slate-400 mt-1 leading-snug">
                    {desc}
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {/* 6. SETTINGS */}
        {activeTool === 'settings' && (
          <div className="space-y-4">
            <div className="space-y-2.5">
              <span className="block text-[11px] font-medium text-slate-400">
                Viewport & Onion Skinning
              </span>

              <label className="flex items-center justify-between text-xs text-slate-200 cursor-pointer">
                <span>Onion Skinning (O)</span>
                <input
                  type="checkbox"
                  checked={onionSkinEnabled}
                  onChange={onToggleOnionSkin}
                  className="rounded border-[#232B3E] bg-[#0B0E14] text-[#3B82F6]"
                />
              </label>

              {onionSkinEnabled && (
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Ghost Opacity</span>
                    <span className="font-mono tabular-nums">
                      {Math.round(onionOpacity * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.1}
                    max={0.55}
                    step={0.02}
                    value={onionOpacity}
                    onChange={(e) =>
                      onChangeOnionOpacity(Number(e.target.value))
                    }
                    className="studio-slider w-full"
                  />
                </div>
              )}

              <label className="flex items-center justify-between text-xs text-slate-200 cursor-pointer">
                <span>Studio Floor Grid (G)</span>
                <input
                  type="checkbox"
                  checked={gridVisible}
                  onChange={onToggleGrid}
                  className="rounded border-[#232B3E] bg-[#0B0E14] text-[#3B82F6]"
                />
              </label>

              <label className="flex items-center justify-between text-xs text-slate-200 cursor-pointer">
                <span>R15 Joint Gizmos (J)</span>
                <input
                  type="checkbox"
                  checked={showSkeleton}
                  onChange={onToggleSkeleton}
                  className="rounded border-[#232B3E] bg-[#0B0E14] text-[#3B82F6]"
                />
              </label>
            </div>

            <div className="border-t border-[#232B3E] pt-3 space-y-2.5">
              <span className="block text-[11px] font-medium text-slate-400">
                Workspace Persistence
              </span>

              <label className="flex items-center justify-between text-xs text-slate-200 cursor-pointer">
                <span>Save panel layout locally</span>
                <input
                  type="checkbox"
                  checked={persistLayout}
                  onChange={onTogglePersistLayout}
                  className="rounded border-[#232B3E] bg-[#0B0E14] text-[#3B82F6]"
                />
              </label>

              <button
                type="button"
                onClick={onResetWorkspaceLayout}
                className="w-full px-3 py-1.5 text-xs font-medium bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] rounded text-slate-200 transition-colors cursor-pointer"
              >
                Reset Workspace Layout
              </button>
            </div>

            <div className="border-t border-[#232B3E] pt-3 space-y-1 text-[11px] text-slate-400">
              <div className="font-medium text-slate-300 mb-1">
                Keyboard Shortcuts
              </div>
              <div className="flex justify-between">
                <span>Play / Pause</span>
                <span className="font-mono text-slate-300">Space</span>
              </div>
              <div className="flex justify-between">
                <span>Key Current Pose</span>
                <span className="font-mono text-slate-300">K</span>
              </div>
              <div className="flex justify-between">
                <span>Mirror Full Pose</span>
                <span className="font-mono text-slate-300">M</span>
              </div>
              <div className="flex justify-between">
                <span>Toggle Onion Skin</span>
                <span className="font-mono text-slate-300">O</span>
              </div>
              <div className="flex justify-between">
                <span>Toggle Snap to Grid</span>
                <span className="font-mono text-slate-300">S</span>
              </div>
              <div className="flex justify-between">
                <span>Undo / Redo</span>
                <span className="font-mono text-slate-300">Ctrl+Z / Y</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
