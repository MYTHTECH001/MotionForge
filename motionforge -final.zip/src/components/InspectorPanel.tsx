import React, { useState } from 'react';
import {
  X,
  RotateCcw,
  KeyRound,
  FlipHorizontal2,
  ArrowLeftRight,
} from 'lucide-react';
import {
  R15_JOINT_META,
  R15_JOINT_NAMES,
  type EasingMode,
  type EvaluatedPose,
  type Keyframe,
  type R15JointName,
  type Vec3Tuple,
} from '../animation/types.ts';
import { getOppositeJoint } from '../animation/poseUtils.ts';
import { clampToLimits, R15_JOINT_LIMITS } from '../animation/jointLimits.ts';

interface InspectorPanelProps {
  width: number;
  selectedJoint: R15JointName | null;
  onSelectJoint: (joint: R15JointName) => void;
  displayPose: EvaluatedPose;
  activeKeyframe: Keyframe | null;
  currentTime: number;
  hasUnsavedPoseEdits: boolean;
  onEditJointRotation: (joint: R15JointName, axis: 0 | 1 | 2, deg: number) => void;
  onEditRootPosition: (axis: 0 | 1 | 2, val: number) => void;
  onResetJoint: (joint: R15JointName) => void;
  onMirrorFullPose: () => void;
  onMirrorSelectedJoint: (joint: R15JointName) => void;
  onCommitPoseToKeyframe: () => void;
  onChangeKeyframeMeta: (
    kfId: string,
    patch: { time?: number; easing?: EasingMode },
  ) => void;
  duration: number;
  onClose: () => void;
}

const AXIS_LABELS = ['X', 'Y', 'Z'] as const;
const AXIS_COLORS = ['text-rose-400', 'text-emerald-400', 'text-sky-400'] as const;

export function InspectorPanel({
  width,
  selectedJoint,
  onSelectJoint,
  displayPose,
  activeKeyframe,
  currentTime,
  hasUnsavedPoseEdits,
  onEditJointRotation,
  onEditRootPosition,
  onResetJoint,
  onMirrorFullPose,
  onMirrorSelectedJoint,
  onCommitPoseToKeyframe,
  onChangeKeyframeMeta,
  duration,
  onClose,
}: InspectorPanelProps) {
  const [respectLimits, setRespectLimits] = useState(true);
  const activeJoint = selectedJoint ?? 'HumanoidRootPart';
  const meta = R15_JOINT_META[activeJoint];
  const rot = displayPose.joints[activeJoint];
  const limits = R15_JOINT_LIMITS[activeJoint];
  const rootPos = displayPose.rootPosition;
  const oppositeJoint = getOppositeJoint(activeJoint);

  const handleAxisEdit = (axis: 0 | 1 | 2, rawDeg: number) => {
    const safeDeg = Math.max(-180, Math.min(180, Number.isFinite(rawDeg) ? rawDeg : 0));
    if (!respectLimits) {
      onEditJointRotation(activeJoint, axis, safeDeg);
      return;
    }
    const candidate: Vec3Tuple = [rot[0], rot[1], rot[2]];
    candidate[axis] = safeDeg;
    const clamped = clampToLimits(activeJoint, candidate);
    onEditJointRotation(activeJoint, axis, clamped[axis]);
  };

  return (
    <aside
      style={{ width }}
      className="shrink-0 bg-[#111622] border-l border-[#232B3E] flex flex-col h-full overflow-hidden"
    >
      {/* Header */}
      <div className="h-10 px-3 border-b border-[#232B3E] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <h2 className="text-xs font-semibold text-slate-200 truncate">
            Joint Inspector
          </h2>
        </div>
        <button
          type="button"
          onClick={onClose}
          title="Close inspector"
          className="p-1 text-slate-400 hover:text-white hover:bg-[#1B2233] rounded transition-colors cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {/* Joint Selector & Metadata */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label
              htmlFor="inspector-joint-select"
              className="text-[11px] font-medium text-slate-400"
            >
              Selected Joint
            </label>
            <span className="text-[11px] font-mono text-slate-500">
              {meta.motorName}
            </span>
          </div>
          <select
            id="inspector-joint-select"
            value={activeJoint}
            onChange={(e) => onSelectJoint(e.target.value as R15JointName)}
            className="w-full bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded-md px-2.5 py-1.5 text-xs font-medium text-slate-100 outline-none"
          >
            {R15_JOINT_NAMES.map((jName) => (
              <option key={jName} value={jName}>
                {jName} ({R15_JOINT_META[jName].motorName})
              </option>
            ))}
          </select>
          <p className="text-[11px] text-slate-500 leading-snug">
            {meta.axisHint}
          </p>
        </div>

        {/* Rotation X / Y / Z */}
        <div className="border-t border-[#232B3E] pt-3 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-300">
              Rotation (deg)
            </span>
            <button
              type="button"
              onClick={() => onResetJoint(activeJoint)}
              title="Reset selected joint to [0, 0, 0]"
              className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-slate-100 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Joint</span>
            </button>
          </div>

          <label className="flex items-center justify-between gap-2 text-[11px] text-slate-400 cursor-pointer select-none">
            <span>Respect joint limits</span>
            <input
              type="checkbox"
              checked={respectLimits}
              onChange={(e) => setRespectLimits(e.target.checked)}
              className="accent-[#3B82F6] rounded cursor-pointer"
            />
          </label>

          {([0, 1, 2] as const).map((axis) => {
            const val = Math.round(rot[axis] * 10) / 10;
            const minBound = respectLimits ? limits.min[axis] : -180;
            const maxBound = respectLimits ? limits.max[axis] : 180;
            return (
              <div key={axis} className="flex items-center gap-2">
                <span
                  className={`text-xs font-mono font-semibold w-4 ${AXIS_COLORS[axis]}`}
                >
                  {AXIS_LABELS[axis]}
                </span>
                <input
                  type="range"
                  min={minBound}
                  max={maxBound}
                  step={1}
                  value={Math.max(minBound, Math.min(maxBound, val))}
                  aria-label={`${activeJoint} ${AXIS_LABELS[axis]} rotation`}
                  onChange={(e) => handleAxisEdit(axis, Number(e.target.value))}
                  className="studio-slider flex-1"
                />
                <input
                  type="number"
                  min={minBound}
                  max={maxBound}
                  step={1}
                  value={val}
                  aria-label={`${activeJoint} ${AXIS_LABELS[axis]} degrees`}
                  onChange={(e) => handleAxisEdit(axis, Number(e.target.value) || 0)}
                  className="w-16 bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded px-1.5 py-1 text-right text-xs font-mono tabular-nums text-slate-100 outline-none"
                />
              </div>
            );
          })}
        </div>

        {/* Root Translation when HumanoidRootPart is active */}
        {activeJoint === 'HumanoidRootPart' && (
          <div className="border-t border-[#232B3E] pt-3 space-y-2">
            <span className="block text-xs font-medium text-slate-300">
              Root Translation (studs)
            </span>
            {([0, 1, 2] as const).map((axis) => {
              const val = Math.round(rootPos[axis] * 100) / 100;
              return (
                <div key={axis} className="flex items-center gap-2">
                  <span
                    className={`text-xs font-mono font-semibold w-4 ${AXIS_COLORS[axis]}`}
                  >
                    {AXIS_LABELS[axis]}
                  </span>
                  <input
                    type="range"
                    min={-3}
                    max={3}
                    step={0.05}
                    value={val}
                    onChange={(e) =>
                      onEditRootPosition(axis, Number(e.target.value))
                    }
                    className="studio-slider flex-1"
                  />
                  <input
                    type="number"
                    min={-10}
                    max={10}
                    step={0.05}
                    value={val}
                    onChange={(e) =>
                      onEditRootPosition(
                        axis,
                        Math.max(-10, Math.min(10, Number(e.target.value) || 0)),
                      )
                    }
                    className="w-16 bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded px-1.5 py-1 text-right text-xs font-mono tabular-nums text-slate-100 outline-none"
                  />
                </div>
              );
            })}
          </div>
        )}

        {/* Mirror Pose Actions */}
        <div className="border-t border-[#232B3E] pt-3 space-y-2">
          <span className="block text-xs font-medium text-slate-300">
            Symmetry
          </span>
          <button
            type="button"
            onClick={onMirrorFullPose}
            title="Flip all Left and Right joint rotations across the X-axis (M)"
            className="w-full flex items-center justify-center gap-1.5 bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] text-slate-200 text-xs font-medium py-1.5 px-3 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FlipHorizontal2 className="w-3.5 h-3.5 text-[#3B82F6]" />
            <span>Mirror Pose (L ↔ R)</span>
          </button>

          {oppositeJoint && (
            <button
              type="button"
              onClick={() => onMirrorSelectedJoint(activeJoint)}
              title={`Mirror ${activeJoint} rotation onto ${oppositeJoint}`}
              className="w-full flex items-center justify-center gap-1.5 bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] text-slate-300 text-xs font-medium py-1.5 px-3 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <ArrowLeftRight className="w-3.5 h-3.5 text-slate-400" />
              <span className="truncate">Mirror to {oppositeJoint}</span>
            </button>
          )}
        </div>

        {/* Keyframe Commit */}
        <div className="border-t border-[#232B3E] pt-3 space-y-2">
          <button
            type="button"
            onClick={onCommitPoseToKeyframe}
            className={`w-full flex items-center justify-center gap-1.5 text-xs font-semibold py-2 px-3 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              hasUnsavedPoseEdits
                ? 'bg-[#F59E0B] hover:bg-[#D97706] text-slate-950'
                : 'bg-[#3B82F6] hover:bg-[#2563EB] text-white'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>
              {activeKeyframe
                ? `Update Keyframe (${activeKeyframe.time.toFixed(2)}s)`
                : `Add Keyframe (${currentTime.toFixed(2)}s)`}
            </span>
          </button>
        </div>

        {/* Keyframe Metadata when playhead is on a keyframe */}
        {activeKeyframe && (
          <div className="border-t border-[#232B3E] pt-3 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="font-medium text-slate-300">Keyframe Timing</span>
              <span className="font-mono tabular-nums">
                {Object.keys(activeKeyframe.joints).length} joints
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label
                  htmlFor="inspector-kf-time"
                  className="block text-[11px] text-slate-400 mb-1"
                >
                  Time (s)
                </label>
                <input
                  id="inspector-kf-time"
                  type="number"
                  min={0}
                  max={duration}
                  step={0.01}
                  value={Number(activeKeyframe.time.toFixed(2))}
                  onChange={(e) =>
                    onChangeKeyframeMeta(activeKeyframe.id, {
                      time: Math.max(
                        0,
                        Math.min(duration, Number(e.target.value) || 0),
                      ),
                    })
                  }
                  className="w-full bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded px-2 py-1 text-xs font-mono tabular-nums text-slate-100 outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="inspector-kf-easing"
                  className="block text-[11px] text-slate-400 mb-1"
                >
                  Easing
                </label>
                <select
                  id="inspector-kf-easing"
                  value={activeKeyframe.easing}
                  onChange={(e) =>
                    onChangeKeyframeMeta(activeKeyframe.id, {
                      easing: e.target.value as EasingMode,
                    })
                  }
                  className="w-full bg-[#0B0E14] border border-[#232B3E] focus:border-[#3B82F6] rounded px-2 py-1 text-xs text-slate-100 outline-none"
                >
                  <option value="easeInOut">Ease In-Out</option>
                  <option value="easeOut">Ease Out</option>
                  <option value="easeIn">Ease In</option>
                  <option value="linear">Linear</option>
                  <option value="constant">Constant (Step)</option>
                  <option value="bounce">Bounce</option>
                  <option value="elastic">Elastic</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
