import React from 'react';
import {
  MousePointer2,
  Sparkles,
  Library,
  PersonStanding,
  Wrench,
  Settings,
} from 'lucide-react';

export type LeftToolId =
  | 'select'
  | 'ai'
  | 'library'
  | 'pose'
  | 'props'
  | 'settings';

interface LeftToolRailProps {
  activeTool: LeftToolId | null;
  onSelectTool: (tool: LeftToolId) => void;
}

const TOOLS: { id: LeftToolId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'select', label: 'Select & Hierarchy', icon: MousePointer2 },
  { id: 'ai', label: 'AI Generator', icon: Sparkles },
  { id: 'library', label: 'Animation Library', icon: Library },
  { id: 'pose', label: 'Pose Editor', icon: PersonStanding },
  { id: 'props', label: 'Props', icon: Wrench },
  { id: 'settings', label: 'Workspace Settings', icon: Settings },
];

export function LeftToolRail({ activeTool, onSelectTool }: LeftToolRailProps) {
  return (
    <nav
      aria-label="Studio tools"
      className="w-12 shrink-0 bg-[#111622] border-r border-[#232B3E] flex flex-col items-center py-2 gap-1.5 select-none"
    >
      {TOOLS.map(({ id, label, icon: Icon }) => {
        const isActive = activeTool === id;
        return (
          <button
            key={id}
            type="button"
            title={label}
            aria-label={label}
            aria-pressed={isActive}
            onClick={() => onSelectTool(id)}
            className={`w-9 h-9 rounded-md flex items-center justify-center transition-colors cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#3B82F6] ${
              isActive
                ? 'bg-[#3B82F6] text-white'
                : 'text-slate-400 hover:text-slate-100 hover:bg-[#1B2233]'
            }`}
          >
            <Icon className="w-4 h-4" />
          </button>
        );
      })}
    </nav>
  );
}
