import React, { useCallback, useEffect, useState } from 'react';
import {
  X,
  Copy,
  Check,
  Terminal,
  RefreshCw,
  ArrowUpRight,
  FolderUp,
  Trash2,
} from 'lucide-react';
import type { AnimationProject } from '../animation/types.ts';

interface SharedClipSummary {
  id: string;
  source: 'mcp' | 'studio';
  updatedAt: string;
  project: AnimationProject;
}

interface McpModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeProject: AnimationProject;
  onOpenClipInTab: (project: AnimationProject, label: string) => void;
}

export function McpModal({
  isOpen,
  onClose,
  activeProject,
  onOpenClipInTab,
}: McpModalProps) {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [clips, setClips] = useState<SharedClipSummary[]>([]);
  const [loadingClips, setLoadingClips] = useState(false);
  const [mcpDisabled, setMcpDisabled] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const origin =
    typeof window !== 'undefined'
      ? window.location.origin
      : 'http://localhost:3000';
  const mcpUrl = `${origin}/mcp`;

  const claudeHttpCmd = `claude mcp add --transport http motionforge ${mcpUrl}`;
  const codexHttpCmd = `codex mcp add motionforge --url ${mcpUrl}`;
  const codexToml = `[mcp_servers.motionforge]\nurl = "${mcpUrl}"`;
  const stdioJson = JSON.stringify(
    {
      mcpServers: {
        motionforge: {
          command: 'npx',
          args: ['tsx', 'mcp-server.ts'],
        },
      },
    },
    null,
    2,
  );

  const fetchClips = useCallback(async () => {
    setLoadingClips(true);
    try {
      const res = await fetch('/api/mcp/clips');
      if (res.status === 404 || res.status === 503) {
        setMcpDisabled(true);
        setClips([]);
        return;
      }
      if (res.ok) {
        setMcpDisabled(false);
        const data = (await res.json()) as { clips?: SharedClipSummary[] };
        setClips(Array.isArray(data.clips) ? data.clips : []);
      }
    } catch {
      // Ignore transient fetch errors
    } finally {
      setLoadingClips(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      setStatusMsg(null);
      fetchClips();
    }
  }, [isOpen, fetchClips]);

  if (!isOpen) return null;

  const copyText = async (key: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedKey(key);
      window.setTimeout(() => {
        setCopiedKey((curr) => (curr === key ? null : curr));
      }, 1800);
    } catch {
      // Clipboard fallback ignored
    }
  };

  const handlePushActiveClip = async () => {
    setStatusMsg(null);
    try {
      const res = await fetch('/api/mcp/clips', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ project: activeProject }),
      });
      if (res.status === 404 || res.status === 503) {
        setMcpDisabled(true);
        setStatusMsg('MCP HTTP endpoint is disabled (ENABLE_MCP=false).');
        return;
      }
      if (res.ok) {
        const data = (await res.json()) as { clip?: SharedClipSummary };
        setStatusMsg(
          `Pushed "${activeProject.name}" to MCP workspace (id: ${data.clip?.id}).`,
        );
        await fetchClips();
      }
    } catch {
      setStatusMsg('Could not push clip to MCP workspace.');
    }
  };

  const handleDeleteClip = async (id: string) => {
    try {
      await fetch(`/api/mcp/clips/${encodeURIComponent(id)}`, {
        method: 'DELETE',
      });
      await fetchClips();
    } catch {
      // Ignore
    }
  };

  const CopyBtn = ({ id, text }: { id: string; text: string }) => (
    <button
      type="button"
      onClick={() => copyText(id, text)}
      title="Copy to clipboard"
      className="flex items-center gap-1 px-2 py-0.5 bg-[#1B2233] hover:bg-[#252E44] border border-[#2B354C] rounded text-[11px] text-slate-200 transition-colors shrink-0 cursor-pointer"
    >
      {copiedKey === id ? (
        <>
          <Check className="w-3 h-3 text-emerald-400" />
          <span className="text-emerald-300">Copied</span>
        </>
      ) : (
        <>
          <Copy className="w-3 h-3" />
          <span>Copy</span>
        </>
      )}
    </button>
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[88vh] bg-[#111622] border border-[#232B3E] rounded-lg shadow-2xl flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#232B3E] shrink-0">
          <div className="flex items-center gap-2.5">
            <Terminal className="w-4 h-4 text-[#3B82F6]" />
            <div>
              <h2 className="text-sm font-semibold text-white">
                MCP Server — Claude Code &amp; Codex
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Streamable HTTP (<code className="text-slate-300">/mcp</code>) &amp;
                local stdio (<code className="text-slate-300">mcp-server.ts</code>)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-[#1B2233] rounded transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Claude Code HTTP */}
          <div className="bg-[#161C2B] border border-[#232B3E] rounded-md p-3.5 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-100">
                Claude Code (Streamable HTTP)
              </span>
              <CopyBtn id="claude-http" text={claudeHttpCmd} />
            </div>
            <pre className="bg-[#0B0E14] border border-[#232B3E] rounded px-3 py-2 text-[11px] font-mono text-sky-300 overflow-x-auto">
              {claudeHttpCmd}
            </pre>
          </div>

          {/* OpenAI Codex CLI */}
          <div className="bg-[#161C2B] border border-[#232B3E] rounded-md p-3.5 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-100">
                OpenAI Codex CLI (HTTP URL or config.toml)
              </span>
              <CopyBtn id="codex-http" text={codexHttpCmd} />
            </div>
            <pre className="bg-[#0B0E14] border border-[#232B3E] rounded px-3 py-2 text-[11px] font-mono text-emerald-300 overflow-x-auto">
              {codexHttpCmd}
            </pre>
            <div className="flex items-center justify-between gap-2 pt-1">
              <span className="text-[11px] text-slate-400">
                Or add to <code className="text-slate-300">~/.codex/config.toml</code>:
              </span>
              <CopyBtn id="codex-toml" text={codexToml} />
            </div>
            <pre className="bg-[#0B0E14] border border-[#232B3E] rounded px-3 py-2 text-[11px] font-mono text-slate-300 overflow-x-auto">
              {codexToml}
            </pre>
          </div>

          {/* Local Stdio Config */}
          <div className="bg-[#161C2B] border border-[#232B3E] rounded-md p-3.5 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-100">
                Local Stdio (.mcp.json)
              </span>
              <CopyBtn id="stdio-json" text={stdioJson} />
            </div>
            <pre className="bg-[#0B0E14] border border-[#232B3E] rounded px-3 py-2 text-[11px] font-mono text-slate-300 overflow-x-auto">
              {stdioJson}
            </pre>
          </div>

          {/* Available MCP Tools */}
          <div className="space-y-1.5">
            <span className="block text-[11px] font-medium text-slate-400">
              Available MCP Tools (10)
            </span>
            <div className="flex flex-wrap gap-1.5 text-[11px] font-mono text-slate-300">
              {[
                'list_r15_joints',
                'list_presets',
                'get_preset',
                'generate_animation',
                'validate_animation',
                'evaluate_pose',
                'export_fbx',
                'save_clip',
                'list_clips',
                'get_clip',
              ].map((t) => (
                <span
                  key={t}
                  className="px-2 py-0.5 bg-[#0B0E14] border border-[#232B3E] rounded"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* Shared Workspace Bridge */}
          <div className="border-t border-[#232B3E] pt-3 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h3 className="text-xs font-semibold text-slate-100">
                  Shared MCP Workspace Clips
                </h3>
                <p className="text-[11px] text-slate-400">
                  Clips generated or saved by Claude Code / Codex appear here to open in the 3D viewport.
                </p>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={handlePushActiveClip}
                  className="flex items-center gap-1 px-2.5 py-1 bg-[#1D2842] hover:bg-[#253354] border border-[#3B82F6]/40 text-sky-200 text-[11px] font-medium rounded transition-colors cursor-pointer"
                >
                  <FolderUp className="w-3.5 h-3.5" />
                  <span>Push Active Clip</span>
                </button>
                <button
                  type="button"
                  onClick={fetchClips}
                  title="Refresh shared workspace clips"
                  className="p-1.5 bg-[#161C2B] hover:bg-[#1E263A] border border-[#232B3E] text-slate-300 rounded transition-colors cursor-pointer"
                >
                  <RefreshCw
                    className={`w-3.5 h-3.5 ${loadingClips ? 'animate-spin' : ''}`}
                  />
                </button>
              </div>
            </div>

            {statusMsg && (
              <p className="text-[11px] text-emerald-400">{statusMsg}</p>
            )}

            {mcpDisabled ? (
              <p className="text-[11px] text-amber-300 bg-amber-950/35 border border-amber-800/50 rounded px-2.5 py-2">
                HTTP MCP endpoints are disabled in this environment (<code className="text-amber-200">ENABLE_MCP=false</code>). Local stdio via <code className="text-amber-200">mcp-server.ts</code> remains available.
              </p>
            ) : clips.length === 0 ? (
              <p className="text-[11px] text-slate-500 py-2">
                No clips in MCP workspace yet. Call <code className="text-slate-400">generate_animation</code> or{' '}
                <code className="text-slate-400">save_clip</code> from Claude Code/Codex, or push your active clip above.
              </p>
            ) : (
              <div className="space-y-1.5">
                {clips.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center justify-between gap-3 bg-[#161C2B] border border-[#232B3E] rounded px-3 py-2"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-xs text-slate-100 font-medium truncate">
                        <span className="truncate">{c.project.name}</span>
                        <span className="text-[10px] font-mono text-slate-400">
                          {c.id}
                        </span>
                      </div>
                      <div className="text-[11px] font-mono text-slate-400">
                        {c.project.duration.toFixed(2)}s · {c.project.keyframes.length} keys ·{' '}
                        {c.source}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          onOpenClipInTab(
                            structuredClone(c.project),
                            `Loaded "${c.project.name}" from MCP`,
                          );
                          onClose();
                        }}
                        className="flex items-center gap-1 px-2.5 py-1 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-[11px] font-medium rounded transition-colors cursor-pointer"
                      >
                        <ArrowUpRight className="w-3 h-3" />
                        <span>Open Tab</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteClip(c.id)}
                        title="Remove from MCP workspace"
                        className="p-1 text-rose-400 hover:bg-rose-950/40 rounded transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
