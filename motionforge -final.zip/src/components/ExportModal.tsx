import React, { useState } from 'react';
import { X, Download, FileJson, Box, Film, FileCode2 } from 'lucide-react';
import type { AnimationProject } from '../animation/types.ts';
import {
  exportFBXAnimation,
  exportGLBAnimation,
  exportProjectJSON,
  exportRobloxLua,
} from '../export/exporters.ts';

interface ExportModalProps {
  project: AnimationProject;
  isOpen: boolean;
  onClose: () => void;
}

export function ExportModal({ project, isOpen, onClose }: ExportModalProps) {
  const [glbBusy, setGlbBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleExportJSON = () => {
    setError(null);
    exportProjectJSON(project);
    setMessage('Downloaded MotionForge Project JSON (.motionforge.json).');
  };

  const handleExportGLB = async () => {
    setGlbBusy(true);
    setError(null);
    setMessage(null);
    try {
      const bytes = await exportGLBAnimation(project);
      const kb = (bytes / 1024).toFixed(1);
      setMessage(`Exported binary R15 GLB animation (${kb} KB).`);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Failed to export GLB animation.',
      );
    } finally {
      setGlbBusy(false);
    }
  };

  const handleExportFBX = () => {
    setError(null);
    setMessage(null);
    try {
      const bytes = exportFBXAnimation(project);
      const kb = (bytes / 1024).toFixed(1);
      setMessage(`Exported ASCII FBX 7.4 R15 animation (${kb} KB).`);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Failed to export FBX animation.',
      );
    }
  };

  const handleExportRobloxLua = () => {
    setError(null);
    setMessage(null);
    try {
      const bytes = exportRobloxLua(project);
      const kb = (bytes / 1024).toFixed(1);
      setMessage(`Exported Roblox KeyframeSequence script (${kb} KB).`);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Failed to export Roblox Lua script.',
      );
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-[#111622] border border-[#232B3E] rounded-lg shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#232B3E]">
          <div>
            <h2 className="text-sm font-semibold text-white">
              Export Animation Data
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              {project.name} · {project.duration.toFixed(2)}s ·{' '}
              {project.keyframes.length} keyframes
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-[#1B2233] rounded transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-3">
          {/* Option 1: MotionForge Project JSON */}
          <div className="flex items-center justify-between gap-4 bg-[#161C2B] border border-[#232B3E] rounded-md p-3.5">
            <div className="flex items-start gap-3">
              <FileJson className="w-5 h-5 text-[#3B82F6] shrink-0 mt-0.5" />
              <div>
                <h3 className="text-xs font-semibold text-slate-100">
                  MotionForge Project JSON
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                  Lossless R15 keyframes, joint Euler rotations, easing curves,
                  and prop settings. Re-importable anytime.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleExportJSON}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#3B82F6] hover:bg-[#2563EB] text-white text-xs font-semibold rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export JSON</span>
            </button>
          </div>

          {/* Option 2: Standard GLB Skeletal Animation */}
          <div className="flex items-center justify-between gap-4 bg-[#161C2B] border border-[#232B3E] rounded-md p-3.5">
            <div className="flex items-start gap-3">
              <Box className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-xs font-semibold text-slate-100">
                  Standard 3D GLB Animation
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                  Binary glTF 2.0 (.glb) containing the named R15 rig hierarchy
                  and baked QuaternionKeyframeTracks for Blender or Three.js.
                </p>
              </div>
            </div>
            <button
              type="button"
              disabled={glbBusy}
              onClick={handleExportGLB}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1B2233] hover:bg-[#252E44] border border-[#2B354C] text-slate-100 text-xs font-semibold rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{glbBusy ? 'Baking...' : 'Export GLB'}</span>
            </button>
          </div>

          {/* Option 3: ASCII FBX 7.4 R15 Skeletal Animation */}
          <div className="flex items-center justify-between gap-4 bg-[#161C2B] border border-[#232B3E] rounded-md p-3.5">
            <div className="flex items-start gap-3">
              <Film className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xs font-semibold text-slate-100">
                    FBX 7.4 R15 Skeletal Animation
                  </h3>
                  <span className="text-[11px] text-amber-300 font-medium">
                    ASCII .fbx
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                  Standard 16-bone R15 LimbNode hierarchy and baked XYZ
                  AnimationCurves (validated via FBXLoader; verify joint
                  orientation inside Roblox Studio or Blender before publishing).
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleExportFBX}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1B2233] hover:bg-[#252E44] border border-[#2B354C] text-slate-100 text-xs font-semibold rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export FBX</span>
            </button>
          </div>

          {/* Option 4: Roblox Studio Native KeyframeSequence (.lua) */}
          <div className="bg-[#161C2B] border border-[#232B3E] rounded-md p-3.5 space-y-2">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <FileCode2 className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xs font-semibold text-slate-100">
                    Roblox KeyframeSequence Script
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                    Native R15 Pose hierarchy, CFrame.Angles, and PoseEasingStyle
                    script for Roblox Studio&apos;s Command Bar.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleExportRobloxLua}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1B2233] hover:bg-[#252E44] border border-[#2B354C] text-slate-100 text-xs font-semibold rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Roblox (.lua)</span>
              </button>
            </div>
            <ol className="text-[11px] text-slate-400 pl-8 space-y-0.5 list-decimal">
              <li>Open Roblox Studio &gt; View &gt; Command Bar.</li>
              <li>Paste the downloaded .lua file and press Enter to generate the KeyframeSequence in ServerStorage (or your selected Rig).</li>
              <li>Right-click the generated KeyframeSequence &gt; Save to Roblox, or import it into Animation Editor.</li>
            </ol>
          </div>

          {message && (
            <p className="text-xs text-emerald-400 pt-1">{message}</p>
          )}
          {error && <p className="text-xs text-rose-400 pt-1">{error}</p>}
        </div>
      </div>
    </div>
  );
}
