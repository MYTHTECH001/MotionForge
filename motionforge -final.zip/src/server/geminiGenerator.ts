import { GoogleGenAI, ThinkingLevel, Type, type Schema } from '@google/genai';
import {
  R15_JOINT_NAMES,
  type AnimationProject,
  type PropType,
  type Vec3Tuple,
} from '../animation/types.ts';
import { validateAnimationPayload } from '../animation/validator.ts';

export const GEMINI_PRIMARY_MODEL =
  process.env.GEMINI_PRIMARY_MODEL?.trim() || 'gemini-4-hydrogen';
export const GEMINI_FALLBACK_MODEL =
  process.env.GEMINI_FALLBACK_MODEL?.trim() || 'gemini-3.1-flash-lite';

const PRIMARY_TIMEOUT_MS = 12000;
const FALLBACK_TIMEOUT_MS = 12000;

export class GeminiGenerationError extends Error {
  status: number;

  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export interface GenerateAnimationRequest {
  prompt: string;
  duration?: number;
  prop?: PropType | 'auto';
  loop?: boolean;
}

export interface RefineAnimationRequest {
  project: unknown;
  instruction: string;
}

export interface GenerateAnimationResult {
  project: AnimationProject;
  warnings: string[];
}

function getAiClient(apiKey: string): GoogleGenAI {
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      timeout: 30000,
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const JOINT_PROPERTIES: Record<string, Schema> = Object.fromEntries(
  R15_JOINT_NAMES.map((joint) => [
    joint,
    {
      type: Type.ARRAY,
      items: { type: Type.NUMBER },
    },
  ]),
);

const ANIMATION_RESPONSE_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING },
    duration: { type: Type.NUMBER },
    fps: { type: Type.INTEGER },
    loop: { type: Type.BOOLEAN },
    prop: { type: Type.STRING, enum: ['none', 'net', 'sword'] },
    keyframes: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          time: { type: Type.NUMBER },
          easing: {
            type: Type.STRING,
            enum: [
              'linear',
              'easeInOut',
              'easeIn',
              'easeOut',
              'constant',
              'bounce',
              'elastic',
            ],
          },
          rootPosition: {
            type: Type.ARRAY,
            items: { type: Type.NUMBER },
          },
          joints: {
            type: Type.OBJECT,
            properties: JOINT_PROPERTIES,
          },
        },
        required: ['time', 'easing', 'joints'],
      },
    },
  },
  required: ['name', 'duration', 'fps', 'loop', 'prop', 'keyframes'],
};

const SYSTEM_INSTRUCTION = `You are a senior Roblox R15 3D character animator and rigging specialist.
Translate the user's text prompt into a realistic, physically grounded keyframe animation for an articulated Roblox R15 rig.

OUTPUT FORMAT: Return ONLY a single valid JSON object (no markdown, no explanation) matching this exact schema:
{
  "name": "Short Animation Name",
  "duration": 1.0,
  "fps": 30,
  "loop": true,
  "prop": "none" | "net" | "sword",
  "keyframes": [
    {
      "time": 0.0,
      "easing": "easeInOut" | "easeIn" | "easeOut" | "linear",
      "rootPosition": [0, 0, 0],
      "joints": {
        "HumanoidRootPart": [0, 0, 0],
        "LowerTorso": [0, 0, 0],
        "UpperTorso": [0, 0, 0],
        "Head": [0, 0, 0],
        "LeftUpperArm": [0, 0, 0],
        "LeftLowerArm": [0, 0, 0],
        "LeftHand": [0, 0, 0],
        "RightUpperArm": [0, 0, 0],
        "RightLowerArm": [0, 0, 0],
        "RightHand": [0, 0, 0],
        "LeftUpperLeg": [0, 0, 0],
        "LeftLowerLeg": [0, 0, 0],
        "LeftFoot": [0, 0, 0],
        "RightUpperLeg": [0, 0, 0],
        "RightLowerLeg": [0, 0, 0],
        "RightFoot": [0, 0, 0]
      }
    }
  ]
}

VALID R15 JOINT NAMES (only use names from this exact list):
HumanoidRootPart, LowerTorso, UpperTorso, Head, LeftUpperArm, LeftLowerArm, LeftHand, RightUpperArm, RightLowerArm, RightHand, LeftUpperLeg, LeftLowerLeg, LeftFoot, RightUpperLeg, RightLowerLeg, RightFoot.

COORDINATE SYSTEM & R15 JOINT CONVENTIONS (Right-handed Three.js XYZ Euler in DEGREES):
The character stands upright along +Y and faces +Z (toward the viewer).
Character's LEFT side is +X; character's RIGHT side is -X.
All rotations are local [rx, ry, rz] Euler angles in degrees relative to neutral standing pose (arms and legs straight down along -Y):
- HumanoidRootPart: [rx, ry, rz] overall body orientation. +ry turns left (+X); -ry turns right (-X).
- LowerTorso: pelvis tilt/twist. +rx pitches hips forward; +ry twists left.
- UpperTorso: waist bend/twist. -rx hunches chest forward; +rx arches back; +ry twists left; -ry twists right.
- Head: -rx looks down; +rx looks up; +ry turns left; -ry turns right.
- LeftUpperArm: -rx swings arm FORWARD (+Z) and overhead (-90 forward, -150 overhead); +rx swings back; +rz raises arm OUTWARD left (+X).
- LeftLowerArm: -rx bends elbow FORWARD (0 straight, -90 bent). Keep ry and rz near 0.
- LeftHand / RightHand: wrist flex/twist [rx, ry, rz]. Animate hands when relevant (e.g. when holding a net or sword, +rx tilts tool tip forward/down and -rx cocks tip back; during waves or expressive gestures, flex/tilt wrists).
- RightUpperArm: -rx swings arm FORWARD (+Z) and overhead (-90 forward, -150 overhead); +rx swings back; -rz raises arm OUTWARD right (-X).
- RightLowerArm: -rx bends elbow FORWARD (0 straight, -90 bent). Keep ry and rz near 0.
- LeftUpperLeg / RightUpperLeg: -rx lifts thigh FORWARD; +rx extends thigh BACK.
- LeftLowerLeg / RightLowerLeg: +rx bends knee BACKWARD (0 straight, +75 squat). Never negative rx on knees.
- LeftFoot / RightFoot: -rx dorsiflexes toes up; +rx points toes down. Animate feet when relevant (crouches, jumps, kicks, stepping, and weight shifts).

ANIMATION PRINCIPLES:
1. Include anticipation, main action/impact, follow-through, and recovery (4 to 6 keyframes for short clips, more for longer clips).
2. If loop=true, make the first keyframe (t=0) and last keyframe (t=duration) match closely.
3. Coordinate whole-body motion: torso twist, counter-balancing off-arm, knee bend + rootPosition Y drop during crouches/swings, animated hands/feet where appropriate, and head tracking.`;

function normalizeRawAnimationObject(raw: unknown): unknown {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return raw;
  const obj = { ...(raw as Record<string, unknown>) };
  if (!Array.isArray(obj.keyframes)) return obj;

  obj.keyframes = obj.keyframes.map((kfRaw) => {
    if (!kfRaw || typeof kfRaw !== 'object' || Array.isArray(kfRaw)) {
      return kfRaw;
    }
    const kf = { ...(kfRaw as Record<string, unknown>) };
    if (Array.isArray(kf.joints)) {
      const mapped: Record<string, [number, number, number]> = {};
      for (const entry of kf.joints) {
        if (entry && typeof entry === 'object' && !Array.isArray(entry)) {
          const item = entry as Record<string, unknown>;
          if (typeof item.joint === 'string') {
            mapped[item.joint] = [
              Number(item.rx ?? 0),
              Number(item.ry ?? 0),
              Number(item.rz ?? 0),
            ];
          }
        }
      }
      kf.joints = mapped;
    }
    return kf;
  });

  return obj;
}

function enforceLoopEndpointMatch(project: AnimationProject): void {
  if (!project.loop || project.keyframes.length < 2) return;
  const first = project.keyframes[0];
  const lastIdx = project.keyframes.length - 1;
  const last = project.keyframes[lastIdx];

  const clonedJoints: AnimationProject['keyframes'][number]['joints'] = {};
  for (const [joint, rot] of Object.entries(first.joints)) {
    if (rot) {
      clonedJoints[joint as keyof typeof clonedJoints] = [rot[0], rot[1], rot[2]];
    }
  }

  project.keyframes[lastIdx] = {
    ...last,
    joints: clonedJoints,
    ...(first.rootPosition
      ? { rootPosition: [...first.rootPosition] as Vec3Tuple }
      : { rootPosition: undefined }),
  };
  if (!first.rootPosition) {
    delete project.keyframes[lastIdx].rootPosition;
  }
}

function withTimeout<T>(
  promise: Promise<T>,
  ms: number,
  label: string,
): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`${label} timed out after ${Math.round(ms / 1000)}s.`));
    }, ms);
    promise.then(
      (val) => {
        clearTimeout(timer);
        resolve(val);
      },
      (err) => {
        clearTimeout(timer);
        reject(err);
      },
    );
  });
}

async function callGeminiAnimationModel(
  apiKey: string,
  userMessage: string,
): Promise<unknown> {
  const ai = getAiClient(apiKey);

  const runModel = async (model: string, timeoutMs: number) => {
    const thinkingLevel = model.includes('flash-lite')
      ? ThinkingLevel.MINIMAL
      : ThinkingLevel.LOW;

    return withTimeout(
      ai.models.generateContent({
        model,
        contents: userMessage,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          responseMimeType: 'application/json',
          responseSchema: ANIMATION_RESPONSE_SCHEMA,
          thinkingConfig: { thinkingLevel },
        },
      }),
      timeoutMs,
      model,
    );
  };

  let response;
  try {
    response = await runModel(GEMINI_PRIMARY_MODEL, PRIMARY_TIMEOUT_MS);
  } catch (primaryErr: unknown) {
    const msg = primaryErr instanceof Error ? primaryErr.message : '';
    console.warn('[MotionForge] Primary model fallback:', msg);
    if (/API_KEY_INVALID|PERMISSION_DENIED|403|401/i.test(msg)) {
      throw primaryErr;
    }
    response = await runModel(GEMINI_FALLBACK_MODEL, FALLBACK_TIMEOUT_MS);
  }

  const rawText = response.text?.trim();
  if (!rawText) {
    throw new GeminiGenerationError(
      502,
      'Gemini returned an empty response. Please try rephrasing your prompt.',
    );
  }

  try {
    return JSON.parse(rawText);
  } catch {
    throw new GeminiGenerationError(
      502,
      'Gemini returned malformed JSON. Please retry.',
    );
  }
}

function mapGeminiError(err: unknown): never {
  if (err instanceof GeminiGenerationError) {
    throw err;
  }
  const message =
    err instanceof Error ? err.message : 'Unknown error calling Gemini API.';
  console.error('[MotionForge] Gemini generation error:', message);

  if (/API_KEY_INVALID|PERMISSION_DENIED|403|401/i.test(message)) {
    throw new GeminiGenerationError(
      401,
      'Gemini API key was rejected. Check GEMINI_API_KEY in Settings > Secrets.',
    );
  }
  if (/RESOURCE_EXHAUSTED|429/i.test(message)) {
    throw new GeminiGenerationError(
      429,
      'Gemini API rate limit reached. Wait a moment and try again.',
    );
  }
  if (/503|504|UNAVAILABLE|DEADLINE_EXCEEDED|timed out/i.test(message)) {
    throw new GeminiGenerationError(
      503,
      'Gemini is temporarily busy or timed out. Please retry in a few seconds, or use the built-in presets.',
    );
  }

  throw new GeminiGenerationError(502, `Gemini generation failed: ${message}`);
}

export function isGeminiConfigured(): boolean {
  return Boolean(
    process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0,
  );
}

export async function generateAnimationFromPrompt(
  req: GenerateAnimationRequest,
): Promise<GenerateAnimationResult> {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new GeminiGenerationError(
      503,
      'GEMINI_API_KEY is not configured. Add your Gemini API key in Settings > Secrets to enable AI generation, or use the built-in presets and manual editor.',
    );
  }

  const rawPrompt = typeof req.prompt === 'string' ? req.prompt.trim() : '';
  if (!rawPrompt) {
    throw new GeminiGenerationError(400, 'Please enter an animation prompt.');
  }
  if (rawPrompt.length > 600) {
    throw new GeminiGenerationError(
      400,
      'Prompt must be 600 characters or fewer.',
    );
  }

  const requestedDuration =
    typeof req.duration === 'number' && Number.isFinite(req.duration)
      ? Math.max(0.3, Math.min(30, Math.round(req.duration * 100) / 100))
      : 1.0;

  const requestedProp =
    req.prop === 'net' || req.prop === 'sword' || req.prop === 'none'
      ? req.prop
      : 'auto';

  const requestedLoop = typeof req.loop === 'boolean' ? req.loop : true;

  const targetKeyframes =
    requestedDuration >= 4
      ? '7 to 10'
      : requestedDuration > 1.5
        ? '5 to 8'
        : '4 to 6';

  const userMessage = [
    `Create a Roblox R15 keyframe animation for: "${rawPrompt}".`,
    `Target duration: ${requestedDuration.toFixed(2)} seconds. Set "duration" to ${requestedDuration.toFixed(2)} and span keyframes from 0.0 to ${requestedDuration.toFixed(2)}.`,
    `Looping: ${requestedLoop ? 'true (match start and end pose)' : 'false'}.`,
    requestedProp === 'auto'
      ? 'Choose prop="net" if catching/net swing, prop="sword" if sword/blade/slash, otherwise prop="none".'
      : `Use prop="${requestedProp}".`,
    `Generate ${targetKeyframes} rich keyframes with coordinated whole-body rotations.`,
  ].join('\n');

  try {
    const parsed = await callGeminiAnimationModel(apiKey, userMessage);
    const normalized = normalizeRawAnimationObject(parsed);
    const validation = validateAnimationPayload(normalized);
    if (!validation.valid || !validation.project) {
      throw new GeminiGenerationError(
        422,
        `Generated animation failed R15 validation: ${validation.errors.join(' ')}`,
      );
    }

    if (Math.abs(validation.project.duration - requestedDuration) > 0.05) {
      const oldDur = Math.max(0.01, validation.project.duration);
      const ratio = requestedDuration / oldDur;
      validation.project.duration = requestedDuration;
      validation.project.keyframes = validation.project.keyframes.map((kf) => ({
        ...kf,
        time: Math.round(kf.time * ratio * 1000) / 1000,
      }));
    }

    if (requestedProp !== 'auto') {
      validation.project.prop = requestedProp;
    }

    validation.project.loop = requestedLoop;
    enforceLoopEndpointMatch(validation.project);

    return {
      project: validation.project,
      warnings: validation.warnings,
    };
  } catch (err: unknown) {
    mapGeminiError(err);
  }
}

export async function refineAnimation(
  req: RefineAnimationRequest,
): Promise<GenerateAnimationResult> {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new GeminiGenerationError(
      503,
      'GEMINI_API_KEY is not configured. Add your Gemini API key in Settings > Secrets to enable AI refinement.',
    );
  }

  const instruction =
    typeof req.instruction === 'string' ? req.instruction.trim() : '';
  if (!instruction) {
    throw new GeminiGenerationError(
      400,
      'Please enter a refinement instruction.',
    );
  }
  if (instruction.length > 600) {
    throw new GeminiGenerationError(
      400,
      'Refinement instruction must be 600 characters or fewer.',
    );
  }

  const inputValidation = validateAnimationPayload(req.project);
  if (!inputValidation.valid || !inputValidation.project) {
    throw new GeminiGenerationError(
      400,
      `Invalid base animation project: ${inputValidation.errors.join(' ')}`,
    );
  }

  const baseProject = inputValidation.project;
  const userMessage = [
    `Edit and refine the following Roblox R15 keyframe animation according to this instruction: "${instruction}".`,
    'Preserve the overall character structure, prop, and timing unless the instruction explicitly asks to change them.',
    'Current animation JSON:',
    JSON.stringify(baseProject),
  ].join('\n');

  try {
    const parsed = await callGeminiAnimationModel(apiKey, userMessage);
    const normalized = normalizeRawAnimationObject(parsed);
    const validation = validateAnimationPayload(normalized);
    if (!validation.valid || !validation.project) {
      throw new GeminiGenerationError(
        422,
        `Refined animation failed R15 validation: ${validation.errors.join(' ')}`,
      );
    }

    enforceLoopEndpointMatch(validation.project);

    return {
      project: validation.project,
      warnings: validation.warnings,
    };
  } catch (err: unknown) {
    mapGeminiError(err);
  }
}
